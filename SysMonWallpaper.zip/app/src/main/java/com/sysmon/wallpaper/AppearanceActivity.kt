package com.sysmon.wallpaper

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** الخلفية وسطر الأوامر السفلي (الاسم والألوان). */
class AppearanceActivity : Activity() {

    private lateinit var p: SharedPreferences
    private lateinit var scroll: ScrollView
    private lateinit var col: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        t.setPadding(0, dp(8), 0, dp(2))
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs.of(this)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(32), dp(16), dp(32))
        scroll.addView(col)
        setContentView(scroll)
        render()
    }

    private fun swatch(color: Int, onClick: () -> Unit): TextView {
        val s = TextView(this)
        s.text = "  #" + String.format("%06X", color and 0xFFFFFF) + "  "
        s.textSize = 12f
        s.typeface = Typeface.MONOSPACE
        s.setBackgroundColor(color or 0xFF000000.toInt())
        s.setTextColor(if (Contrast.lum(color) > 0.4f) Color.BLACK else Color.WHITE)
        s.setPadding(dp(8), dp(10), dp(8), dp(10))
        s.setOnClickListener { onClick() }
        return s
    }

    private fun render() {
        val y = scroll.scrollY
        col.removeAllViews()
        col.addView(tv("ax82l@phone:~\$ sysmon --look", 15f, Col.GREEN, true))

        // ---- قوالب ألوان جاهزة ----
        col.addView(tv("Color themes", 14f, Col.CYAN, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        col.addView(tv("sets the background, prompt colors and every graph's color stops", 11f, Col.GRAY))
        val themeRow = LinearLayout(this)
        themeRow.orientation = LinearLayout.HORIZONTAL
        for (t in Themes.all) {
            val b = Button(this)
            b.text = t.name
            b.isAllCaps = false
            b.textSize = 11f
            b.setOnClickListener { Themes.apply(p, t); render() }
            themeRow.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(themeRow)

        // ---- الخلفية ----
        col.addView(tv("Background", 14f, Col.CYAN, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        val bg = p.getInt(Prefs.BG, Color.BLACK)
        col.addView(swatch(bg) {
            ColorDialog.show(this, "Background color", null) { c -> p.edit().putInt(Prefs.BG, c).apply(); render() }
        })
        val sw = Switch(this)
        sw.text = "Shift colors that match the background"
        sw.textSize = 12f
        sw.typeface = Typeface.MONOSPACE
        sw.setTextColor(Color.WHITE)
        sw.isChecked = p.getBoolean(Prefs.BGSHIFT, true)
        sw.setOnCheckedChangeListener { _, c -> p.edit().putBoolean(Prefs.BGSHIFT, c).apply() }
        sw.setPadding(0, dp(14), 0, 0)
        col.addView(sw)
        col.addView(tv("Any text or graph color too close to the background is lightened or darkened so it stays readable. Turn off to use your exact colors.", 11f, Col.GRAY))

        // ---- سطر الأوامر ----
        col.addView(tv("Prompt line (bottom)", 14f, Col.CYAN, true).apply { setPadding(0, dp(24), 0, dp(4)) })
        col.addView(tv("Edit the text and color of each part. Leave a part empty to hide it.", 11f, Col.GRAY))
        val labels = mapOf(
            "user" to "user", "at" to "at", "host" to "host", "colon" to "colon",
            "path" to "path", "sign" to "prompt", "cmd" to "command"
        )
        for ((name, defT, defC) in Prefs.PROMPT) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(tv(labels[name] ?: name, 12f, Col.WHITE), LinearLayout.LayoutParams(dp(72), ViewGroup.LayoutParams.WRAP_CONTENT))
            val et = EditText(this)
            et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            et.setText(p.getString("ps_t_$name", defT))
            et.setTextColor(Color.WHITE)
            et.typeface = Typeface.MONOSPACE
            et.textSize = 14f
            et.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    p.edit().putString("ps_t_$name", s?.toString() ?: "").apply()
                }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
            row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val dot = TextView(this)
            dot.text = "●"
            dot.textSize = 22f
            dot.gravity = Gravity.CENTER
            dot.setTextColor(p.getInt("ps_c_$name", defC))
            dot.setPadding(dp(12), dp(4), dp(8), dp(4))
            dot.setOnClickListener {
                ColorDialog.show(this, "Color: " + (labels[name] ?: name), null) { c ->
                    p.edit().putInt("ps_c_$name", c).apply()
                    render()
                }
            }
            row.addView(dot)
            col.addView(row)
        }

        val dev = Switch(this)
        dev.text = "Use the phone name as host"
        dev.textSize = 12f
        dev.typeface = Typeface.MONOSPACE
        dev.setTextColor(Color.WHITE)
        dev.isChecked = p.getBoolean(Prefs.P_DEV, false)
        dev.setOnCheckedChangeListener { _, c -> p.edit().putBoolean(Prefs.P_DEV, c).apply() }
        dev.setPadding(0, dp(16), 0, 0)
        col.addView(dev)
        val name = try { Settings.Global.getString(contentResolver, Settings.Global.DEVICE_NAME) } catch (e: Exception) { null }
        col.addView(tv("current phone name: " + (if (name.isNullOrBlank()) Build.MODEL else name) + "  (its color follows the host color)", 11f, Col.GRAY))

        val cur = Switch(this)
        cur.text = "Blinking cursor"
        cur.textSize = 12f
        cur.typeface = Typeface.MONOSPACE
        cur.setTextColor(Color.WHITE)
        cur.isChecked = p.getBoolean(Prefs.P_CUR, true)
        cur.setOnCheckedChangeListener { _, c -> p.edit().putBoolean(Prefs.P_CUR, c).apply() }
        cur.setPadding(0, dp(12), 0, 0)
        col.addView(cur)
        col.addView(tv("cursor color", 12f, Col.WHITE))
        col.addView(swatch(p.getInt(Prefs.P_CUR_COL, Col.WHITE)) {
            ColorDialog.show(this, "Cursor color", null) { c -> p.edit().putInt(Prefs.P_CUR_COL, c).apply(); render() }
        })

        val reset = Button(this)
        reset.text = "Reset background & prompt"
        reset.isAllCaps = false
        reset.setOnClickListener {
            val e = p.edit().remove(Prefs.BG).remove(Prefs.BGSHIFT).remove(Prefs.P_DEV).remove(Prefs.P_CUR).remove(Prefs.P_CUR_COL)
            for ((n, _, _) in Prefs.PROMPT) e.remove("ps_t_$n").remove("ps_c_$n")
            e.apply()
            render()
        }
        col.addView(reset, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) })
        scroll.post { scroll.scrollTo(0, y) }
    }
}
