package com.sysmon.wallpaper

import android.Manifest
import android.app.ActivityManager
import android.content.ContentResolver
import android.hardware.display.DisplayManager
import android.location.LocationManager
import android.net.Network
import android.view.Display
import android.content.pm.PackageManager
import android.telephony.TelephonyManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.view.WindowManager
import java.io.File
import java.net.Inet4Address
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

class Span(val t: String, val c: Int, val bars: FloatArray? = null, val heat: Boolean = false)
typealias Line = List<Span>

object Col {
    val GREEN = 0xFF00E676.toInt()
    val YELLOW = 0xFFFFD600.toInt()
    val RED = 0xFFFF5252.toInt()
    val CYAN = 0xFF18FFFF.toInt()
    val BLUE = 0xFF448AFF.toInt()
    val GRAY = 0xFF8A8A8A.toInt()
    val WHITE = 0xFFEEEEEE.toInt()
}

fun heatColor(v: Float): Int = if (v < 0.5f) Col.GREEN else if (v < 0.8f) Col.YELLOW else Col.RED

class Ring(private val n: Int) {
    private val a = FloatArray(n)
    private var i = 0
    var count = 0
        private set

    fun add(v: Float) { a[i] = v; i = (i + 1) % n; if (count < n) count++ }
    fun reset() { i = 0; count = 0 }
    fun avg(): Float {
        if (count == 0) return 0f
        var s = 0f
        for (k in 0 until count) s += a[k]
        return s / count
    }
    fun last(): Float = if (count == 0) 0f else a[(i - 1 + n) % n]
    fun ordered(): FloatArray {
        val out = FloatArray(n)
        for (k in 0 until n) out[k] = a[(i + k) % n]
        return out
    }
}

/** نافذة عدادات: تعطي معدل التغير بين أقدم وأحدث قراءة. */
class CounterWin(private val n: Int) {
    private val v = LongArray(n)
    private val t = LongArray(n)
    private var i = 0
    var count = 0
        private set

    fun add(value: Long, ts: Long) { v[i] = value; t[i] = ts; i = (i + 1) % n; if (count < n) count++ }
    fun reset() { i = 0; count = 0 }
    /** معدل التغير على نافذة زمنية لا تقل عن span (أو أقصى ما توفر). */
    fun perUnit(span: Long): Float {
        if (count < 2) return 0f
        val newest = (i - 1 + n) % n
        var best = newest
        var idx = newest
        var used = 1
        while (used < count) {
            idx = (idx - 1 + n) % n
            used++
            best = idx
            if (t[newest] - t[idx] >= span) break
        }
        val dt = t[newest] - t[best]
        if (dt <= 0L) return 0f
        return (v[newest] - v[best]).coerceAtLeast(0L).toFloat() / dt.toFloat()
    }
}

class SysStats(private val ctx: Context) {

    companion object {
        const val CORES_MAX = 16
        private val THERMAL = listOf("NONE", "LIGHT", "MODERATE", "SEVERE", "CRITICAL", "EMERGENCY", "SHUTDOWN")
    }

    @Volatile var left: List<Line> = emptyList()
    @Volatile var right: List<Line> = emptyList()
    @Volatile var lux: Float = -1f

    private val pending = ArrayList<Pair<String, Line>>()
    fun drainEvents(): List<Pair<String, Line>> {
        if (pending.isEmpty()) return emptyList()
        val c = ArrayList(pending)
        pending.clear()
        return c
    }

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val au = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val wnd = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = Prefs.of(ctx)
    private val bt = BtMonitor(ctx.applicationContext)
    private val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
    private val cfgUsed = BooleanArray(CORES_MAX)
    private val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val dmgr = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    @Volatile private var cbSsid = ""
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var briAuto = false

    private val soc: String = if (Build.VERSION.SDK_INT >= 31) (Build.SOC_MODEL ?: "") else ""
    private var tickN = 0L
    private var mediumDone = false
    private var lastMedium = 0L
    private var lastSlow = 0L
    private var started = false
    private var gpuUtil = -1f
    private var gpuAnnounced = false
    private val gpuRoot = GpuRoot()

    // ---------- CPU ----------
    private var cores = 1
    private val maxFreq = LongArray(CORES_MAX)
    private val freqAvg = Array(CORES_MAX) { Ring(4) }
    private val hist = Array(CORES_MAX) { Ring(12) }
    private val loadWin = Array(CORES_MAX) { CounterWin(40) }
    private val coreOnline = BooleanArray(CORES_MAX)
    private val coreFreq = FloatArray(CORES_MAX)
    private val coreLoad = FloatArray(CORES_MAX) { -1f }
    private val idleStates = IntArray(CORES_MAX)
    private var idleOk = false
    private var loadAvg = -1f
    private var fRatio = -1f
    private val loadHist = Ring(10)
    private var thermalPath: String? = null
    private var gpuPath: String? = null
    private var gpuNow = -1f
    private var gpuMax = 0f

    // ---------- battery ----------
    private var pct = -1
    private var status = -1
    private var plugged = 0
    private var tempC = Float.NaN
    private var volt = 0
    private var health = 0
    private var cycles = -1
    private var chargeMah = -1
    private var etaMs = -1L
    private val curRing = Ring(4)

    // ---------- memory / disk ----------
    private var ramTotal = 0L
    private var ramUsed = 0L
    private val ramHist = Ring(8)
    private var swapTotal = -1L
    private var swapFree = -1L
    private var cachedB = -1L
    private var dskTotal = 0L
    private var dskFree = 0L

    // ---------- network ----------
    private val rxWin = CounterWin(40)
    private val txWin = CounterWin(40)
    private var dl = 0f
    private var ul = 0f
    private val dlHist = Ring(10)
    private val ulHist = Ring(10)
    private var rxTotal = -1L
    private var txTotal = -1L
    private var netType = "OFF"
    private var band = ""
    private var wifiStd = 0
    private var rssi = Int.MIN_VALUE
    private var linkMbps = -1
    private var cellSig = Int.MIN_VALUE
    private var ip = "N/A"
    private var ssid = ""
    private var opName = ""

    // ---------- system ----------
    private var hz = -1
    private var bri = -1
    private var upS = 0L
    private var zzz = -1
    private var air = 0
    private var dnd = 0
    private var psv = 0
    private var thm = -1
    private var vol = -1
    private var load3 = ""

    // ---------- events state ----------
    private var detectReady = false
    private var pPct = -1
    private var pPlug = -1
    private var pStatus = -1
    private var pNet = ""
    private var pHz = -1
    private var pBri = -1
    private var pVol = -1
    private var pAir = -1
    private var pDnd = -1
    private var pPsv = -1
    private var pThm = -99
    private var ramHigh = false
    private var lvB = 0
    private var lvC = 0
    private var boostArmed = true
    private var lastBoost = 0L
    private var dlBurst = false
    private var ulBurst = false
    private var startTs = 0L
    private var pBtOn: Boolean? = null
    private var pBtInit = false
    private val pBtDevs = HashMap<String, BtDev>()

    val curPct: Int get() = pct
    val curCharging: Boolean get() = status == BatteryManager.BATTERY_STATUS_CHARGING
    val curPsv: Boolean get() = psv == 1
    fun note(tag: String, c: Int, msg: String) = evT(tag, c, msg)
    fun onVisible(v: Boolean) {
        if (!started) return
        if (v) gpuRoot.start() else gpuRoot.stop()
    }
    fun release() {
        gpuRoot.stop()
        bt.stop()
        try { netCb?.let { cm.unregisterNetworkCallback(it) } } catch (e: Exception) { }
        netCb = null
    }

    // ====================== helpers ======================

    private fun readText(path: String): String? = try {
        File(path).readText().trim()
    } catch (e: Exception) {
        null
    }

    private fun readLong(path: String): Long? = readText(path)?.toLongOrNull()
    private fun f(fmt: String, vararg a: Any): String = String.format(Locale.US, fmt, *a)
    private fun stamp() = Span(timeFmt.format(Date()) + " ", Col.GRAY)
    private fun sp(t: String, c: Int = Col.WHITE) = Span(t, c)
    private fun gr(t: String) = Span(t, Col.GRAY)
    private fun bars(a: FloatArray, c: Int, heat: Boolean) = Span("", c, a, heat)
    private fun row(vararg s: Span): Line = s.toList()
    private fun rc(r: Float) = heatColor(r)
    private fun tcol(t: Float, lo: Float, hi: Float) = if (t < lo) Col.GREEN else if (t < hi) Col.YELLOW else Col.RED
    private fun nn(b: Float) = (log10(b + 1f) / 7f).coerceIn(0f, 1f)

    private fun ev(tag: String, tc: Int, vararg s: Span) {
        pending.add(Pair(tag, listOf(stamp(), Span("$tag ", tc)) + s.toList()))
    }

    private fun evT(tag: String, tc: Int, msg: String, mc: Int = Col.WHITE) = ev(tag, tc, Span(msg, mc))

    private fun spd(b: Float): String = when {
        b >= 1_048_576f -> f("%.1fMB/s", b / 1_048_576f)
        b >= 1024f -> f("%.0fKB/s", b / 1024f)
        else -> f("%.0fB/s", b)
    }

    private fun big(b: Long): String = when {
        b >= (1L shl 30) -> f("%.1fG", b / 1_073_741_824f)
        b >= (1L shl 20) -> f("%.0fM", b / 1_048_576f)
        else -> f("%.0fK", b / 1024f)
    }

    private fun hm(ms: Long): String {
        val m = ms / 60000L
        return "${m / 60}h${(m % 60).toString().padStart(2, '0')}m"
    }

    private fun battery(): Intent? =
        ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

    private inline fun safe(block: () -> Unit) {
        try { block() } catch (e: Exception) { }
    }

    // ====================== sysfs ======================

    private fun readIdle(i: Int): Long? {
        val n = idleStates[i]
        if (n == 0) return null
        var sum = 0L
        for (j in 0 until n) {
            sum += readLong("/sys/devices/system/cpu/cpu$i/cpuidle/state$j/time") ?: return null
        }
        return sum
    }

    private fun findThermal(): String? {
        val zones = File("/sys/class/thermal").listFiles { x -> x.name.startsWith("thermal_zone") }
            ?: return null
        val prefer = listOf("cpu", "soc", "tsens", "mtktscpu", "ap")
        for (z in zones.sortedBy { it.name }) {
            val type = readText(File(z, "type").path) ?: continue
            if (prefer.any { type.contains(it, ignoreCase = true) }) {
                val p = File(z, "temp").path
                if (readLong(p) != null) return p
            }
        }
        return null
    }

    private fun cpuTemp(): Float? {
        val p = thermalPath ?: return null
        val v = readLong(p) ?: return null
        val c = if (abs(v) > 1000) v / 1000f else v.toFloat()
        return if (c in 1f..120f) c else null
    }

    private fun findGpu(): String? {
        for (p in listOf("/sys/class/kgsl/kgsl-3d0/gpuclk", "/sys/kernel/gpu/gpu_clock", "/sys/kernel/ged/hal/current_freqency")) {
            if (readLong(p) != null) return p
        }
        val dirs = File("/sys/class/devfreq").listFiles() ?: return null
        for (d in dirs) {
            val n = d.name.lowercase()
            if (n.contains("mali") || n.contains("gpu") || n.contains("kgsl")) {
                val p = d.path + "/cur_freq"
                if (readLong(p) != null) return p
            }
        }
        return null
    }

    private fun gpuMhz(): Float? {
        val p = gpuPath ?: return null
        val v = readLong(p) ?: return null
        return when {
            v > 10_000_000L -> v / 1e6f
            v > 10_000L -> v / 1e3f
            else -> v.toFloat()
        }
    }

    private fun kb(text: String?, key: String): Long {
        if (text == null) return -1L
        val line = text.lineSequence().firstOrNull { it.startsWith(key) } ?: return -1L
        val v = line.split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() ?: return -1L
        return v * 1024L
    }

    // ====================== السطوع ======================

    /** تحويل السطوع الخطي إلى موضع شريط السطوع (منحنى النظام HLG). */
    private fun linearToSlider(x: Float): Float {
        val n = x.coerceIn(0f, 1f) * 12f
        val r = if (n <= 1f) sqrt(n) * 0.5f else 0.17883277f * ln(n - 0.28466892f) + 0.55991073f
        return r.coerceIn(0f, 1f)
    }

    private fun readBrightness(cr: ContentResolver): Int {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val info = dmgr.getDisplay(Display.DEFAULT_DISPLAY)?.brightnessInfo
                if (info != null) {
                    val mn = info.brightnessMinimum
                    val mx = if (info.brightnessMaximum > 1f) 1f else info.brightnessMaximum
                    if (mx > mn) {
                        val norm = ((info.brightness - mn) / (mx - mn)).coerceIn(0f, 1f)
                        return Math.round(linearToSlider(norm) * 100f)
                    }
                }
            } catch (e: Exception) { }
        }
        val br = try { Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, -1) } catch (e: Exception) { -1 }
        return if (br >= 0) (br * 100 / 255).coerceAtMost(100) else -1
    }

    // ====================== اسم الشبكة عبر NetworkCallback ======================

    private fun cleanSsid(raw: String?): String {
        val r = (raw ?: "").trim('"')
        return if (r.isEmpty() || r == "<unknown ssid>") "" else r
    }

    private fun registerNetCb() {
        if (Build.VERSION.SDK_INT < 31 || netCb != null) return
        try {
            val cb = object : ConnectivityManager.NetworkCallback(ConnectivityManager.NetworkCallback.FLAG_INCLUDE_LOCATION_INFO) {
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    val ti = caps.transportInfo
                    cbSsid = if (ti is WifiInfo) cleanSsid(ti.ssid) else ""
                }
                override fun onLost(network: Network) { cbSsid = "" }
            }
            cm.registerDefaultNetworkCallback(cb)
            netCb = cb
        } catch (e: Exception) { }
    }

    // ====================== start / probe ======================

    fun start(hasLight: Boolean) {
        cores = (0 until CORES_MAX).count { File("/sys/devices/system/cpu/cpu$it").exists() }
            .coerceAtLeast(1)
        for (i in 0 until cores) {
            var j = 0
            while (File("/sys/devices/system/cpu/cpu$i/cpuidle/state$j/time").exists()) j++
            idleStates[i] = j
        }
        val a = LongArray(cores) { readIdle(it) ?: -1L }
        try { Thread.sleep(150) } catch (e: InterruptedException) { }
        val b = LongArray(cores) { readIdle(it) ?: -1L }
        var inc = 0
        for (i in 0 until cores) if (a[i] >= 0L && b[i] > a[i]) inc++
        idleOk = inc >= (cores + 1) / 2

        thermalPath = findThermal()
        gpuPath = findGpu()

        val okFreq = readLong("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq") != null
        val okTherm = thermalPath != null && cpuTemp() != null
        val okMem = readText("/proc/meminfo") != null
        val okLoad = readText("/proc/loadavg") != null
        val okCur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW).let {
            it != Int.MIN_VALUE && it != 0
        }
        val okCnt = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER).let {
            it != Long.MIN_VALUE && it > 0L
        }
        val okCyc = (battery()?.getIntExtra("android.os.extra.CYCLE_COUNT", -1) ?: -1) > 0
        val okWifi = try { wm.connectionInfo != null } catch (e: Exception) { false }
        val btPerm = bt.hasPerm()
        val locPerm = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

        ev("SYS", Col.GREEN, sp("sysmon 2.0 ${Build.MANUFACTURER} ${Build.MODEL} android ${Build.VERSION.RELEASE} sdk ${Build.VERSION.SDK_INT}"))
        probeLine(listOf("cpufreq" to okFreq, "idle" to idleOk, "thermal" to okTherm))
        probeLine(listOf("meminfo" to okMem, "loadavg" to okLoad, "current" to okCur, "mAh" to okCnt))
        probeLine(listOf("cycles" to okCyc, "light" to hasLight, "wifi" to okWifi, "bt" to btPerm, "loc" to locPerm))
        evT(
            "CPU", Col.BLUE,
            if (idleOk) "load source: cpuidle (real), f% = frequency ratio" else "load source: frequency only (f%)",
            Col.GRAY
        )
        registerNetCb()
        gpuRoot.start()
        startTs = SystemClock.elapsedRealtime()
        started = true
    }

    private fun probeLine(items: List<Pair<String, Boolean>>) {
        val s = ArrayList<Span>()
        s += stamp()
        s += Span("PROBE ", Col.BLUE)
        for ((n, ok) in items) {
            s += Span("$n ", Col.WHITE)
            s += Span(if (ok) "OK " else "N/A ", if (ok) Col.GREEN else Col.RED)
        }
        pending.add(Pair("PROBE", s))
    }

    // ====================== tick ======================

    fun tick() {
        tickN++
        val nowMs = SystemClock.elapsedRealtime()
        val nowUs = SystemClock.elapsedRealtimeNanos() / 1000L
        safe { sampleCpu(nowUs) }
        safe { sampleGpu() }
        safe { sampleCurrent() }
        safe { sampleNetBytes(nowMs) }
        if (lastMedium == 0L || nowMs - lastMedium >= 1000L) { lastMedium = nowMs; safe { sampleMedium() } }
        if (lastSlow == 0L || nowMs - lastSlow >= 5000L) { lastSlow = nowMs; safe { sampleSlow() } }
        safe { detect() }
        safe { buildPanels() }
    }

    private fun sampleCpu(nowUs: Long) {
        var sumF = 0f; var nF = 0; var sumL = 0f; var nL = 0
        for (i in 0 until cores) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val cur = readLong(base + "scaling_cur_freq")
            if (cur == null || cur <= 0L) {
                coreOnline[i] = false
                coreLoad[i] = -1f
                loadWin[i].reset()
                freqAvg[i].reset()
                hist[i].add(0f)
                continue
            }
            coreOnline[i] = true
            val cfg = prefs.getInt(Prefs.fmaxKey(i), Prefs.defaultFmax(i)).toLong() * 1000L
            if (cfg > 0L) {
                maxFreq[i] = cfg
                cfgUsed[i] = true
            } else {
                if (cfgUsed[i]) { maxFreq[i] = 0L; cfgUsed[i] = false }
                if (maxFreq[i] == 0L) maxFreq[i] = readLong(base + "cpuinfo_max_freq") ?: 0L
                if (cur > maxFreq[i]) maxFreq[i] = cur
            }
            freqAvg[i].add(cur.toFloat())
            coreFreq[i] = freqAvg[i].avg()
            val mx = maxFreq[i].toFloat()
            hist[i].add(if (mx > 0f) (cur / mx).coerceAtMost(1f) else 0f)
            if (mx > 0f) { sumF += (coreFreq[i] / mx).coerceAtMost(1f); nF++ }
            if (idleOk) {
                val idle = readIdle(i)
                if (idle != null) {
                    loadWin[i].add(idle, nowUs)
                    if (loadWin[i].count >= 3) {
                        val l = (1f - loadWin[i].perUnit(1_000_000L)).coerceIn(0f, 1f)
                        coreLoad[i] = l
                        sumL += l; nL++
                    }
                } else coreLoad[i] = -1f
            }
        }
        fRatio = if (nF > 0) sumF / nF else -1f
        loadAvg = if (nL > 0) sumL / nL else -1f
        loadHist.add(if (loadAvg >= 0f) loadAvg else max(fRatio, 0f))
    }

    private fun sampleGpu() {
        gpuNow = gpuMhz() ?: -1f
        if (gpuNow < 0f && gpuRoot.freq >= 0f) gpuNow = gpuRoot.freq
        gpuUtil = gpuRoot.util
        if (gpuNow > gpuMax) gpuMax = gpuNow
        if (gpuRoot.ok && !gpuAnnounced) {
            gpuAnnounced = true
            evT("GPU", Col.GREEN, "root read OK", Col.GREEN)
        }
    }

    private fun sampleCurrent() {
        val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        if (raw != Int.MIN_VALUE) {
            val ma = if (abs(raw) > 20_000) abs(raw) / 1000f else abs(raw).toFloat()
            curRing.add(ma)
        }
    }

    private fun sampleNetBytes(nowMs: Long) {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx < 0L || tx < 0L) return
        rxTotal = rx; txTotal = tx
        rxWin.add(rx, nowMs); txWin.add(tx, nowMs)
        dl = rxWin.perUnit(1000L) * 1000f
        ul = txWin.perUnit(1000L) * 1000f
        dlHist.add(nn(dl)); ulHist.add(nn(ul))
    }

    @Suppress("DEPRECATION")
    private fun sampleMedium() {
        val b = battery()
        if (b != null) {
            val lv = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            pct = if (lv >= 0 && sc > 0) lv * 100 / sc else -1
            status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            plugged = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
            val t = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            tempC = if (t == Int.MIN_VALUE) Float.NaN else t / 10f
            volt = b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
            health = b.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)
            cycles = b.getIntExtra("android.os.extra.CYCLE_COUNT", -1)
        }
        val cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        chargeMah = if (cc == Long.MIN_VALUE || cc <= 0L) -1 else if (cc > 20_000L) (cc / 1000L).toInt() else cc.toInt()
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val ma = curRing.avg()
        etaMs = when {
            charging && Build.VERSION.SDK_INT >= 28 -> bm.computeChargeTimeRemaining()
            !charging && chargeMah > 0 && ma > 20f -> (chargeMah / ma * 3_600_000f).toLong()
            else -> -1L
        }

        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        ramTotal = mi.totalMem
        ramUsed = mi.totalMem - mi.availMem
        if (ramTotal > 0L) ramHist.add(ramUsed.toFloat() / ramTotal)
        val mt = readText("/proc/meminfo")
        swapTotal = kb(mt, "SwapTotal:")
        swapFree = kb(mt, "SwapFree:")
        cachedB = kb(mt, "Cached:")

        val la = readText("/proc/loadavg")?.split(" ")
        load3 = if (la != null && la.size >= 3) "${la[0]} ${la[1]} ${la[2]}" else ""

        val cr = ctx.contentResolver
        air = try { Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0) } catch (e: Exception) { 0 }
        dnd = try { Settings.Global.getInt(cr, "zen_mode", 0) } catch (e: Exception) { 0 }
        psv = if (pm.isPowerSaveMode) 1 else 0
        thm = if (Build.VERSION.SDK_INT >= 29) pm.currentThermalStatus else -1
        val mx = au.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        vol = if (mx > 0) au.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / mx else -1
        hz = Math.round(wnd.defaultDisplay.refreshRate)
        briAuto = try { Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0) == 1 } catch (e: Exception) { false }
        bri = readBrightness(cr)
        upS = SystemClock.elapsedRealtime() / 1000L
        val e = SystemClock.elapsedRealtime()
        zzz = if (e > 0L) (100L * (e - SystemClock.uptimeMillis()) / e).toInt() else -1

        val net = cm.activeNetwork
        val caps = if (net != null) cm.getNetworkCapabilities(net) else null
        band = ""; wifiStd = 0; rssi = Int.MIN_VALUE; linkMbps = -1; cellSig = Int.MIN_VALUE
        ssid = ""; opName = ""
        netType = when {
            caps == null -> "OFF"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cell"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Eth"
            else -> "Net"
        }
        if (netType == "WiFi") {
            val info: WifiInfo? = try { wm.connectionInfo } catch (e2: Exception) { null }
            if (info != null) {
                rssi = info.rssi
                linkMbps = info.linkSpeed
                val fq = info.frequency
                band = when {
                    fq in 2400..2500 -> "2.4GHz"
                    fq in 4900..5899 -> "5GHz"
                    fq >= 5925 -> "6GHz"
                    else -> ""
                }
                wifiStd = if (Build.VERSION.SDK_INT >= 30) info.wifiStandard else 0
                val rawSsid = (info.ssid ?: "").trim('"')
                ssid = if (rawSsid.isEmpty() || rawSsid == "<unknown ssid>") "" else rawSsid
            }
        } else if (netType == "Cell" && caps != null && Build.VERSION.SDK_INT >= 29) {
            cellSig = caps.signalStrength
            opName = tm?.networkOperatorName ?: ""
        }
        if (netType == "WiFi" && ssid.isEmpty() && cbSsid.isNotEmpty()) ssid = cbSsid
        safe { bt.refresh() }
        mediumDone = true
    }

    private fun sampleSlow() {
        val st = StatFs(Environment.getDataDirectory().path)
        dskTotal = st.blockCountLong * st.blockSizeLong
        dskFree = st.availableBytes
        val net = cm.activeNetwork
        val lp = if (net != null) cm.getLinkProperties(net) else null
        val a = lp?.linkAddresses?.firstOrNull { it.address is Inet4Address }
        ip = a?.address?.hostAddress ?: "N/A"
    }

    // ====================== events ======================

    private fun hyst(cur: Int, t: Float, t1: Float, t2: Float): Int {
        if (t.isNaN()) return cur
        var l = cur
        if (t >= t2) l = 2 else if (t >= t1 && l < 1) l = 1
        if (l == 2 && t < t2 - 2f) l = 1
        if (l == 1 && t < t1 - 2f) l = 0
        return l
    }

    private val lvName = listOf("normal", "warm", "hot")
    private val lvCol = listOf(Col.GREEN, Col.YELLOW, Col.RED)

    private fun bigIdx(): Int = (0 until cores).maxByOrNull { maxFreq[it] } ?: 0

    private fun detect() {
        if (!mediumDone) return
        val first = !detectReady
        detectReady = true

        if (pPct >= 0 && pct >= 0 && pct != pPct) {
            evT("BAT", if (status == BatteryManager.BATTERY_STATUS_CHARGING) Col.CYAN else Col.YELLOW, "$pPct% -> $pct%")
        }
        pPct = pct

        if (!first && plugged != pPlug) {
            if (plugged != 0) evT("CHG", Col.CYAN, "plugged ${plugName()}", Col.CYAN)
            else evT("CHG", Col.YELLOW, "unplugged", Col.YELLOW)
        }
        if (!first && status != pStatus && status == BatteryManager.BATTERY_STATUS_FULL) evT("CHG", Col.GREEN, "battery full", Col.GREEN)
        pPlug = plugged; pStatus = status

        val key = "$netType|$band|$ssid"
        if (!first && key != pNet) {
            if (netType == "OFF") evT("NET", Col.RED, "offline", Col.RED)
            else evT("NET", Col.CYAN, "-> $netType $ssid $band".replace("  ", " ").trim(), Col.WHITE)
        }
        pNet = key

        // ---- البلوتوث ----
        val btOn = bt.on
        if (pBtInit && btOn != null && pBtOn != null && btOn != pBtOn) {
            evT("BT", Col.BLUE, if (btOn) "bluetooth ON" else "bluetooth off", if (btOn) Col.CYAN else Col.GRAY)
        }
        pBtOn = btOn
        val curBt = bt.devices
        if (pBtInit) {
            for (d in curBt) {
                val old = pBtDevs[d.addr]
                if (old == null) evT("BT", Col.CYAN, "+ ${d.name} (${d.kinds})", Col.CYAN)
                else if (d.battery >= 0 && old.battery >= 0 && d.battery != old.battery) {
                    evT("BT", Col.BLUE, "${d.name} battery ${old.battery}% -> ${d.battery}%")
                }
            }
            for ((addr, old) in pBtDevs) {
                if (curBt.none { it.addr == addr }) evT("BT", Col.YELLOW, "- ${old.name} disconnected", Col.YELLOW)
            }
        }
        pBtDevs.clear()
        for (d in curBt) pBtDevs[d.addr] = d
        pBtInit = bt.permOk && bt.on != null && SystemClock.elapsedRealtime() - startTs > 4000L

        if (!first && hz != pHz && pHz > 0) evT("SCR", Col.BLUE, "refresh $pHz -> ${hz}Hz")
        pHz = hz
        if (pBri < 0) pBri = bri else if (bri >= 0 && abs(bri - pBri) >= 5) { evT("SCR", Col.BLUE, "brightness $pBri -> $bri%"); pBri = bri }
        if (pVol < 0) pVol = vol else if (vol >= 0 && abs(vol - pVol) >= 5) { evT("VOL", Col.BLUE, "$pVol -> $vol%"); pVol = vol }

        if (!first && air != pAir) evT("AIR", Col.YELLOW, if (air == 1) "airplane ON" else "airplane off")
        if (!first && dnd != pDnd) evT("DND", Col.YELLOW, if (dnd != 0) "do not disturb ON" else "do not disturb off")
        if (!first && psv != pPsv) evT("PSV", Col.YELLOW, if (psv == 1) "battery saver ON" else "battery saver off")
        pAir = air; pDnd = dnd; pPsv = psv

        if (!first && thm != pThm && thm >= 0 && pThm >= 0) {
            evT("THM", if (thm >= 3) Col.RED else Col.YELLOW, "${THERMAL.getOrElse(pThm) { "?" }} -> ${THERMAL.getOrElse(thm) { "?" }}")
        }
        pThm = thm

        if (ramTotal > 0L) {
            val r = ramUsed.toFloat() / ramTotal
            if (!ramHigh && r >= 0.90f) { ramHigh = true; evT("RAM", Col.RED, "high ${(r * 100).toInt()}%", Col.RED) }
            else if (ramHigh && r < 0.85f) { ramHigh = false; evT("RAM", Col.GREEN, "back to normal ${(r * 100).toInt()}%", Col.GREEN) }
        }

        val nb = hyst(lvB, tempC, 40f, 45f)
        if (!first && nb != lvB) evT("TMP", lvCol[nb], f("battery %.1fC %s", tempC, lvName[nb]), lvCol[nb])
        lvB = nb
        val ct = cpuTemp()
        if (ct != null) {
            val nc = hyst(lvC, ct, 60f, 75f)
            if (!first && nc != lvC) evT("TMP", lvCol[nc], f("cpu %.0fC %s", ct, lvName[nc]), lvCol[nc])
            lvC = nc
        }

        val bi = bigIdx()
        val r = hist[bi].last()
        val now = SystemClock.elapsedRealtime()
        if (boostArmed && r >= 0.95f && now - lastBoost > 4000L && coreOnline[bi]) {
            boostArmed = false; lastBoost = now
            evT("CPU", Col.YELLOW, f("C%d boost %.2fGHz", bi, coreFreq[bi] / 1_000_000f), Col.YELLOW)
        } else if (!boostArmed && r < 0.7f) boostArmed = true

        if (!dlBurst && dl >= 5_242_880f) { dlBurst = true; evT("NET", Col.CYAN, "DL burst ${spd(dl)}", Col.CYAN) }
        else if (dlBurst && dl < 1_048_576f) dlBurst = false
        if (!ulBurst && ul >= 2_097_152f) { ulBurst = true; evT("NET", Col.CYAN, "UL burst ${spd(ul)}", Col.CYAN) }
        else if (ulBurst && ul < 524_288f) ulBurst = false
    }

    private fun plugName() = when (plugged) {
        BatteryManager.BATTERY_PLUGGED_AC -> "AC"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "WLS"
        else -> if (plugged != 0) "DOCK" else "-"
    }

    // ====================== panel rows ======================

    private fun clusterName(i: Int): String {
        val distinct = (0 until cores).map { maxFreq[it] }.filter { it > 0L }.distinct().sorted()
        val rank = distinct.indexOf(maxFreq[i])
        val total = distinct.size
        if (rank < 0) return "?"
        if (soc.equals("MT6985", ignoreCase = true) && total == 3) return listOf("A510", "A715", "X3")[rank]
        return when (total) {
            1 -> "CPU"
            2 -> listOf("LIT", "BIG")[rank]
            3 -> listOf("LIT", "MID", "BIG")[rank]
            else -> "CL$rank"
        }
    }

    // ====================== الصفوف القابلة للترتيب (blocks) ======================

    private val gbF = 1_073_741_824f
    private val isFull: Boolean get() = status == BatteryManager.BATTERY_STATUS_FULL

    private var cachedLayout: Layout? = null
    private var cacheL: String? = null
    private var cacheR: String? = null

    private fun currentLayout(): Layout {
        val kl = prefs.getString(LayoutStore.KEY_L, null)
        val kr = prefs.getString(LayoutStore.KEY_R, null)
        val c = cachedLayout
        if (c != null && kl == cacheL && kr == cacheR) return c
        val n = LayoutStore.load(prefs)
        cachedLayout = n; cacheL = kl; cacheR = kr
        return n
    }

    private fun arrange(items: List<Item>): List<Line> {
        val out = ArrayList<Line>()
        for (item in items) {
            if (!item.on) continue
            val rows = block(item.id)
            if (item.color == 0) {
                out.addAll(rows)
            } else {
                for (line in rows) {
                    out.add(line.map { sp2 -> if (sp2.c == Col.GRAY) sp2 else Span(sp2.t, item.color, sp2.bars, false) })
                }
            }
        }
        return out
    }

    private fun buildPanels() {
        val lay = currentLayout()
        left = arrange(lay.left)
        right = arrange(lay.right)
    }

    private fun block(id: String): List<Line> = when (id) {
        "cpu" -> listOf(cpuRow())
        "cores" -> coreRows()
        "gpu" -> listOf(gpuRow())
        "ldv" -> listOf(if (load3.isNotEmpty()) row(sp("LDV "), sp(load3, Col.CYAN)) else row(sp("LDV "), gr("N/A")))
        "os" -> listOf(row(sp("OS  "), sp("A${Build.VERSION.RELEASE} "), gr("patch "), sp(Build.VERSION.SECURITY_PATCH ?: "N/A")))
        "kern" -> listOf(kernRow())
        "bt" -> btRows()
        "bat" -> listOf(batRow())
        "batv" -> listOf(batVRow())
        "batt" -> listOf(batTRow())
        "bate" -> listOf(batERow())
        "ram" -> listOf(ramRow())
        "swp" -> listOf(swpRow())
        "dsk" -> listOf(dskRow())
        "net" -> listOf(netRow())
        "ap" -> listOf(apRow())
        "dl" -> listOf(row(gr("DL "), bars(dlHist.ordered(), Col.CYAN, false), sp(" " + spd(dl), heatColor(dl / 10_485_760f))))
        "ul" -> listOf(row(gr("UL "), bars(ulHist.ordered(), Col.BLUE, false), sp(" " + spd(ul), heatColor(ul / 10_485_760f))))
        "rxtx" -> listOf(
            row(
                gr("RX "), sp(if (rxTotal >= 0L) big(rxTotal) else "N/A"),
                gr(" TX "), sp(if (txTotal >= 0L) big(txTotal) else "N/A"),
                gr(" "), sp(ip, Col.GRAY)
            )
        )
        "scr" -> listOf(scrRow())
        "sys" -> listOf(sysRow())
        "flags" -> listOf(flagsRow())
        "thm" -> listOf(thmRow())
        else -> emptyList()
    }

    private fun cpuRow(): Line {
        val h = ArrayList<Span>()
        h += sp("CPU ")
        if (loadAvg >= 0f) h += sp("ld ${(loadAvg * 100).toInt()}% ", rc(loadAvg))
        h += if (fRatio >= 0f) sp("f ${(fRatio * 100).toInt()}% ", rc(fRatio)) else gr("f N/A ")
        h += bars(loadHist.ordered(), Col.GREEN, true)
        val ct = cpuTemp()
        h += if (ct != null) sp(f(" %.0f°C", ct), tcol(ct, 55f, 70f))
        else if (!tempC.isNaN()) sp(f(" b%.0f°C", tempC), tcol(tempC, 38f, 43f))
        else gr(" N/A")
        return h
    }

    private fun coreRows(): List<Line> {
        val rows = ArrayList<Line>()
        for (i in 0 until cores) {
            val r = ArrayList<Span>()
            r += gr("C$i ")
            r += sp(clusterName(i).padEnd(5), Col.GRAY)
            if (!coreOnline[i]) {
                r += gr("off")
                rows += r
                continue
            }
            val mx = maxFreq[i].toFloat()
            val ratio = if (mx > 0f) (coreFreq[i] / mx).coerceAtMost(1f) else 0f
            r += sp(f("%.2fG ", coreFreq[i] / 1_000_000f), rc(ratio))
            r += bars(hist[i].ordered(), Col.GREEN, true)
            if (coreLoad[i] >= 0f) r += sp(f(" %3d%%", (coreLoad[i] * 100).toInt()), rc(coreLoad[i]))
            rows += r
        }
        return rows
    }

    private fun gpuRow(): Line =
        if (gpuNow >= 0f || gpuUtil >= 0f) row(
            sp("GPU "),
            if (gpuNow >= 0f) sp(f("%.0fMHz ", gpuNow), rc(if (gpuMax > 0f) gpuNow / gpuMax else 0f)) else gr(""),
            if (gpuUtil >= 0f) sp(f("ld %.0f%%", gpuUtil), rc(gpuUtil / 100f)) else gr("")
        ) else row(sp("GPU "), sp("denied", Col.RED))

    private fun kernRow(): Line {
        val kr = System.getProperty("os.version") ?: "N/A"
        val k = kr.split("-").take(3).joinToString("-").take(32)
        return row(sp("K   "), sp(k, Col.GRAY))
    }

    private fun btRows(): List<Line> {
        val rows = ArrayList<Line>()
        val bh = ArrayList<Span>()
        bh += sp("BT  ")
        when {
            !bt.permOk -> bh += sp("no permission", Col.RED)
            bt.on == null -> bh += gr("N/A")
            bt.on == false -> bh += gr("off")
            else -> {
                bh += sp("on ", Col.CYAN)
                bh += gr("pair ")
                bh += sp(if (bt.paired >= 0) "${bt.paired} " else "? ")
                bh += gr("conn ")
                bh += sp("${bt.devices.size}", if (bt.devices.isEmpty()) Col.GRAY else Col.GREEN)
            }
        }
        rows += bh
        val devs = bt.devices
        for (j in 0 until 2) {
            val d = devs.getOrNull(j)
            if (d == null) {
                rows += row(gr(if (j == 0 && bt.on == true && devs.isEmpty()) "    none connected" else ""))
            } else {
                val bc = if (d.battery > 50) Col.GREEN else if (d.battery > 20) Col.YELLOW else Col.RED
                rows += row(
                    gr("  "),
                    sp(d.name.take(14).padEnd(14)),
                    if (d.battery >= 0) sp(String.format(Locale.US, " %3d%%", d.battery), bc) else gr(" n/a "),
                    gr(" " + d.kinds)
                )
            }
        }
        return rows
    }

    private fun batRow(): Line {
        val charging = curCharging
        val pc = if (charging) Col.CYAN else if (pct > 50) Col.GREEN else if (pct > 20) Col.YELLOW else Col.RED
        return row(
            sp("BAT "),
            sp(if (pct >= 0) "$pct%" else "N/A", pc),
            sp(if (charging) " CHG " else if (isFull) " FULL " else " DIS ", if (charging) Col.CYAN else Col.GRAY),
            if (chargeMah > 0) sp("${chargeMah}mAh", Col.GRAY) else gr("")
        )
    }

    private fun batVRow(): Line {
        val has = curRing.count > 0
        val ma = curRing.avg()
        val sign = if (curCharging) "+" else "-"
        return row(
            gr("    "),
            if (volt > 0) sp(f("%.2fV ", volt / 1000f)) else gr("N/A "),
            if (has) sp(f("%s%.0fmA ", sign, ma)) else gr("N/A "),
            if (has && volt > 0) sp(f("%s%.1fW", sign, volt / 1000f * ma / 1000f)) else gr("")
        )
    }

    private fun batTRow(): Line {
        val hp = when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "good" to Col.GREEN
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "hot" to Col.RED
            BatteryManager.BATTERY_HEALTH_COLD -> "cold" to Col.BLUE
            BatteryManager.BATTERY_HEALTH_DEAD -> "dead" to Col.RED
            else -> "?" to Col.GRAY
        }
        return row(
            gr("    "),
            if (!tempC.isNaN()) sp(f("%.1f°C ", tempC), tcol(tempC, 38f, 43f)) else gr("N/A "),
            gr("cyc "),
            if (cycles > 0) sp("$cycles ") else gr("N/A "),
            gr("hp "),
            sp(hp.first, hp.second)
        )
    }

    private fun batERow(): Line = row(
        gr("    "),
        if (etaMs > 0L) sp("~" + hm(etaMs) + (if (curCharging) " to full" else " left")) else gr("eta N/A"),
        gr("  "),
        sp(plugName(), Col.CYAN)
    )

    private fun ramRow(): Line {
        val rr = if (ramTotal > 0L) ramUsed.toFloat() / ramTotal else 0f
        val ramCol = if (rr < 0.70f) Col.GREEN else if (rr < 0.88f) Col.YELLOW else Col.RED
        return row(
            sp("RAM "),
            sp(f("%.1f/%.0fG %d%% ", ramUsed / gbF, ramTotal / gbF, (rr * 100).toInt()), ramCol),
            bars(ramHist.ordered(), ramCol, false)
        )
    }

    private fun swpRow(): Line = row(
        sp("SWP "),
        if (swapTotal >= 0L) sp(f("%.1f/%.1fG ", (swapTotal - swapFree) / gbF, swapTotal / gbF)) else gr("N/A "),
        gr("CCH "),
        if (cachedB >= 0L) sp(f("%.1fG", cachedB / gbF), Col.CYAN) else gr("N/A")
    )

    private fun dskRow(): Line {
        val dr = if (dskTotal > 0L) (dskTotal - dskFree).toFloat() / dskTotal else 0f
        val dc = if (dr < 0.75f) Col.GREEN else if (dr < 0.90f) Col.YELLOW else Col.RED
        return row(
            sp("DSK "),
            sp(f("%.0f/%.0fG %d%%", (dskTotal - dskFree) / gbF, dskTotal / gbF, (dr * 100).toInt()), dc)
        )
    }

    private fun netRow(): Line {
        val n = ArrayList<Span>()
        n += sp("NET ")
        when (netType) {
            "OFF" -> n += sp("offline", Col.RED)
            "WiFi" -> {
                val std = when (wifiStd) { 4 -> "WiFi4"; 5 -> "WiFi5"; 6 -> "WiFi6"; 7 -> "WiFi7"; else -> "WiFi" }
                n += sp("$std ", Col.CYAN)
                if (band.isNotEmpty()) n += sp("$band ", Col.CYAN)
                if (rssi != Int.MIN_VALUE && rssi > -127) n += sp("${rssi}dBm ", if (rssi >= -60) Col.GREEN else if (rssi >= -75) Col.YELLOW else Col.RED)
                if (linkMbps > 0) n += sp("${linkMbps}M")
            }
            "Cell" -> {
                n += sp("Cell ", Col.BLUE)
                n += if (cellSig != Int.MIN_VALUE) sp("sig $cellSig") else gr("sig N/A")
            }
            else -> n += sp(netType, Col.CYAN)
        }
        return n
    }

    private fun ssidWhy(): String {
        val perm = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!perm) return "no location perm"
        val on = try { if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled else true } catch (e: Exception) { true }
        if (!on) return "location is off"
        return "hidden by OS"
    }

    private fun apRow(): Line = when (netType) {
        "WiFi" -> if (ssid.isNotEmpty()) row(gr("AP  "), sp(ssid.take(30), Col.CYAN))
        else row(gr("AP  "), gr("N/A (" + ssidWhy() + ")"))
        "Cell" -> row(gr("OP  "), if (opName.isNotEmpty()) sp(opName.take(30), Col.BLUE) else gr("N/A"))
        else -> row(gr("AP  "), gr("-"))
    }

    private fun scrRow(): Line = row(
        sp("SCR "),
        sp(if (hz > 0) "${hz}Hz " else "N/A ", Col.CYAN),
        sp(if (bri >= 0) "$bri%" else "N/A", Col.YELLOW),
        gr(if (briAuto) " auto " else " "),
        gr("lux "),
        if (lux >= 0f) sp(f("%.0f", lux), Col.YELLOW) else gr("N/A")
    )

    private fun sysRow(): Line {
        val d = upS / 86400L
        val hh = (upS % 86400L) / 3600L
        val mm = (upS % 3600L) / 60L
        return row(
            sp("SYS "), gr("up "),
            sp(if (d > 0) "${d}d${hh}h " else "${hh}h${mm}m ", Col.GREEN),
            gr("zzz "),
            if (zzz >= 0) sp("$zzz%", Col.CYAN) else gr("N/A")
        )
    }

    private fun flagsRow(): Line {
        fun onoff(label: String, v: Int) =
            listOf(gr("$label "), if (v != 0) sp("on ", Col.YELLOW) else gr("off "))
        return onoff("AIR", air) + onoff("DND", dnd) + onoff("PSV", psv)
    }

    private fun thmRow(): Line = row(
        gr("THM "),
        if (thm >= 0) sp(THERMAL.getOrElse(thm) { "?" } + " ", if (thm == 0) Col.GREEN else if (thm < 3) Col.YELLOW else Col.RED) else gr("N/A "),
        gr("VOL "),
        if (vol >= 0) sp("$vol%") else gr("N/A")
    )
}

/** يحاول قراءة GPU عبر root (su). لو الجهاز غير مروت يفشل بصمت ويظهر denied. */
class GpuRoot {
    @Volatile var freq = -1f
    @Volatile var util = -1f
    @Volatile var ok = false
    private var proc: Process? = null
    private var running = false
    private var gen = 0

    @Synchronized
    fun start() {
        if (running) return
        running = true
        val my = ++gen
        val t = Thread { loop(my) }
        t.isDaemon = true
        t.start()
    }

    @Synchronized
    fun stop() {
        running = false
        gen++
        proc?.destroy()
        proc = null
        freq = -1f
        util = -1f
    }

    @Synchronized
    private fun current(my: Int) = running && gen == my

    private fun loop(my: Int) {
        var p: Process? = null
        try {
            val cmd = "while true; do echo \"\$(cat /sys/kernel/ged/hal/current_freqency 2>/dev/null)|" +
                    "\$(cat /sys/kernel/ged/hal/gpu_utilization 2>/dev/null)\"; sleep 0.5; done"
            val np = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            p = np
            synchronized(this) {
                if (gen == my) proc = np else np.destroy()
            }
            val r = np.inputStream.bufferedReader()
            while (current(my)) {
                val line = r.readLine() ?: break
                parse(line)
            }
        } catch (e: Exception) {
        } finally {
            try { p?.destroy() } catch (e: Exception) { }
            synchronized(this) {
                if (gen == my) { running = false; proc = null }
            }
        }
    }

    private fun parse(line: String) {
        val parts = line.split("|")
        val fq = parts.getOrNull(0)?.trim()?.split(Regex("\\s+"))?.firstOrNull()?.toFloatOrNull()
        val ut = parts.getOrNull(1)?.trim()?.split(Regex("\\s+"))?.firstOrNull()?.toFloatOrNull()
        if (fq != null) {
            freq = when {
                fq > 1e7f -> fq / 1e6f
                fq > 1e4f -> fq / 1e3f
                else -> fq
            }
            ok = true
        }
        if (ut != null && ut in 0f..100f) {
            util = ut
            ok = true
        }
    }
}
