package com.sysmon.wallpaper

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.view.WindowManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

data class Span(val t: String, val c: Int)
typealias Line = List<Span>

object Col {
    val GREEN = 0xFF00E676.toInt()
    val YELLOW = 0xFFFFD600.toInt()
    val RED = 0xFFFF5252.toInt()
    val CYAN = 0xFF18FFFF.toInt()
    val BLUE = 0xFF448AFF.toInt()
    val GRAY = 0xFF8A8A8A.toInt()
    val WHITE = 0xFFEEEEEE.toInt()
}

/** يجمع معلومات الجهاز ويحوّلها لأسطر ملونة. كل قراءة محمية بـ try/catch فإذا فشلت تظهر N/A. */
class SysStats(private val ctx: Context) {

    companion object {
        const val KINDS = 5
    }

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    private val coreCount =
        (0..15).count { File("/sys/devices/system/cpu/cpu$it").exists() }.coerceAtLeast(1)
    private val maxFreq = LongArray(16)

    private var lastRx = 0L
    private var lastTx = 0L
    private var lastTs = 0L

    private val thermalPath: String? by lazy { findThermal() }

    fun build(kind: Int): Line = try {
        when (kind % KINDS) {
            0 -> cpu()
            1 -> bat()
            2 -> mem()
            3 -> net()
            else -> sys()
        }
    } catch (e: Exception) {
        listOf(Span("ERR ${e.javaClass.simpleName}", Col.RED))
    }

    // ---------- helpers ----------

    private fun readLong(path: String): Long? = try {
        File(path).readText().trim().toLongOrNull()
    } catch (e: Exception) {
        null
    }

    private fun ratioColor(r: Float) = when {
        r < 0.5f -> Col.GREEN
        r < 0.8f -> Col.YELLOW
        else -> Col.RED
    }

    private fun tempColor(t: Float, lo: Float, hi: Float) = when {
        t < lo -> Col.GREEN
        t < hi -> Col.YELLOW
        else -> Col.RED
    }

    private fun f(fmt: String, vararg a: Any) = String.format(Locale.US, fmt, *a)

    private fun stamp(): Span = Span(timeFmt.format(Date()) + " ", Col.GRAY)

    private fun battery(): Intent? =
        ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

    private fun batTemp(): Float? {
        val v = battery()?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        return if (v == null || v == Int.MIN_VALUE) null else v / 10f
    }

    private fun findThermal(): String? {
        val zones = File("/sys/class/thermal").listFiles { x -> x.name.startsWith("thermal_zone") }
            ?: return null
        val prefer = listOf("cpu", "soc", "tsens", "mtktscpu", "ap")
        for (z in zones.sortedBy { it.name }) {
            val type = try { File(z, "type").readText().trim() } catch (e: Exception) { continue }
            if (prefer.any { type.contains(it, ignoreCase = true) }) {
                val p = File(z, "temp").path
                if (readLong(p) != null) return p
            }
        }
        return null
    }

    private fun cpuTemp(): Float? {
        val p = thermalPath ?: return null
        val v = readLong(p) ?: return null
        val c = if (abs(v) > 1000) v / 1000f else v.toFloat()
        return if (c in 1f..120f) c else null
    }

    // ---------- lines ----------

    private fun cpu(): Line {
        val out = ArrayList<Span>()
        out += stamp()
        out += Span("CPU ", Col.WHITE)
        var sum = 0f
        var n = 0
        for (i in 0 until coreCount) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val cur = readLong(base + "scaling_cur_freq")
            if (maxFreq[i] == 0L) maxFreq[i] = readLong(base + "cpuinfo_max_freq") ?: 0L
            if (cur == null) {
                out += Span("--- ", Col.GRAY)
                continue
            }
            if (cur > maxFreq[i]) maxFreq[i] = cur
            val r = if (maxFreq[i] > 0) cur.toFloat() / maxFreq[i] else 0f
            sum += r
            n++
            out += Span(f("%.1f ", cur / 1_000_000f), ratioColor(r))
        }
        val load = if (n > 0) sum / n else 0f
        out += Span(f("~%d%% ", (load * 100).toInt()), ratioColor(load))
        val ct = cpuTemp()
        if (ct != null) {
            out += Span(f("%.0f°C", ct), tempColor(ct, 55f, 70f))
        } else {
            val bt = batTemp()
            out += if (bt != null) Span(f("b%.0f°C", bt), tempColor(bt, 38f, 43f))
            else Span("N/A", Col.GRAY)
        }
        return out
    }

    private fun bat(): Line {
        val it = battery()
        val level = it?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = it?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = it?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        val volt = it?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val bt = batTemp()

        val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val ma = when {
            raw == Int.MIN_VALUE || raw == 0 -> null
            abs(raw) > 20_000 -> raw / 1000   // µA -> mA
            else -> raw
        }

        val pctColor = when {
            charging -> Col.CYAN
            pct > 50 -> Col.GREEN
            pct > 20 -> Col.YELLOW
            else -> Col.RED
        }
        val out = ArrayList<Span>()
        out += stamp()
        out += Span("BAT ", Col.WHITE)
        out += Span(if (pct >= 0) "$pct% " else "N/A ", pctColor)
        out += if (bt != null) Span(f("%.1f°C ", bt), tempColor(bt, 38f, 43f)) else Span("N/A ", Col.GRAY)
        out += Span(if (volt > 0) f("%.2fV ", volt / 1000f) else "N/A ", Col.WHITE)
        out += Span(if (ma != null) f("%+dmA ", ma) else "N/A ", Col.WHITE)
        out += Span(if (charging) "CHG" else "DIS", if (charging) Col.CYAN else Col.GRAY)
        return out
    }

    private fun mem(): Line {
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val gb = 1024f * 1024f * 1024f
        val used = (mi.totalMem - mi.availMem).toFloat()
        val r = if (mi.totalMem > 0) used / mi.totalMem else 0f
        val ramColor = when {
            r < 0.70f -> Col.GREEN
            r < 0.88f -> Col.YELLOW
            else -> Col.RED
        }

        val out = ArrayList<Span>()
        out += stamp()
        out += Span("MEM ", Col.WHITE)
        out += Span(f("%.1f/%.0fG %d%% ", used / gb, mi.totalMem / gb, (r * 100).toInt()), ramColor)
        try {
            val st = StatFs(Environment.getDataDirectory().path)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBytes
            val dr = (total - free).toFloat() / total
            val dc = when {
                dr < 0.75f -> Col.GREEN
                dr < 0.90f -> Col.YELLOW
                else -> Col.RED
            }
            out += Span("DSK ", Col.WHITE)
            out += Span(f("%.0f/%.0fG", (total - free) / gb, total / gb), dc)
        } catch (e: Exception) {
            out += Span("DSK N/A", Col.GRAY)
        }
        return out
    }

    private fun speed(b: Float): String = when {
        b >= 1_048_576f -> f("%.1fMB/s", b / 1_048_576f)
        b >= 1024f -> f("%.0fKB/s", b / 1024f)
        else -> f("%.0fB/s", b)
    }

    private fun speedColor(b: Float) = when {
        b < 1_048_576f -> Col.GREEN
        b < 10_485_760f -> Col.YELLOW
        else -> Col.RED
    }

    private fun net(): Line {
        val now = SystemClock.elapsedRealtime()
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        var dl = 0f
        var ul = 0f
        if (lastTs > 0 && rx >= 0 && tx >= 0) {
            val dt = (now - lastTs) / 1000f
            if (dt > 0f) {
                dl = (rx - lastRx).coerceAtLeast(0) / dt
                ul = (tx - lastTx).coerceAtLeast(0) / dt
            }
        }
        lastRx = rx; lastTx = tx; lastTs = now

        val caps = try { cm.getNetworkCapabilities(cm.activeNetwork) } catch (e: Exception) { null }
        val (type, tc) = when {
            caps == null -> "OFFLINE" to Col.RED
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi" to Col.CYAN
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cell" to Col.BLUE
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Eth" to Col.CYAN
            else -> "Net" to Col.WHITE
        }
        val out = ArrayList<Span>()
        out += stamp()
        out += Span("NET ", Col.WHITE)
        out += Span("$type ", tc)
        out += Span("DL ", Col.GRAY)
        out += Span(speed(dl) + " ", speedColor(dl))
        out += Span("UL ", Col.GRAY)
        out += Span(speed(ul), speedColor(ul))
        return out
    }

    @Suppress("DEPRECATION")
    private fun sys(): Line {
        val out = ArrayList<Span>()
        out += stamp()
        out += Span("SYS ", Col.WHITE)

        val s = SystemClock.elapsedRealtime() / 1000
        val d = s / 86400
        val h = (s % 86400) / 3600
        val m = (s % 3600) / 60
        val up = if (d > 0) "${d}d${h}h${m}m" else "${h}h${m}m"
        out += Span("up ", Col.GRAY)
        out += Span("$up ", Col.GREEN)

        try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            out += Span(f("%.0fHz ", wm.defaultDisplay.refreshRate), Col.CYAN)
        } catch (e: Exception) {
            out += Span("--Hz ", Col.GRAY)
        }

        val br = try {
            Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, -1)
        } catch (e: Exception) { -1 }
        if (br >= 0) {
            out += Span("bri ", Col.GRAY)
            out += Span("${br * 100 / 255}% ", Col.YELLOW)
        }

        val health = battery()?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0) ?: 0
        val (ht, hc) = when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "good" to Col.GREEN
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "hot" to Col.RED
            BatteryManager.BATTERY_HEALTH_COLD -> "cold" to Col.BLUE
            BatteryManager.BATTERY_HEALTH_DEAD -> "dead" to Col.RED
            else -> "?" to Col.GRAY
        }
        out += Span("hp:", Col.GRAY)
        out += Span(ht, hc)
        return out
    }
}
