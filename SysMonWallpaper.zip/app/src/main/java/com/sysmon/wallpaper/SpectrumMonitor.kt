package com.sysmon.wallpaper

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max

/**
 * طيف الصوت الخارج من الجهاز كله (موسيقى، إشعارات...) عبر Visualizer على المزيج العام.
 * يحتاج RECORD_AUDIO كبوابة أمان من أندرويد فقط؛ لا يُسجَّل شيء.
 */
class SpectrumMonitor(private val ctx: Context, private val prefs: SharedPreferences) {

    @Volatile var ok = false
    @Volatile var err = ""
    @Volatile var active = false
    @Volatile var rmsDb = -90f
    @Volatile var peakDb = -90f
    @Volatile private var blocked = false
    @Volatile private var paused = false
    @Volatile private var lastFft: ByteArray? = null
    @Volatile private var lastRate = 0

    private var viz: Visualizer? = null
    private var cur = FloatArray(0)
    private var pk = FloatArray(0)
    private var lastUpd = 0L
    private var lastSignal = 0L
    private var everSignal = false
    private var musicSince = 0L

    private val listener = object : Visualizer.OnDataCaptureListener {
        override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
            if (waveform == null || waveform.isEmpty()) return
            var sum = 0.0
            var pkv = 0
            for (b in waveform) {
                val s = (b.toInt() and 0xFF) - 128
                sum += (s * s).toDouble()
                if (abs(s) > pkv) pkv = abs(s)
            }
            val rms = Math.sqrt(sum / waveform.size) / 128.0
            rmsDb = if (rms < 1e-5) -90f else (20.0 * log10(rms)).toFloat()
            peakDb = if (pkv == 0) -90f else (20.0 * log10(pkv / 128.0)).toFloat()
        }

        override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
            if (fft != null) {
                lastFft = fft.copyOf()
                lastRate = samplingRate
            }
        }
    }

    fun hasPerm(): Boolean =
        ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    @Synchronized
    fun ensure() {
        if (paused || viz != null) return
        if (!hasPerm()) {
            err = "no permission"
            return
        }
        try {
            val v = Visualizer(0)
            v.enabled = false
            val r = Visualizer.getCaptureSizeRange()
            v.captureSize = r[1]
            v.setDataCaptureListener(listener, Visualizer.getMaxCaptureRate(), true, true)
            v.enabled = true
            viz = v
            ok = true
            err = ""
        } catch (e: Throwable) {
            ok = false
            err = e.javaClass.simpleName
        }
    }

    @Synchronized
    private fun release() {
        try { viz?.enabled = false } catch (e: Throwable) { }
        try { viz?.release() } catch (e: Throwable) { }
        viz = null
        ok = false
        active = false
    }

    fun pause() { paused = true; release() }
    fun stop() { paused = true; release() }
    fun resume() { paused = false; ensure() }

    fun statusText(): String = when {
        !hasPerm() -> "no RECORD_AUDIO permission"
        !ok -> "init failed" + (if (err.isNotEmpty()) " ($err)" else "")
        blocked -> "silent? (OS may block capture)"
        active -> "live"
        else -> "idle"
    }

    /** يُستدعى كل نبضة: يحوّل FFT إلى نطاقات ويسلّسها. */
    fun update(now: Long, musicActive: Boolean) {
        val st = Graphs.get(prefs, "spec")
        val bands = st.count
        if (cur.size != bands) {
            cur = FloatArray(bands)
            pk = FloatArray(bands)
        }
        val dt = (now - lastUpd).coerceIn(1L, 500L)
        lastUpd = now
        if (!ok) {
            active = false
            return
        }
        val gain = prefs.getFloat("sp_gain", 1.0f)
        val att = prefs.getFloat("sp_att", 0.6f)
        val rel = prefs.getFloat("sp_rel", 0.12f)
        val tilt = prefs.getFloat("sp_tilt", 0.5f)
        val fmin = prefs.getInt("sp_fmin", 40).coerceAtLeast(10).toFloat()
        val fmax = prefs.getInt("sp_fmax", 16000).coerceAtLeast(fmin.toInt() + 100).toFloat()

        val target = FloatArray(bands)
        val fft = lastFft
        val rate = lastRate
        if (fft != null && fft.size >= 8 && rate > 0) {
            val n = fft.size
            val half = n / 2
            val binHz = rate / 1000f / n
            val ratio = (fmax / fmin).toDouble()
            for (i in 0 until bands) {
                val f0 = fmin * Math.pow(ratio, i.toDouble() / bands).toFloat()
                val f1 = fmin * Math.pow(ratio, (i + 1).toDouble() / bands).toFloat()
                var k0 = Math.round(f0 / binHz)
                if (k0 < 1) k0 = 1
                var k1 = (f1 / binHz).toInt()
                if (k1 < k0) k1 = k0
                if (k1 > half - 1) k1 = half - 1
                if (k0 > k1) k0 = k1
                var m = 0f
                for (k in k0..k1) {
                    val re = fft[2 * k].toInt()
                    val im = fft[2 * k + 1].toInt()
                    val mag = Math.sqrt((re * re + im * im).toDouble()).toFloat()
                    if (mag > m) m = mag
                }
                val db = 20f * log10(max(m, 1f) / 128f)
                var v = ((db + 42f) / 42f).coerceIn(0f, 1.3f) * 100f * gain
                v *= 1f + tilt * (i.toFloat() / max(1, bands - 1))
                target[i] = v.coerceIn(0f, 100f)
            }
        }

        val ka = 1f - Math.pow((1.0 - att).coerceIn(0.0, 0.999), dt / 40.0).toFloat()
        val kr = 1f - Math.pow((1.0 - rel).coerceIn(0.0, 0.999), dt / 40.0).toFloat()
        var mx = 0f
        for (i in 0 until bands) {
            val t = target[i]
            cur[i] += (t - cur[i]) * (if (t > cur[i]) ka else kr)
            pk[i] = max(cur[i], pk[i] - 0.06f * dt)
            if (cur[i] > mx) mx = cur[i]
        }
        if (mx > 4f) {
            lastSignal = now
            everSignal = true
        }
        active = lastSignal > 0L && now - lastSignal < 1500L
        if (musicActive) {
            if (musicSince == 0L) musicSince = now
        } else {
            musicSince = 0L
        }
        blocked = !everSignal && musicSince != 0L && now - musicSince > 4000L
    }

    fun values(n: Int): FloatArray {
        if (!ok) return FloatArray(n) { Float.NaN }
        return if (cur.size == n) cur.copyOf() else FloatArray(n)
    }

    fun peaks(n: Int): FloatArray? = if (ok && pk.size == n) pk.copyOf() else null
}
