package com.sysmon.wallpaper

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build

class BtDev(val addr: String, val name: String, val kinds: String, val battery: Int)

/** يقرأ حالة البلوتوث والأجهزة المتصلة وبطاريتها (إن توفرت). يحتاج صلاحية الأجهزة القريبة. */
class BtMonitor(private val ctx: Context) {

    @Volatile var permOk = false
    @Volatile var on: Boolean? = null
    @Volatile var paired = -1
    @Volatile var devices: List<BtDev> = emptyList()

    private val mgr = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val adapter: BluetoothAdapter? = mgr?.adapter
    private val proxies = HashMap<Int, BluetoothProfile>()
    private val battCache = HashMap<String, Int>()
    private var inited = false
    @Volatile private var stopped = false
    private var rcv: BroadcastReceiver? = null

    fun hasPerm(): Boolean =
        if (Build.VERSION.SDK_INT >= 31)
            ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        else true

    @Suppress("DEPRECATION")
    private fun devOf(i: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    private fun ensureInit() {
        val a = adapter ?: return
        if (inited || stopped) return
        inited = true
        for (p in intArrayOf(BluetoothProfile.A2DP, BluetoothProfile.HEADSET)) {
            try {
                a.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
                    override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                        synchronized(proxies) { proxies[profile] = proxy }
                    }
                    override fun onServiceDisconnected(profile: Int) {
                        synchronized(proxies) { proxies.remove(profile) }
                    }
                }, p)
            } catch (e: Exception) { }
        }
        try {
            val r = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    val d = devOf(i)
                    val lv = i.getIntExtra("android.bluetooth.device.extra.BATTERY_LEVEL", -1)
                    if (d != null && lv in 0..100) synchronized(battCache) { battCache[d.address] = lv }
                }
            }
            val f = IntentFilter("android.bluetooth.device.action.BATTERY_LEVEL_CHANGED")
            if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(r, f, Context.RECEIVER_EXPORTED)
            else ctx.registerReceiver(r, f)
            rcv = r
        } catch (e: Exception) { }
    }

    private fun nameOf(d: BluetoothDevice): String = try {
        (if (Build.VERSION.SDK_INT >= 30) d.alias else null) ?: d.name ?: d.address
    } catch (e: Exception) {
        d.address
    }

    /** البطارية: أولاً دالة النظام المخفية، وإلا آخر قيمة وصلت من بث النظام، وإلا -1. */
    private fun battery(d: BluetoothDevice): Int {
        try {
            val v = d.javaClass.getMethod("getBatteryLevel").invoke(d) as Int
            if (v in 0..100) return v
        } catch (e: Throwable) { }
        return synchronized(battCache) { battCache[d.address] } ?: -1
    }

    fun refresh() {
        permOk = hasPerm()
        val a = adapter
        if (!permOk || a == null) {
            on = null; devices = emptyList(); paired = -1
            return
        }
        ensureInit()
        on = try { a.isEnabled } catch (e: Exception) { null }
        paired = try { a.bondedDevices?.size ?: 0 } catch (e: Exception) { -1 }
        if (on != true) { devices = emptyList(); return }

        val map = LinkedHashMap<String, BluetoothDevice>()
        val kinds = HashMap<String, MutableList<String>>()
        fun add(d: BluetoothDevice, k: String) {
            map.putIfAbsent(d.address, d)
            kinds.getOrPut(d.address) { ArrayList() }.add(k)
        }
        synchronized(proxies) {
            for ((prof, px) in proxies) {
                val label = when (prof) {
                    BluetoothProfile.A2DP -> "A2DP"
                    BluetoothProfile.HEADSET -> "HFP"
                    else -> "?"
                }
                try { for (d in px.connectedDevices) add(d, label) } catch (e: Exception) { }
            }
        }
        try { mgr?.getConnectedDevices(BluetoothProfile.GATT)?.forEach { add(it, "GATT") } } catch (e: Exception) { }
        devices = map.values.map { d ->
            BtDev(d.address, nameOf(d), kinds[d.address]?.joinToString("/") ?: "", battery(d))
        }
    }

    fun stop() {
        try {
            synchronized(proxies) {
                for ((p, px) in proxies) adapter?.closeProfileProxy(p, px)
                proxies.clear()
            }
            rcv?.let { ctx.unregisterReceiver(it) }
        } catch (e: Exception) { }
        rcv = null
        inited = false
        stopped = true
    }
}
