package com.sysmon.wallpaper

import android.content.SharedPreferences

/** تحويل الإعدادات إلى نص وتطبيق النص (للاستيراد والتصدير والملفات الشخصية). */
object SettingsIO {
    const val HEADER = "SYSMON1"

    fun toText(p: SharedPreferences): String {
        val sb = StringBuilder(HEADER).append('\n')
        for (e in p.all.entries.sortedBy { it.key }) {
            val k = e.key
            val v = e.value ?: continue
            if (k == "defaults_v") continue
            val t = when (v) {
                is Boolean -> "b"
                is Int -> "i"
                is Long -> "l"
                is Float -> "f"
                is String -> "s"
                else -> continue
            }
            sb.append(k).append('|').append(t).append('|')
                .append(java.net.URLEncoder.encode(v.toString(), "UTF-8")).append('\n')
        }
        return sb.toString()
    }

    /** يرجع عدد المفاتيح المطبقة، أو -1 إذا النص ليس إعدادات صالحة. replace يمسح الحالي أولاً. */
    fun apply(p: SharedPreferences, textIn: String, replace: Boolean): Int {
        val text = textIn.replace("\r", "")
        val i = text.indexOf(HEADER)
        if (i < 0) return -1
        val e = p.edit()
        if (replace) e.clear()
        var n = 0
        for (raw in text.substring(i + HEADER.length).lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            val parts = line.split("|")
            if (parts.size < 3) continue
            val key = parts[0].trim()
            val type = parts[1].trim()
            if (key.isEmpty()) continue
            val v = try {
                java.net.URLDecoder.decode(parts.drop(2).joinToString("|"), "UTF-8")
            } catch (ex: Exception) {
                continue
            }
            when (type) {
                "b" -> e.putBoolean(key, v == "true")
                "i" -> { val x = v.toIntOrNull() ?: continue; e.putInt(key, x) }
                "l" -> { val x = v.toLongOrNull() ?: continue; e.putLong(key, x) }
                "f" -> { val x = v.toFloatOrNull() ?: continue; e.putFloat(key, x) }
                "s" -> e.putString(key, v)
                else -> continue
            }
            n++
        }
        e.apply()
        return n
    }

    fun loadDefaults(p: SharedPreferences) {
        apply(p, DefaultProfile.TEXT, true)
        p.edit().putInt("defaults_v", 1).apply()
    }

    fun count(text: String): Int = text.lineSequence().count { it.split("|").size >= 3 }
}
