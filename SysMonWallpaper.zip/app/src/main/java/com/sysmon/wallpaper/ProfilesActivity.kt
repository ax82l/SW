package com.sysmon.wallpaper

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** ملفات إعدادات محفوظة داخل التطبيق + استيراد/تصدير بالنص أو بالملفات. */
class ProfilesActivity : Activity() {

    private lateinit var p: SharedPreferences
    private lateinit var store: SharedPreferences
    private lateinit var scroll: ScrollView
    private lateinit var col: LinearLayout

    private val reqExport = 11
    private val reqImport = 12

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        t.setPadding(0, dp(8), 0, dp(2))
        return t
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun btn(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs.of(this)
        store = getSharedPreferences("sysmon_profiles", Context.MODE_PRIVATE)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(32), dp(16), dp(32))
        scroll.addView(col)
        setContentView(scroll)
        render()
    }

    private fun render() {
        col.removeAllViews()
        col.addView(tv("ax82l@phone:~\$ sysmon --profiles", 15f, Col.GREEN, true))
        col.addView(tv("profiles live inside the app (they are removed if you uninstall it)", 11f, Col.GRAY))

        col.addView(btn("Save current settings as a new profile...") {
            askText("Profile name", "e.g. gaming", "", false, "Save") { name ->
                val n = name.trim()
                if (n.isEmpty()) toast("Name is empty")
                else {
                    store.edit().putString(n, SettingsIO.toText(p)).apply()
                    toast("Saved profile: $n")
                    render()
                }
            }
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })

        col.addView(tv("Built-in", 14f, Col.CYAN, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        col.addView(btn("Load author default (replaces all)") {
            confirm("Replace all current settings with the author default?") {
                SettingsIO.loadDefaults(p)
                toast("Default settings loaded")
            }
        })

        col.addView(tv("Saved profiles", 14f, Col.CYAN, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        val names = store.all.keys.sorted()
        if (names.isEmpty()) col.addView(tv("none yet", 12f, Col.GRAY))
        for (name in names) {
            val text = store.getString(name, "") ?: ""
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))
            row.addView(tv(name, 14f, Col.WHITE, true))
            row.addView(tv(SettingsIO.count(text).toString() + " settings  |  tap for options", 11f, Col.GRAY))
            row.setOnClickListener { profileMenu(name, text) }
            col.addView(row)
        }

        col.addView(tv("Import / export", 14f, Col.CYAN, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        col.addView(btn("Import from pasted text...") {
            askText("Paste settings text", "paste here (starts with SYSMON1)", "", true, "Next") { txt -> chooseMode(txt) }
        })
        col.addView(btn("Import from a file...") { importFile() })
        col.addView(btn("Export current settings to a file...") { exportFile() })
        col.addView(btn("Copy current settings text") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("sysmon", SettingsIO.toText(p)))
            toast("Copied")
        })
    }

    private fun profileMenu(name: String, text: String) {
        val items = arrayOf(
            "Load (replace all)", "Merge into current", "Overwrite with current settings",
            "Rename", "Copy text", "Delete"
        )
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> confirm("Replace all current settings with \"$name\"?") {
                        val n = SettingsIO.apply(p, text, true)
                        toast(if (n < 0) "Profile is damaged" else "Loaded $n settings")
                    }
                    1 -> {
                        val n = SettingsIO.apply(p, text, false)
                        toast(if (n < 0) "Profile is damaged" else "Merged $n settings")
                    }
                    2 -> confirm("Overwrite \"$name\" with the current settings?") {
                        store.edit().putString(name, SettingsIO.toText(p)).apply()
                        toast("Updated")
                        render()
                    }
                    3 -> askText("New name", "", name, false, "Rename") { nn ->
                        val n2 = nn.trim()
                        if (n2.isNotEmpty() && n2 != name) {
                            store.edit().remove(name).putString(n2, text).apply()
                            render()
                        }
                    }
                    4 -> {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("sysmon", text))
                        toast("Copied")
                    }
                    5 -> confirm("Delete \"$name\"?") {
                        store.edit().remove(name).apply()
                        render()
                    }
                    else -> { }
                }
            }
            .show()
    }

    private fun chooseMode(text: String) {
        if (!text.contains(SettingsIO.HEADER)) {
            toast("Not a SysMon settings text (it must contain SYSMON1)")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Apply " + SettingsIO.count(text) + " settings")
            .setMessage("Merge keeps your other settings. Replace all starts from the imported text only.")
            .setPositiveButton("Merge") { _, _ ->
                val n = SettingsIO.apply(p, text, false)
                toast("Merged $n settings")
            }
            .setNeutralButton("Replace all") { _, _ ->
                val n = SettingsIO.apply(p, text, true)
                toast("Loaded $n settings")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirm(msg: String, onYes: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(msg)
            .setPositiveButton("Yes") { _, _ -> onYes() }
            .setNegativeButton("No", null)
            .show()
    }

    private fun askText(
        title: String, hint: String, initial: String, multiline: Boolean, okLabel: String, onOk: (String) -> Unit
    ) {
        val et = EditText(this)
        et.hint = hint
        et.setText(initial)
        et.typeface = Typeface.MONOSPACE
        et.textSize = 13f
        if (multiline) {
            et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            et.minLines = 6
            et.maxLines = 12
            et.gravity = Gravity.TOP
        } else {
            et.inputType = InputType.TYPE_CLASS_TEXT
            et.setSingleLine(true)
        }
        val box = LinearLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), dp(0))
        box.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(okLabel) { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun exportFile() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TITLE, "sysmon-settings.txt")
        try { startActivityForResult(i, reqExport) } catch (e: Exception) { toast("No file picker available") }
    }

    private fun importFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        try { startActivityForResult(i, reqImport) } catch (e: Exception) { toast("No file picker available") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        try {
            if (requestCode == reqExport) {
                contentResolver.openOutputStream(uri)?.use { it.write(SettingsIO.toText(p).toByteArray(Charsets.UTF_8)) }
                toast("Saved")
            } else if (requestCode == reqImport) {
                val txt = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                chooseMode(txt)
            }
        } catch (e: Exception) {
            toast("File error: " + e.javaClass.simpleName)
        }
    }
}
