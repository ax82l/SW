package com.sysmon.wallpaper

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object ColorDialog {
    private val palette = listOf(
        0xFF00E676.toInt() to "Green", 0xFFFFD600.toInt() to "Yellow", 0xFFFF5252.toInt() to "Red", 0xFF18FFFF.toInt() to "Cyan",
        0xFF448AFF.toInt() to "Blue", 0xFFEEEEEE.toInt() to "White", 0xFFFF9100.toInt() to "Orange", 0xFFFF4081.toInt() to "Pink",
        0xFFB388FF.toInt() to "Purple", 0xFFC6FF00.toInt() to "Lime", 0xFF8A8A8A.toInt() to "Gray", 0xFF000000.toInt() to "Black",
        0xFF1A1A1A.toInt() to "Dark", 0xFF0A1128.toInt() to "Navy", 0xFF1B2A1B.toInt() to "Forest", 0xFFFFFFFF.toInt() to "Paper"
    )

    /** autoLabel != null يضيف خيار "تلقائي" (القيمة 0). */
    fun show(ctx: Context, title: String, autoLabel: String?, onPick: (Int) -> Unit) {
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val dlg = AlertDialog.Builder(ctx).setTitle(title).setView(box).setNegativeButton("Cancel", null).create()

        val items = ArrayList<Pair<Int, String>>()
        if (autoLabel != null) items.add(0 to autoLabel)
        items.addAll(palette)

        var rowL: LinearLayout? = null
        for ((i, pc) in items.withIndex()) {
            if (i % 4 == 0) {
                rowL = LinearLayout(ctx)
                rowL.orientation = LinearLayout.HORIZONTAL
                box.addView(rowL)
            }
            val sq = TextView(ctx)
            sq.text = pc.second
            sq.textSize = 11f
            sq.gravity = Gravity.CENTER
            sq.setPadding(0, dp(14), 0, dp(14))
            if (pc.first == 0) {
                sq.setBackgroundColor(0xFF333333.toInt())
                sq.setTextColor(Color.WHITE)
            } else {
                sq.setBackgroundColor(pc.first)
                sq.setTextColor(if (Contrast.lum(pc.first) > 0.4f) Color.BLACK else Color.WHITE)
            }
            sq.setOnClickListener { dlg.dismiss(); onPick(pc.first) }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            rowL!!.addView(sq, lp)
        }

        val hex = EditText(ctx)
        hex.hint = "custom hex, e.g. FF8800"
        hex.setTextColor(Color.WHITE)
        hex.setHintTextColor(0xFF8A8A8A.toInt())
        hex.typeface = Typeface.MONOSPACE
        box.addView(hex)
        val apply = Button(ctx)
        apply.text = "Apply custom color"
        apply.isAllCaps = false
        apply.setOnClickListener {
            try {
                val c = Color.parseColor("#" + hex.text.toString().trim().removePrefix("#"))
                dlg.dismiss()
                onPick(c or 0xFF000000.toInt())
            } catch (e: Exception) {
                hex.error = "invalid"
            }
        }
        box.addView(apply)
        dlg.show()
    }
}
