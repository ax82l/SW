package com.sysmon.wallpaper

import android.content.SharedPreferences

class Theme(
    val name: String, val bg: Int, val low: Int, val mid: Int, val high: Int,
    val accent: Int, val text: Int
)

object Themes {
    val all = listOf(
        Theme("Classic", 0xFF000000.toInt(), 0xFF00E676.toInt(), 0xFFFFD600.toInt(), 0xFFFF5252.toInt(), 0xFF00E676.toInt(), 0xFFEEEEEE.toInt()),
        Theme("Matrix", 0xFF000000.toInt(), 0xFF00FF41.toInt(), 0xFF8BFF4D.toInt(), 0xFFE8FF3D.toInt(), 0xFF00FF41.toInt(), 0xFFB8FFB8.toInt()),
        Theme("Amber", 0xFF0B0700.toInt(), 0xFFFFB000.toInt(), 0xFFFF8000.toInt(), 0xFFFF3D00.toInt(), 0xFFFFB000.toInt(), 0xFFFFD27F.toInt()),
        Theme("Ice", 0xFF05080F.toInt(), 0xFF4FC3F7.toInt(), 0xFF81D4FA.toInt(), 0xFFFFFFFF.toInt(), 0xFF4FC3F7.toInt(), 0xFFE1F5FE.toInt()),
        Theme("Mono", 0xFF000000.toInt(), 0xFF8A8A8A.toInt(), 0xFFCCCCCC.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFDDDDDD.toInt())
    )

    /** يضبط الخلفية وألوان سطر الأوامر ومحطات ألوان كل الرسوم. */
    fun apply(p: SharedPreferences, t: Theme) {
        val e = p.edit()
        e.putInt(Prefs.BG, t.bg)
        for ((n, _, _) in Prefs.PROMPT) {
            val c = when (n) {
                "user", "at", "host" -> t.accent
                "path" -> t.mid
                else -> t.text
            }
            e.putInt("ps_c_$n", c)
        }
        e.putInt(Prefs.P_CUR_COL, t.text)
        e.apply()
        for (def in Graphs.all) {
            val s = Graphs.get(p, def.id).copy()
            for ((i, st) in s.stops.withIndex()) {
                st.color = when {
                    s.stops.size == 1 -> if (def.id == "ul") t.mid else t.low
                    i == 0 -> t.low
                    i == 1 -> t.mid
                    else -> t.high
                }
            }
            Graphs.save(p, def.id, s)
        }
    }
}
