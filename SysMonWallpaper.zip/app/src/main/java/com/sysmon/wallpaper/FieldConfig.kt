package com.sysmon.wallpaper

import android.content.SharedPreferences

/** حقل داخل سطر (مثلاً نسبة البطارية داخل سطر BAT). numeric = له قيمة رقمية تصلح لشروط (أكبر/أصغر). */
class FieldDef(val id: String, val label: String, val numeric: Boolean = false, val defRules: String = "")

/** شرط لون: cond = ge / gt / le / lt (على قيمة الحقل) أو chg / dis (حسب الشحن). */
class Rule(var cond: String, var v: Float, var color: Int)

object Fields {
    private fun f(id: String, label: String, numeric: Boolean = false, def: String = "") = FieldDef(id, label, numeric, def)

    // القاعدة الافتراضية لنسبة البطارية = نفس السلوك الحالي (شحن أصفر، 20 وأقل أحمر، 50 وأقل أصفر، غير ذلك أخضر)
    private val BAT_PCT = "chg:0:" + Col.YELLOW + ";le:20:" + Col.RED + ";le:50:" + Col.YELLOW + ";ge:0:" + Col.GREEN
    private val DSK_PCT = "ge:90:" + Col.RED + ";ge:75:" + Col.YELLOW + ";ge:0:" + Col.GREEN

    val all: Map<String, List<FieldDef>> = mapOf(
        "cpu" to listOf(f("lbl", "label (CPU)"), f("ld", "load %", true), f("f", "frequency %", true),
            f("gld", "load graph"), f("gt", "temperature graph"), f("tmp", "temperature", true)),
        "cores" to listOf(f("lbl", "core name (C0)"), f("cl", "cluster name"), f("fq", "frequency (GHz)", true),
            f("gf", "frequency graph"), f("gl", "load graph"), f("ld", "load %", true)),
        "gpu" to listOf(f("lbl", "label (GPU)"), f("mhz", "frequency (MHz)", true), f("ld", "load %", true)),
        "ldv" to listOf(f("lbl", "label (LDV)"), f("val", "load average values")),
        "ram" to listOf(f("lbl", "label (RAM)"), f("gb", "used / total GB", true), f("mb", "used MB"),
            f("pct", "percent", true), f("g", "graph")),
        "swp" to listOf(f("lbl", "label (SWP)"), f("sw", "swap used / total"), f("swmb", "swap MB"), f("cch", "cached")),
        "dsk" to listOf(f("lbl", "label (DSK)"), f("gb", "used / total GB", true), f("mb", "used MB"),
            f("pct", "percent", true, DSK_PCT)),
        "bat" to listOf(f("lbl", "label (BAT)"), f("pct", "percent", true, BAT_PCT),
            f("state", "state tag (CHG / DIS / FULL)"), f("mah", "charge mAh")),
        "batv" to listOf(f("v", "voltage", true), f("cyc", "cycles", true), f("hp", "health")),
        "batt" to listOf(f("ma", "current (mA + graph)", true), f("w", "power (W + graph)", true),
            f("t", "temperature (+ graph)", true)),
        "bate" to listOf(f("eta", "time left / to full"), f("plug", "charger type")),
        "kern" to listOf(f("lbl", "label (K)"), f("ver", "kernel version")),
        "os" to listOf(f("lbl", "label (OS)"), f("ver", "Android version"), f("patch", "security patch")),
        "bt" to listOf(f("lbl", "label (BT)"), f("st", "state (on / off)"), f("pair", "paired count"),
            f("conn", "connected count", true), f("dev", "device name"), f("dbat", "device battery %", true),
            f("kinds", "device kind")),
        "net" to listOf(f("lbl", "label (NET)"), f("type", "type (WiFi / Cell / offline)"), f("band", "band"),
            f("rssi", "signal dBm", true), f("mbps", "link speed")),
        "ap" to listOf(f("lbl", "label (AP / OP)"), f("name", "name")),
        "hs" to listOf(f("lbl", "label (HS)"), f("st", "state"), f("method", "detect method")),
        "dl" to listOf(f("lbl", "label (DL)"), f("g", "graph"), f("spd", "speed", true)),
        "ul" to listOf(f("lbl", "label (UL)"), f("g", "graph"), f("spd", "speed", true)),
        "rxtx" to listOf(f("rx", "RX total"), f("tx", "TX total"), f("ip", "IP address")),
        "scr" to listOf(f("lbl", "label (SCR)"), f("hz", "refresh rate", true), f("bri", "brightness %", true),
            f("auto", "auto tag"), f("lux", "lux", true)),
        "sys" to listOf(f("lbl", "label (SYS)"), f("up", "uptime"), f("zzz", "deep sleep %", true)),
        "flags" to listOf(f("air", "airplane", true), f("dnd", "do not disturb", true), f("psv", "battery saver", true)),
        "pwr" to listOf(f("lbl", "label (PWR)"), f("mode", "mode name (0 bal, 1 perf, 2 saver, 3 ultra)", true)),
        "thm" to listOf(f("lbl", "label (THM)"), f("st", "status", true)),
        "clk" to listOf(f("lbl", "label (CLK)"), f("time", "time"), f("date", "date")),
        "fls" to listOf(f("lbl", "label (FLS)"), f("st", "state")),
        "prv" to listOf(f("lbl", "label (PRV)"), f("mic", "microphone"), f("cam", "camera"), f("gps", "GPS")),
        "snd" to listOf(f("lbl", "label (SND)"), f("st", "play state"), f("out", "output device"), f("ring", "ringer mode"),
            f("med", "media volume", true), f("rng", "ring volume", true), f("alm", "alarm volume", true),
            f("ntf", "notification volume", true), f("lvl", "level dB", true), f("pk", "peak dB"))
    )

    fun of(block: String): List<FieldDef> = all[block] ?: emptyList()
    fun def(block: String, fid: String): FieldDef? = of(block).firstOrNull { it.id == fid }
}

/** ألوان الحقول المشروطة + إخفاء الحقول (كلها محفوظة في الإعدادات). */
object FieldCfg {
    private const val KEY_HIDE = "fh"
    private fun rkey(block: String, fid: String) = "fr_$block.$fid"

    // ---------- إخفاء ----------
    private var hideRaw: String? = "\u0000"
    private var hideSet: Set<String> = emptySet()

    @Synchronized
    fun hidden(p: SharedPreferences, block: String, fid: String): Boolean {
        val raw = p.getString(KEY_HIDE, "") ?: ""
        if (raw != hideRaw) {
            hideRaw = raw
            hideSet = raw.split(",").filter { it.isNotEmpty() }.toSet()
        }
        return hideSet.contains("$block.$fid")
    }

    fun hiddenAny(p: SharedPreferences): Boolean = !(p.getString(KEY_HIDE, "") ?: "").isEmpty()

    fun setHidden(p: SharedPreferences, block: String, fid: String, hide: Boolean) {
        val cur = (p.getString(KEY_HIDE, "") ?: "").split(",").filter { it.isNotEmpty() }.toMutableSet()
        if (hide) cur.add("$block.$fid") else cur.remove("$block.$fid")
        p.edit().putString(KEY_HIDE, cur.joinToString(",")).apply()
    }

    // ---------- قواعد الألوان ----------
    private val cache = HashMap<String, Pair<String?, List<Rule>>>()

    private fun parse(raw: String): List<Rule> {
        val out = ArrayList<Rule>()
        for (part in raw.split(";")) {
            val f = part.split(":")
            if (f.size < 3) continue
            val v = f[1].toFloatOrNull() ?: continue
            val c = f[2].toIntOrNull() ?: continue
            out.add(Rule(f[0], v, c))
        }
        return out
    }

    fun ser(rules: List<Rule>): String = rules.joinToString(";") { it.cond + ":" + it.v + ":" + it.color }

    /** القواعد الفعلية: المحفوظة، أو الافتراضية للحقل، أو فارغة (يعني يبقى اللون التلقائي). */
    @Synchronized
    fun rules(p: SharedPreferences, block: String, fid: String): List<Rule> {
        val k = rkey(block, fid)
        val saved = p.getString(k, null)
        val raw = saved ?: Fields.def(block, fid)?.defRules ?: ""
        val c = cache[k]
        if (c != null && c.first == raw) return c.second
        val r = if (raw.isEmpty()) emptyList() else parse(raw)
        cache[k] = Pair(raw, r)
        return r
    }

    fun isCustom(p: SharedPreferences, block: String, fid: String): Boolean = p.getString(rkey(block, fid), null) != null

    fun save(p: SharedPreferences, block: String, fid: String, rules: List<Rule>) {
        p.edit().putString(rkey(block, fid), ser(rules)).apply()
    }

    fun reset(p: SharedPreferences, block: String, fid: String) {
        p.edit().remove(rkey(block, fid)).apply()
    }

    /** أول قاعدة تنطبق تعطي لونها، وإلا 0 (يبقى اللون التلقائي). */
    fun pick(rules: List<Rule>, num: Float, charging: Boolean): Int {
        for (r in rules) {
            val ok = when (r.cond) {
                "chg" -> charging
                "dis" -> !charging
                "ge" -> !num.isNaN() && num >= r.v
                "gt" -> !num.isNaN() && num > r.v
                "le" -> !num.isNaN() && num <= r.v
                "lt" -> !num.isNaN() && num < r.v
                else -> false
            }
            if (ok) return r.color
        }
        return 0
    }

    fun condLabel(r: Rule): String = when (r.cond) {
        "chg" -> "when charging"
        "dis" -> "when not charging"
        "ge" -> "value >= " + fmt(r.v)
        "gt" -> "value > " + fmt(r.v)
        "le" -> "value <= " + fmt(r.v)
        "lt" -> "value < " + fmt(r.v)
        else -> r.cond
    }

    private fun fmt(v: Float): String = if (v == v.toInt().toFloat()) v.toInt().toString() else v.toString()

    /** مسح كل إعدادات الحقول (إخفاء + ألوان). */
    fun clearAll(p: SharedPreferences) {
        val e = p.edit().remove(KEY_HIDE)
        for (k in p.all.keys) if (k.startsWith("fr_")) e.remove(k)
        e.apply()
    }
}

class LogState(val id: String, val tag: String, val label: String, val def: Int)

/** كل حالة في السجل لها لون قابل للتغيير (المفتاح lc_ID، 0 = اللون التلقائي). */
object LogStates {
    val all = listOf(
        LogState("BAT_CHG", "BAT", "level changed while charging", Col.CYAN),
        LogState("BAT_DIS", "BAT", "level changed while discharging", Col.YELLOW),
        LogState("CHG_PLUG", "CHG", "charger plugged", Col.CYAN),
        LogState("CHG_UNPLUG", "CHG", "charger unplugged", Col.YELLOW),
        LogState("CHG_FULL", "CHG", "battery full", Col.GREEN),
        LogState("VOL", "VOL", "volume changed", Col.BLUE),
        LogState("NET_OFF", "NET", "went offline", Col.RED),
        LogState("NET_ON", "NET", "network changed / connected", Col.CYAN),
        LogState("NET_DL", "NET", "download burst", Col.CYAN),
        LogState("NET_UL", "NET", "upload burst", Col.CYAN),
        LogState("SCR_HZ", "SCR", "refresh rate changed", Col.BLUE),
        LogState("SCR_BRI", "SCR", "brightness changed", Col.BLUE),
        LogState("BT_ON", "BT", "bluetooth on", Col.CYAN),
        LogState("BT_OFF", "BT", "bluetooth off", Col.GRAY),
        LogState("BT_DEV_ON", "BT", "device connected", Col.CYAN),
        LogState("BT_DEV_BAT", "BT", "device battery changed", Col.BLUE),
        LogState("BT_DEV_OFF", "BT", "device disconnected", Col.YELLOW),
        LogState("HS_ON", "HS", "hotspot on", Col.CYAN),
        LogState("HS_OFF", "HS", "hotspot off", Col.GRAY),
        LogState("SND_PLAY", "SND", "audio playing", Col.CYAN),
        LogState("SND_STOP", "SND", "audio stopped", Col.GRAY),
        LogState("SND_RINGER", "SND", "ringer mode changed", Col.BLUE),
        LogState("SND_OUT", "SND", "output device changed", Col.CYAN),
        LogState("SND_WARN", "SND", "spectrum problem", Col.YELLOW),
        LogState("PRV_MIC_ON", "PRV", "microphone in use", Col.RED),
        LogState("PRV_MIC_OFF", "PRV", "microphone released", Col.GRAY),
        LogState("PRV_CAM_ON", "PRV", "camera in use", Col.RED),
        LogState("PRV_CAM_OFF", "PRV", "camera released", Col.GRAY),
        LogState("PRV_GPS_ON", "PRV", "GPS started", Col.YELLOW),
        LogState("PRV_GPS_OFF", "PRV", "GPS stopped", Col.GRAY),
        LogState("FLS_ON", "FLS", "flashlight on", Col.YELLOW),
        LogState("FLS_OFF", "FLS", "flashlight off", Col.GRAY),
        LogState("CPU_BOOST", "CPU", "CPU boost", Col.YELLOW),
        LogState("TMP_NORMAL", "TMP", "temperature back to normal", Col.GREEN),
        LogState("TMP_WARM", "TMP", "temperature warm", Col.YELLOW),
        LogState("TMP_HOT", "TMP", "temperature hot", Col.RED),
        LogState("RAM_HIGH", "RAM", "RAM high", Col.RED),
        LogState("RAM_OK", "RAM", "RAM back to normal", Col.GREEN),
        LogState("THM_WARN", "THM", "thermal status changed", Col.YELLOW),
        LogState("THM_HOT", "THM", "thermal status severe", Col.RED),
        LogState("AIR_ON", "AIR", "airplane on", Col.YELLOW),
        LogState("AIR_OFF", "AIR", "airplane off", Col.YELLOW),
        LogState("DND_ON", "DND", "do not disturb on", Col.YELLOW),
        LogState("DND_OFF", "DND", "do not disturb off", Col.YELLOW),
        LogState("PSV_ON", "PSV", "battery saver on", Col.YELLOW),
        LogState("PSV_OFF", "PSV", "battery saver off", Col.YELLOW),
        LogState("PWR_BAL", "PWR", "mode: balanced", Col.GREEN),
        LogState("PWR_PERF", "PWR", "mode: performance", Col.ORANGE),
        LogState("PWR_SAVER", "PWR", "mode: battery saver", Col.YELLOW),
        LogState("PWR_ULTRA", "PWR", "mode: ultra battery saver", Col.RED),
        LogState("CFG", "CFG", "auto refresh speed changed", Col.BLUE),
        LogState("GPU_OK", "GPU", "GPU root read OK", Col.GREEN)
    )

    fun key(id: String) = "lc_$id"
}
