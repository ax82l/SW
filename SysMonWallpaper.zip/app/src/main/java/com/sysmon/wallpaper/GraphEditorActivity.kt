package com.sysmon.wallpaper

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** معاينة حية للرسم: تمر على المجال كاملاً لتظهر ألوان المحطات. */
class GraphPreview(ctx: Context, private val styleOf: () -> GraphStyle) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), (64 * d).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val g = styleOf()
        canvas.drawColor(Color.BLACK)
        val n = g.count
        val vals = FloatArray(n) { k -> g.sample(if (n > 1) k / (n - 1f) else 1f) }
        GraphDraw.draw(canvas, paint, 12 * d, height - 12 * d, g, vals, d, 40 * d, 255, 0, null) { it }
    }
}

class GraphEditorActivity : Activity() {

    private lateinit var p: SharedPreferences
    private lateinit var scroll: ScrollView
    private lateinit var col: LinearLayout
    private var curId: String? = null
    private var style: GraphStyle? = null
    private var preview: GraphPreview? = null
    private var info: TextView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        t.setPadding(0, dp(8), 0, dp(2))
        return t
    }

    private fun fmt(v: Float): String = if (v == v.toInt().toFloat()) v.toInt().toString() else v.toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs.of(this)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(32), dp(16), dp(32))
        scroll.addView(col)
        setContentView(scroll)
        render()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (curId != null) {
            curId = null
            style = null
            render()
        } else {
            super.onBackPressed()
        }
    }

    private fun persist() {
        val id = curId ?: return
        val s = style ?: return
        Graphs.save(p, id, s)
        preview?.invalidate()
        updateInfo()
    }

    private fun updateInfo() {
        val s = style ?: return
        val tick = p.getInt(Prefs.TICK, Prefs.TICK_DEF)
        val step = if (s.updMs > 0) s.updMs else tick
        val secs = s.count * step / 1000f
        info?.text = "width " + fmt(Math.round(s.totalDp() * 10) / 10f) + " dp  |  covers ~" +
            fmt(Math.round(secs * 10) / 10f) + " s at the current refresh" +
            "\n(one column fits about 200 dp)"
    }

    private fun render() {
        val y = scroll.scrollY
        col.removeAllViews()
        preview = null
        info = null
        if (curId == null) renderList() else renderEditor()
        scroll.post { scroll.scrollTo(0, y) }
    }

    private fun renderList() {
        col.addView(tv("ax82l@phone:~\$ sysmon --graphs", 15f, Col.GREEN, true))
        col.addView(tv("tap a graph to edit its size, range, colors and speed", 11f, Col.GRAY))
        for (def in Graphs.all) {
            val s = Graphs.get(p, def.id)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, dp(10), 0, dp(10))
            row.addView(tv(def.label, 14f, Col.WHITE, true))
            row.addView(tv(
                s.count.toString() + " bars  |  " + fmt(s.width) + "dp  |  range " + fmt(s.rmin) + ".." + fmt(s.rmax) +
                    " " + def.unit + "  |  " + s.stops.size + " color stops", 11f, Col.GRAY
            ))
            row.setOnClickListener {
                curId = def.id
                style = Graphs.get(p, def.id).copy()
                render()
            }
            col.addView(row)
        }
    }

    private fun numField(label: String, value: String, decimal: Boolean, onChange: (Float) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(tv(label, 12f, Col.WHITE), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or
            (if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0) or InputType.TYPE_NUMBER_FLAG_SIGNED
        et.setText(value)
        et.setTextColor(Color.WHITE)
        et.typeface = Typeface.MONOSPACE
        et.textSize = 13f
        et.gravity = Gravity.END
        et.minWidth = dp(96)
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString()?.toFloatOrNull() ?: return
                onChange(v)
                persist()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        row.addView(et)
        col.addView(row)
    }

    private fun toggle(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = title
        sw.textSize = 12f
        sw.typeface = Typeface.MONOSPACE
        sw.setTextColor(Color.WHITE)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, c -> onChange(c); persist() }
        sw.setPadding(0, dp(10), 0, dp(4))
        col.addView(sw)
    }

    private fun toggleP(title: String, key: String, def: Boolean) {
        val sw = Switch(this)
        sw.text = title
        sw.textSize = 12f
        sw.typeface = Typeface.MONOSPACE
        sw.setTextColor(Color.WHITE)
        sw.isChecked = p.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, c -> p.edit().putBoolean(key, c).apply() }
        sw.setPadding(0, dp(10), 0, dp(4))
        col.addView(sw)
    }

    private fun specExtras() {
        col.addView(tv("Audio spectrum", 13f, Col.CYAN, true).apply { setPadding(0, dp(16), 0, dp(2)) })
        col.addView(tv("follows everything the phone plays (music, notifications). The microphone permission is only Android's gate for this API: nothing is recorded.", 11f, Col.GRAY))
        fun fnum(label: String, key: String, def: Float) =
            numField(label, fmt(p.getFloat(key, def)), true) { p.edit().putFloat(key, it).apply() }
        fun inum(label: String, key: String, def: Int) =
            numField(label, p.getInt(key, def).toString(), false) { p.edit().putInt(key, it.toInt()).apply() }
        inum("height in text lines (1-8)", "sp_rows", 3)
        fnum("gain (sensitivity)", "sp_gain", 1f)
        fnum("rise speed (0-1)", "sp_att", 0.6f)
        fnum("fall speed (0-1)", "sp_rel", 0.12f)
        fnum("treble boost (0-2)", "sp_tilt", 0.5f)
        inum("lowest frequency (Hz)", "sp_fmin", 40)
        inum("highest frequency (Hz)", "sp_fmax", 16000)
        toggleP("Peak caps", "sp_peaks", true)
        toggleP("Faster refresh while sound plays", "sp_boost", true)
        inum("boosted refresh (ms)", "sp_boostms", 40)
    }

    private fun renderEditor() {
        val id = curId ?: return
        val s = style ?: return
        val def = Graphs.all.first { it.id == id }
        col.addView(tv(def.label, 15f, Col.GREEN, true))
        col.addView(tv("unit: " + def.unit + "  (range and color stops use this unit)", 11f, Col.GRAY))

        val pv = GraphPreview(this) { s }
        preview = pv
        col.addView(pv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)).apply {
            topMargin = dp(8)
            bottomMargin = dp(4)
        })
        val inf = tv("", 11f, Col.CYAN)
        info = inf
        col.addView(inf)
        updateInfo()

        col.addView(tv("Shape", 13f, Col.CYAN, true).apply { setPadding(0, dp(16), 0, dp(2)) })
        numField("bar width (dp)", fmt(s.width), true) { s.width = it.coerceIn(0.5f, 40f) }
        numField("gap between bars (dp)", fmt(s.gap), true) { s.gap = it.coerceIn(0f, 20f) }
        numField("number of bars", s.count.toString(), false) { s.count = it.toInt().coerceIn(1, 64) }
        numField("min bar height (dp)", fmt(s.minH), true) { s.minH = it.coerceIn(0f, 20f) }
        numField("new bar every (ms, 0 = each refresh)", s.updMs.toString(), false) { s.updMs = it.toInt().coerceAtLeast(0) }
        if (id == "spec") specExtras()

        col.addView(tv("Range (" + def.unit + ")", 13f, Col.CYAN, true).apply { setPadding(0, dp(16), 0, dp(2)) })
        numField("empty bar at", fmt(s.rmin), true) { s.rmin = it }
        numField("full bar at", fmt(s.rmax), true) { s.rmax = it }
        toggle("Logarithmic scale", s.log) { s.log = it }

        col.addView(tv("Color stops", 13f, Col.CYAN, true).apply { setPadding(0, dp(16), 0, dp(2)) })
        col.addView(tv("from each value upward the bar uses that color", 11f, Col.GRAY))
        toggle("Smooth blend between stops", s.smooth) { s.smooth = it }

        for (stop in s.stops.toList()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(tv("from", 12f, Col.GRAY), LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.WRAP_CONTENT))
            val et = EditText(this)
            et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            et.setText(fmt(stop.v))
            et.setTextColor(Color.WHITE)
            et.typeface = Typeface.MONOSPACE
            et.textSize = 13f
            et.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) {
                    val v = e?.toString()?.toFloatOrNull() ?: return
                    stop.v = v
                    persist()
                }
                override fun beforeTextChanged(e: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(e: CharSequence?, st: Int, b: Int, c: Int) {}
            })
            row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val sw = TextView(this)
            sw.text = "  #" + String.format("%06X", stop.color and 0xFFFFFF) + "  "
            sw.textSize = 12f
            sw.typeface = Typeface.MONOSPACE
            sw.setBackgroundColor(stop.color or 0xFF000000.toInt())
            sw.setTextColor(if (Contrast.lum(stop.color) > 0.4f) Color.BLACK else Color.WHITE)
            sw.setPadding(dp(6), dp(10), dp(6), dp(10))
            sw.setOnClickListener {
                ColorDialog.show(this, "Stop color", null) { c ->
                    stop.color = c or 0xFF000000.toInt()
                    persist()
                    render()
                }
            }
            row.addView(sw)

            val del = TextView(this)
            del.text = "✕"
            del.textSize = 18f
            del.setTextColor(Col.RED)
            del.gravity = Gravity.CENTER
            del.setPadding(dp(14), dp(8), dp(8), dp(8))
            del.setOnClickListener {
                if (s.stops.size > 1) {
                    s.stops.remove(stop)
                    persist()
                    render()
                }
            }
            row.addView(del)
            col.addView(row)
        }

        val add = Button(this)
        add.text = "+ Add color stop"
        add.isAllCaps = false
        add.setOnClickListener {
            val last = s.stops.lastOrNull()
            val v = if (last == null) s.rmin else last.v + (s.rmax - s.rmin) / 8f
            s.stops.add(Stop(v, last?.color ?: Col.GREEN))
            persist()
            render()
        }
        col.addView(add, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        val copy = Button(this)
        copy.text = "Copy shape from another graph"
        copy.isAllCaps = false
        copy.setOnClickListener {
            val others = Graphs.all.filter { it.id != id }
            android.app.AlertDialog.Builder(this)
                .setTitle("Copy shape from")
                .setItems(others.map { it.label }.toTypedArray()) { _, which ->
                    val src = Graphs.get(p, others[which].id)
                    s.width = src.width
                    s.gap = src.gap
                    s.count = src.count
                    s.minH = src.minH
                    s.updMs = src.updMs
                    persist()
                    render()
                }
                .show()
        }
        col.addView(copy)

        val reset = Button(this)
        reset.text = "Reset this graph to default"
        reset.isAllCaps = false
        reset.setOnClickListener {
            Graphs.reset(p, id)
            style = Graphs.get(p, id).copy()
            render()
        }
        col.addView(reset)

        val back = Button(this)
        back.text = "Back to list"
        back.isAllCaps = false
        back.setOnClickListener {
            curId = null
            style = null
            render()
        }
        col.addView(back)
    }
}
