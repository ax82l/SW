package com.sysmon.wallpaper

import android.content.Context
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** عناصر واجهة مشتركة (بطاقات، أقسام قابلة للطي، شرائح، أزرار) بنمط Terminal موحّد. */
object Ui {
    val BG = 0xFF000000.toInt()
    val CARD = 0xFF101216.toInt()
    val STROKE = 0xFF262B32.toInt()
    val STROKE_STRONG = 0xFF3A414A.toInt()
    val TRACK = 0xFF2E333A.toInt()
    val DIM = 0xFF8A919B.toInt()

    const val PRIMARY = 0
    const val SECONDARY = 1
    const val DANGER = 2

    private const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun withAlpha(color: Int, a: Int): Int = (a shl 24) or (color and 0xFFFFFF)

    fun shape(c: Context, fill: Int, stroke: Int, radius: Int = 12): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = radius * c.resources.displayMetrics.density
        g.setColor(fill)
        if (stroke != 0) g.setStroke(dp(c, 1).coerceAtLeast(1), stroke)
        return g
    }

    fun ripple(base: Drawable): Drawable = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), base, null)

    fun lp(
        c: Context, top: Int = 0, bottom: Int = 0, weight: Float = 0f, start: Int = 0, end: Int = 0
    ): LinearLayout.LayoutParams {
        val l = if (weight > 0f) LinearLayout.LayoutParams(0, WRAP, weight)
        else LinearLayout.LayoutParams(MATCH, WRAP)
        l.setMargins(dp(c, start), dp(c, top), dp(c, end), dp(c, bottom))
        return l
    }

    fun text(c: Context, s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        return t
    }

    /** عنوان مجموعة صغير، مثل: // customize */
    fun label(c: Context, s: String): TextView {
        val t = text(c, "// $s", 11f, DIM, true)
        t.letterSpacing = 0.12f
        return t
    }

    fun button(c: Context, label: String, style: Int, onClick: () -> Unit): TextView {
        val b = TextView(c)
        b.text = label
        b.textSize = 13f
        b.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        b.gravity = Gravity.CENTER
        b.isClickable = true
        b.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12))
        when (style) {
            PRIMARY -> {
                b.setTextColor(0xFF000000.toInt())
                b.background = ripple(shape(c, Col.GREEN, 0, 10))
            }
            DANGER -> {
                b.setTextColor(Col.RED)
                b.background = ripple(shape(c, 0, withAlpha(Col.RED, 0x99), 10))
            }
            else -> {
                b.setTextColor(Col.WHITE)
                b.background = ripple(shape(c, 0, STROKE_STRONG, 10))
            }
        }
        b.setOnClickListener { onClick() }
        return b
    }

    fun chip(c: Context, label: String, color: Int): TextView {
        val t = text(c, label, 11f, color, true)
        t.setPadding(dp(c, 10), dp(c, 5), dp(c, 10), dp(c, 5))
        t.background = shape(c, withAlpha(color, 0x22), withAlpha(color, 0x77), 16)
        return t
    }

    fun presetChip(c: Context, label: String, onClick: () -> Unit): TextView {
        val t = text(c, label, 11f, Col.WHITE, true)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.setPadding(dp(c, 4), dp(c, 8), dp(c, 4), dp(c, 8))
        t.setOnClickListener { onClick() }
        presetStyle(c, t, false)
        return t
    }

    fun presetStyle(c: Context, t: TextView, selected: Boolean) {
        t.setTextColor(if (selected) Col.GREEN else Col.WHITE)
        t.background = ripple(
            shape(c, if (selected) withAlpha(Col.GREEN, 0x26) else 0, if (selected) Col.GREEN else STROKE_STRONG, 8)
        )
    }

    fun navRow(c: Context, title: String, sub: String, onClick: () -> Unit): View {
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
        row.background = ripple(shape(c, CARD, STROKE, 12))
        row.isClickable = true
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(c, title, 14f, Col.WHITE, true))
        col.addView(text(c, sub, 11f, DIM), lp(c, top = 2))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(text(c, "\u203A", 22f, Col.GREEN, true))
        row.setOnClickListener { onClick() }
        return row
    }

    fun toggle(c: Context, p: SharedPreferences, title: String, key: String, def: Boolean, hint: String): View {
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, 0, dp(c, 12), 0)
        col.addView(text(c, title, 13f, Col.WHITE, true))
        if (hint.isNotEmpty()) col.addView(text(c, hint, 11f, DIM), lp(c, top = 2))
        val sw = Switch(c)
        sw.isChecked = p.getBoolean(key, def)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(Col.GREEN, 0xFF7A808A.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(withAlpha(Col.GREEN, 0x66), 0xFF2E333A.toInt()))
        sw.setOnCheckedChangeListener { _, ch -> p.edit().putBoolean(key, ch).apply() }
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        return row
    }

    class Slider(val bar: SeekBar, val view: LinearLayout)

    /** شريط: العنوان يسار والقيمة (بلون) يمين، الشرح تحت العنوان، وملاحظة تحذيرية اختيارية. */
    fun slider(
        c: Context, p: SharedPreferences, title: String, min: Int, max: Int, step: Int, key: String, def: Int,
        hint: String = "", colorOf: (Int) -> Int = { Col.CYAN }, note: ((Int) -> String)? = null,
        onChange: ((Int) -> Unit)? = null, fmt: (Int) -> String
    ): Slider {
        val box = LinearLayout(c)
        box.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(c)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val valueView = text(c, "", 13f, Col.CYAN, true)
        valueView.gravity = Gravity.END
        head.addView(text(c, title, 13f, Col.WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(valueView, LinearLayout.LayoutParams(WRAP, WRAP))
        box.addView(head)
        if (hint.isNotEmpty()) box.addView(text(c, hint, 11f, DIM), lp(c, top = 2))
        val noteView = text(c, "", 11f, Col.YELLOW)
        noteView.visibility = View.GONE
        box.addView(noteView, lp(c, top = 2))

        val bar = SeekBar(c)
        bar.max = (max - min) / step
        fun render(value: Int) {
            val col = colorOf(value)
            valueView.text = fmt(value)
            valueView.setTextColor(col)
            bar.progressTintList = ColorStateList.valueOf(col)
            bar.thumbTintList = ColorStateList.valueOf(col)
            val n = note?.invoke(value) ?: ""
            noteView.text = n
            noteView.setTextColor(col)
            noteView.visibility = if (n.isEmpty()) View.GONE else View.VISIBLE
        }
        bar.progressBackgroundTintList = ColorStateList.valueOf(TRACK)
        bar.progress = ((p.getInt(key, def) - min) / step).coerceIn(0, bar.max)
        render(min + bar.progress * step)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                val value = min + v * step
                render(value)
                p.edit().putInt(key, value).apply()
                onChange?.invoke(value)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        box.addView(bar, lp(c, top = 4))
        onChange?.invoke(min + bar.progress * step)
        return Slider(bar, box)
    }
}

/** بطاقة قابلة للطي؛ حالتها (مفتوحة/مطوية) تُحفظ في ملف تفضيلات خاص بالواجهة فقط. */
class Section(
    private val c: Context, title: String, sub: String,
    private val store: SharedPreferences, defaultOpen: Boolean
) {
    val view = LinearLayout(c)
    private val body = LinearLayout(c)
    private val arrow = Ui.text(c, "", 16f, Col.GREEN, true)

    init {
        val key = "open_$title"
        view.orientation = LinearLayout.VERTICAL
        view.background = Ui.shape(c, Ui.CARD, Ui.STROKE, 12)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(Ui.dp(c, 14), 0, Ui.dp(c, 14), Ui.dp(c, 14))

        val head = LinearLayout(c)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(Ui.dp(c, 14), Ui.dp(c, 14), Ui.dp(c, 14), Ui.dp(c, 14))
        head.background = Ui.ripple(Ui.shape(c, 0, 0, 12))
        head.isClickable = true
        val titles = LinearLayout(c)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(Ui.text(c, title, 14f, Col.WHITE, true))
        if (sub.isNotEmpty()) titles.addView(Ui.text(c, sub, 11f, Ui.DIM), Ui.lp(c, top = 2))
        head.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(arrow)
        view.addView(head)
        view.addView(body)

        fun show(open: Boolean) {
            body.visibility = if (open) View.VISIBLE else View.GONE
            arrow.text = if (open) "\u25BE" else "\u25B8"
        }
        show(store.getBoolean(key, defaultOpen))
        head.setOnClickListener {
            val open = body.visibility != View.VISIBLE
            show(open)
            store.edit().putBoolean(key, open).apply()
        }
    }

    fun add(v: View, top: Int = 16) {
        body.addView(v, Ui.lp(c, top = top))
    }
}
