package com.sysmon.wallpaper

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.GnssStatus
import android.location.LocationManager
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.os.Build
import android.os.Handler
import android.os.Looper

/**
 * يراقب (بدون صلاحيات خاصة) استخدام المايك والكاميرا والفلاش ومحرك الـ GPS.
 * لا يعرف أسماء التطبيقات، فقط هل هناك استخدام الآن ومتى كان آخر استخدام (منذ تشغيل الخلفية).
 */
class PrivacyMonitor(private val ctx: Context) {

    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()

    @Volatile var test = false          // وضع الاختبار
    @Volatile var testTorch = -2        // -2 = غير مفعّل، وإلا قيمة torch() الوهمية
    @Volatile var testCam = "back"
    @Volatile var micOk = false
    @Volatile var camOk = false
    @Volatile var torchOk = false
    @Volatile var gnssOk = false

    @Volatile var micActive = false
    @Volatile var camActive = false
    @Volatile var gpsActive = false
    @Volatile var micLast = -1L
    @Volatile var camLast = -1L
    @Volatile var gpsLast = -1L
    @Volatile var sats = -1
    @Volatile var satsUsed = -1

    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cam = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    private val camBusy = LinkedHashSet<String>()
    private val torchState = HashMap<String, Boolean>()
    private val torchUnavail = HashSet<String>()
    private var gnssRegistered = false
    @Volatile private var stopped = false

    private val micCb = object : AudioManager.AudioRecordingCallback() {
        override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
            updateMic(configs)
        }
    }

    private val camCb = object : CameraManager.AvailabilityCallback() {
        override fun onCameraAvailable(cameraId: String) {
            synchronized(lock) { camBusy.remove(cameraId) }
            camActive = synchronized(lock) { camBusy.isNotEmpty() }
        }
        override fun onCameraUnavailable(cameraId: String) {
            synchronized(lock) { camBusy.add(cameraId) }
            camActive = true
        }
    }

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            synchronized(lock) {
                torchState[cameraId] = enabled
                torchUnavail.remove(cameraId)
            }
        }
        override fun onTorchModeUnavailable(cameraId: String) {
            synchronized(lock) { torchUnavail.add(cameraId) }
        }
    }

    private val gnssCb = object : GnssStatus.Callback() {
        override fun onStarted() { gpsActive = true }
        override fun onStopped() { gpsActive = false }
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            sats = status.satelliteCount
            var u = 0
            for (i in 0 until status.satelliteCount) if (status.usedInFix(i)) u++
            satsUsed = u
        }
    }

    private fun updateMic(configs: List<AudioRecordingConfiguration>?) {
        val n = configs?.count { if (Build.VERSION.SDK_INT >= 29) !it.isClientSilenced else true } ?: 0
        micActive = n > 0
    }

    fun hasLoc(): Boolean = test ||
        ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    fun ensureGnss() {
        if (gnssRegistered || stopped || !hasLoc()) return
        try {
            lm.registerGnssStatusCallback(gnssCb, main)
            gnssRegistered = true
            gnssOk = true
        } catch (e: Exception) { }
    }

    fun start() {
        try {
            audio.registerAudioRecordingCallback(micCb, main)
            updateMic(audio.activeRecordingConfigurations)
            micOk = true
        } catch (e: Exception) { }
        try {
            cam.registerAvailabilityCallback(camCb, main)
            camOk = true
        } catch (e: Exception) { }
        try {
            cam.registerTorchCallback(torchCb, main)
            torchOk = true
        } catch (e: Exception) { }
        ensureGnss()
    }

    /** بعد الخروج من وضع الاختبار: يرجع الحالة الحقيقية للمايك والكاميرا ويصفّر "آخر استخدام". */
    fun resync() {
        test = false
        testTorch = -2
        try { updateMic(audio.activeRecordingConfigurations) } catch (e: Exception) { micActive = false }
        camActive = synchronized(lock) { camBusy.isNotEmpty() }
        gpsActive = false
        micLast = -1L; camLast = -1L; gpsLast = -1L
    }

    /** يُستدعى كل نبضة: يحدّث "آخر استخدام" للمصادر النشطة. */
    fun tick(now: Long) {
        if (micActive) micLast = now
        if (camActive) camLast = now
        if (gpsActive) gpsLast = now
    }

    /** -1 لا فلاش / 0 مطفأ / 1 يعمل / 2 غير متاح (الكاميرا مستخدمة) */
    fun torch(): Int = if (test && testTorch > -2) testTorch else synchronized(lock) {
        when {
            torchState.values.any { it } -> 1
            torchUnavail.isNotEmpty() -> 2
            torchState.isNotEmpty() -> 0
            else -> -1
        }
    }

    private val facingCache = HashMap<String, String>()

    private fun facing(id: String): String = synchronized(facingCache) { facingCache.getOrPut(id) { facing0(id) } }

    private fun facing0(id: String): String = try {
        when (cam.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING)) {
            CameraCharacteristics.LENS_FACING_BACK -> "back"
            CameraCharacteristics.LENS_FACING_FRONT -> "front"
            else -> "ext"
        }
    } catch (e: Exception) {
        "cam"
    }

    fun camLabel(): String {
        if (test) return testCam
        val ids = synchronized(lock) { camBusy.toList() }
        if (ids.isEmpty()) return "on"
        return ids.map { facing(it) }.distinct().joinToString("/")
    }

    fun stop() {
        try { audio.unregisterAudioRecordingCallback(micCb) } catch (e: Exception) { }
        try { cam.unregisterAvailabilityCallback(camCb) } catch (e: Exception) { }
        try { cam.unregisterTorchCallback(torchCb) } catch (e: Exception) { }
        try { if (gnssRegistered) lm.unregisterGnssStatusCallback(gnssCb) } catch (e: Exception) { }
        gnssRegistered = false
        stopped = true
    }
}
