package com.sysmon.wallpaper

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val TICK = "tick"        // ms
    const val AUTO = "auto"        // تعديل تلقائي حسب البطارية
    const val TEXT = "text"        // حجم الخط × 10 (sp)
    const val BOTTOM = "bottom"    // مسافة من أسفل الشاشة %
    const val LOG = "log"          // إظهار سجل الأحداث
    const val LOGOFF = "logoff"    // وسوم الأحداث المخفية (مفصولة بفاصلة)

    const val BG = "bg"                // لون الخلفية
    const val BGSHIFT = "bgshift"      // إزاحة الألوان المطابقة للخلفية
    const val P_DEV = "ps_dev"         // استخدام اسم الجهاز كاسم مضيف
    const val P_CUR = "ps_cursor"      // إظهار المؤشر
    const val P_CUR_COL = "ps_cursor_col"

    /** أجزاء سطر الأوامر: (الاسم، النص الافتراضي، اللون الافتراضي) */
    val PROMPT: List<Triple<String, String, Int>> = listOf(
        Triple("user", "ax82l", Col.GREEN),
        Triple("at", "@", Col.GREEN),
        Triple("host", "phone", Col.GREEN),
        Triple("colon", ":", Col.WHITE),
        Triple("path", "~", Col.YELLOW),
        Triple("sign", "$ ", Col.WHITE),
        Triple("cmd", "sysmon ", Col.WHITE)
    )

    const val TICK_DEF = 250
    const val TEXT_DEF = 95
    const val CLK_MS = "clkms"        // سرعة تحديث سطر الساعة فقط
    const val CLK_MS_DEF = 8
    const val BOTTOM_DEF = 18
    const val LOGOFF_DEF = "BAT,VOL,SCR"

    fun fmaxKey(i: Int) = "fmax$i"

    /** أقصى تردد (MHz) افتراضي لكل نواة: Dimensity 9200+ ، 0 = كشف تلقائي */
    fun defaultFmax(i: Int): Int = when (i) {
        0, 1, 2, 3 -> 2000
        4, 5, 6 -> 2850
        7 -> 3350
        else -> 0
    }

    @Volatile private var ready = false

    /** عند أول تثبيت (لا توجد إعدادات) تُطبَّق الإعدادات الافتراضية للتطبيق. */
    fun of(ctx: Context): SharedPreferences {
        val sp = ctx.applicationContext.getSharedPreferences("sysmon", Context.MODE_PRIVATE)
        if (!ready) {
            synchronized(this) {
                if (!ready) {
                    if (sp.all.isEmpty()) SettingsIO.loadDefaults(sp)
                    ready = true
                }
            }
        }
        return sp
    }
}
