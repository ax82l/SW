package com.sysmon.wallpaper

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val TICK = "tick"        // ms
    const val AUTO = "auto"        // تعديل تلقائي حسب البطارية
    const val TEXT = "text"        // حجم الخط × 10 (sp)
    const val BOTTOM = "bottom"    // مسافة من أسفل الشاشة %
    const val LOG = "log"          // إظهار سجل الأحداث

    const val TICK_DEF = 250
    const val TEXT_DEF = 90
    const val BOTTOM_DEF = 16

    fun of(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("sysmon", Context.MODE_PRIVATE)
}
