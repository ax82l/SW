package com.sysmon.wallpaper

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val TICK = "tick"        // ms
    const val AUTO = "auto"        // تعديل تلقائي حسب البطارية
    const val TEXT = "text"        // حجم الخط × 10 (sp)
    const val BOTTOM = "bottom"    // مسافة من أسفل الشاشة %
    const val LOG = "log"          // إظهار سجل الأحداث
    const val LOGOFF = "logoff"    // وسوم الأحداث المخفية (مفصولة بفاصلة)

    const val TICK_DEF = 250
    const val TEXT_DEF = 90
    const val BOTTOM_DEF = 16

    fun fmaxKey(i: Int) = "fmax$i"

    /** أقصى تردد (MHz) افتراضي لكل نواة: Dimensity 9200+ ، 0 = كشف تلقائي */
    fun defaultFmax(i: Int): Int = when (i) {
        0, 1, 2, 3 -> 2000
        4, 5, 6 -> 2850
        7 -> 3350
        else -> 0
    }

    fun of(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("sysmon", Context.MODE_PRIVATE)
}
