package com.sysmon.wallpaper

import android.content.SharedPreferences

class BlockDef(val id: String, val label: String, val side: Char)

object Blocks {
    /** الترتيب هنا = الترتيب الافتراضي داخل كل عمود */
    val all = listOf(
        BlockDef("cpu", "CPU header (load, temp)", 'L'),
        BlockDef("cores", "CPU cores (a line per core)", 'L'),
        BlockDef("gpu", "GPU", 'L'),
        BlockDef("ldv", "Load average", 'L'),
        BlockDef("os", "Android / security patch", 'L'),
        BlockDef("kern", "Kernel", 'L'),
        BlockDef("ram", "RAM", 'L'),
        BlockDef("swp", "Swap / cached", 'L'),
        BlockDef("dsk", "Storage", 'L'),
        BlockDef("bat", "Battery level / charge", 'R'),
        BlockDef("batv", "Battery volt / cycles / health", 'R'),
        BlockDef("batt", "Battery mA / W / temp + graphs (2 lines)", 'R'),
        BlockDef("bate", "Battery time left / charger", 'R'),
        BlockDef("bt", "Bluetooth (1 line + 1 per device)", 'R'),
        BlockDef("net", "Network", 'R'),
        BlockDef("ap", "Wi-Fi name / operator", 'R'),
        BlockDef("hs", "Hotspot on / off", 'R'),
        BlockDef("dl", "Download speed", 'R'),
        BlockDef("ul", "Upload speed", 'R'),
        BlockDef("rxtx", "Total traffic / IP", 'R'),
        BlockDef("scr", "Screen (Hz, brightness, lux)", 'R'),
        BlockDef("sys", "Uptime / deep sleep", 'R'),
        BlockDef("flags", "Airplane / DND / saver", 'R'),
        BlockDef("thm", "Thermal / volume", 'R')
    )

    fun label(id: String): String = all.firstOrNull { it.id == id }?.label ?: id
}

object LogTags {
    val all = listOf(
        "BAT" to "battery level changes",
        "CHG" to "charger plugged / unplugged / full",
        "VOL" to "volume changes",
        "NET" to "network changes, speed bursts",
        "SCR" to "refresh rate / brightness changes",
        "BT" to "bluetooth on/off, devices, battery",
        "HS" to "hotspot on / off",
        "CPU" to "CPU boost events",
        "TMP" to "temperature warnings",
        "RAM" to "RAM high / back to normal",
        "THM" to "thermal status",
        "AIR" to "airplane mode",
        "DND" to "do not disturb",
        "PSV" to "battery saver",
        "CFG" to "auto refresh speed changes",
        "GPU" to "GPU root read",
        "SYS" to "startup line",
        "PROBE" to "startup probe lines"
    )
}

class Item(val id: String, var on: Boolean = true, var color: Int = 0)

class Layout(val left: MutableList<Item>, val right: MutableList<Item>)

object LayoutStore {
    const val KEY_L = "layoutL"
    const val KEY_R = "layoutR"

    fun defaults(): Layout {
        val l = Blocks.all.filter { it.side == 'L' }.map { Item(it.id) }.toMutableList()
        val r = Blocks.all.filter { it.side == 'R' }.map { Item(it.id) }.toMutableList()
        return Layout(l, r)
    }

    private fun parse(s: String?): List<Item> {
        if (s.isNullOrEmpty()) return emptyList()
        val out = ArrayList<Item>()
        for (part in s.split(",")) {
            val f = part.split(":")
            if (f.size < 2) continue
            out.add(Item(f[0], f[1] == "1", f.getOrNull(2)?.toIntOrNull() ?: 0))
        }
        return out
    }

    fun load(p: SharedPreferences): Layout {
        val seen = HashSet<String>()
        fun clean(list: List<Item>): MutableList<Item> {
            val res = ArrayList<Item>()
            for (x in list) {
                if (Blocks.all.any { b -> b.id == x.id } && seen.add(x.id)) res.add(x)
            }
            return res
        }
        val l = clean(parse(p.getString(KEY_L, null)))
        val r = clean(parse(p.getString(KEY_R, null)))
        if (l.isEmpty() && r.isEmpty()) return defaults()
        // أي بلوك جديد لم يُحفظ يضاف لجهته الافتراضية
        for (b in Blocks.all) {
            if (!seen.contains(b.id)) (if (b.side == 'L') l else r).add(Item(b.id))
        }
        return Layout(l, r)
    }

    private fun ser(list: List<Item>): String =
        list.joinToString(",") { "${it.id}:${if (it.on) 1 else 0}:${it.color}" }

    fun save(p: SharedPreferences, l: Layout) {
        p.edit().putString(KEY_L, ser(l.left)).putString(KEY_R, ser(l.right)).apply()
    }
}
