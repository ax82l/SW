package com.sysmon.wallpaper

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.util.TypedValue
import android.view.SurfaceHolder

// ====== إعدادات تقدر تعدلها ======
private const val TICK_MS = 250L          // كل كم ملي ثانية ينضاف سطر جديد
private const val FRAME_MS = 33L          // سرعة رسم الحركة (33 = حوالي 30 إطار/ثانية)
private const val TEXT_SP = 11f           // حجم الخط
private const val BOTTOM_MARGIN = 0.13f   // مسافة من أسفل الشاشة (عشان الدوك)
private const val FADE_TOP = 0.38f        // فوق هذا الخط الأسطر تختفي تماماً
private const val FADE_FULL = 0.70f       // تحت هذا الخط الأسطر واضحة 100%
private const val MAX_LINES = 60

class SysMonService : WallpaperService() {

    override fun onCreateEngine(): Engine = MonEngine()

    private inner class MonEngine : Engine() {

        private val thread = HandlerThread("sysmon").apply { start() }
        private val handler = Handler(thread.looper)
        private val stats = SysStats(applicationContext)

        private val lines = ArrayList<Line>() // الأحدث في الآخر
        private var kind = 0
        private var lastTick = 0L

        @Volatile private var shown = false
        @Volatile private var w = 0
        @Volatile private var h = 0

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.MONOSPACE
            textSize = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP, TEXT_SP, resources.displayMetrics
            )
        }
        private val lineH = paint.fontSpacing * 1.12f

        private val prompt: Line = listOf(
            Span("user@phone", Col.GREEN),
            Span(":", Col.WHITE),
            Span("~", Col.BLUE),
            Span("$ ", Col.WHITE),
            Span("sysmon ", Col.WHITE)
        )

        private val frame = object : Runnable {
            override fun run() {
                if (!shown) return
                val now = SystemClock.uptimeMillis()
                if (now - lastTick >= TICK_MS) {
                    lastTick = now
                    push()
                }
                draw(now)
                handler.postDelayed(this, FRAME_MS)
            }
        }

        private fun push() {
            lines.add(stats.build(kind))
            kind = (kind + 1) % SysStats.KINDS
            if (lines.size > MAX_LINES) lines.removeAt(0)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width
            h = height
            handler.post { draw(SystemClock.uptimeMillis()) }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            shown = visible
            handler.removeCallbacks(frame)
            if (visible) handler.post(frame)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            shown = false
            handler.removeCallbacks(frame)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            shown = false
            handler.removeCallbacksAndMessages(null)
            thread.quitSafely()
            super.onDestroy()
        }

        private fun drawLine(c: Canvas, line: Line, x0: Float, y: Float, alpha: Float): Float {
            var x = x0
            val a = (alpha * 255f).toInt().coerceIn(0, 255)
            for (s in line) {
                paint.color = s.c
                paint.alpha = a
                c.drawText(s.t, x, y, paint)
                x += paint.measureText(s.t)
            }
            return x
        }

        private fun draw(now: Long) {
            val holder = surfaceHolder
            if (w == 0 || h == 0 || !holder.surface.isValid) return
            var c: Canvas? = null
            try {
                c = holder.lockCanvas() ?: return
                c.drawColor(Color.BLACK)

                val p = ((now - lastTick).toFloat() / TICK_MS).coerceIn(0f, 1f)
                val shift = lineH * (1f - p)
                val left = w * 0.04f
                val promptY = h * (1f - BOTTOM_MARGIN)
                val top = h * FADE_TOP
                val full = h * FADE_FULL

                var i = 0
                while (i < lines.size) {
                    val line = lines[lines.size - 1 - i]
                    val y = promptY - lineH * (i + 1) + shift
                    if (y < top - lineH) break
                    var a = ((y - top) / (full - top)).coerceIn(0f, 1f)
                    if (i == 0) a *= p
                    drawLine(c, line, left, y, a)
                    i++
                }

                val endX = drawLine(c, prompt, left, promptY, 1f)
                if ((now / 500L) % 2L == 0L) {
                    paint.color = Col.WHITE
                    paint.alpha = 255
                    val cw = paint.measureText("M")
                    c.drawRect(endX, promptY - paint.textSize * 0.85f, endX + cw, promptY + paint.descent(), paint)
                }
            } catch (e: Exception) {
                // تجاهل أخطاء الرسم المؤقتة
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c) } catch (_: Exception) { }
                }
            }
        }
    }
}
