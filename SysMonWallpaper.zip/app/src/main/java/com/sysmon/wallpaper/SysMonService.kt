package com.sysmon.wallpaper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.util.TypedValue
import android.view.SurfaceHolder
import kotlin.math.max
import kotlin.math.min

// ====== إعدادات تقدر تعدلها ======
private const val TICK_MS = 250L        // سرعة التحديث
private const val TEXT_SP = 9f          // حجم الخط الأقصى (يصغر تلقائياً لو ما كفى العرض)
private const val BOTTOM_MARGIN = 0.12f // مسافة من أسفل الشاشة
private const val LOG_TOP = 0.50f       // أعلى نقطة يوصلها سجل الأحداث (تحت الساعة)
private const val LOG_FADE = 0.10f      // ارتفاع منطقة التلاشي
private const val LEFT_COLS = 38        // عرض العمود الأيسر بالحروف
private const val TOTAL_COLS = 75       // العرض الكلي بالحروف
private const val MAX_LOG = 80

class SysMonService : WallpaperService() {

    override fun onCreateEngine(): Engine = MonEngine()

    private inner class MonEngine : Engine(), SensorEventListener {

        private val thread = HandlerThread("sysmon").apply { start() }
        private val handler = Handler(thread.looper)
        private val stats = SysStats(this@SysMonService.applicationContext)
        private val sm = this@SysMonService.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        private val light: Sensor? = sm.getDefaultSensor(Sensor.TYPE_LIGHT)

        private val log = ArrayList<Line>()
        private var started = false

        @Volatile private var shown = false
        @Volatile private var w = 0
        @Volatile private var h = 0

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
        private var charW = 10f
        private var lineH = 20f

        private val prompt: Line = listOf(
            Span("user@phone", Col.GREEN),
            Span(":", Col.WHITE),
            Span("~", Col.BLUE),
            Span("$ ", Col.WHITE),
            Span("sysmon ", Col.WHITE)
        )

        private val tick = object : Runnable {
            override fun run() {
                if (!shown) return
                val t0 = SystemClock.uptimeMillis()
                if (!started) {
                    started = true
                    stats.start(light != null)
                }
                stats.tick()
                for (e in stats.drainEvents()) {
                    log.add(e)
                    if (log.size > MAX_LOG) log.removeAt(0)
                }
                draw(t0)
                val dt = SystemClock.uptimeMillis() - t0
                handler.postDelayed(this, max(TICK_MS - dt, 50L))
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width
            h = height
            paint.textSize = 100f
            val ratio = paint.measureText("M") / 100f
            val spPx = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP, TEXT_SP, this@SysMonService.resources.displayMetrics
            )
            val fit = w * 0.95f / (TOTAL_COLS * ratio)
            paint.textSize = min(spPx, fit)
            charW = paint.measureText("M")
            lineH = paint.fontSpacing * 1.05f
            handler.post { draw(SystemClock.uptimeMillis()) }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            shown = visible
            handler.removeCallbacks(tick)
            if (visible) {
                handler.post(tick)
                if (light != null) sm.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL, handler)
            } else if (light != null) {
                sm.unregisterListener(this)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            shown = false
            handler.removeCallbacks(tick)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            shown = false
            if (light != null) sm.unregisterListener(this)
            handler.removeCallbacksAndMessages(null)
            thread.quitSafely()
            super.onDestroy()
        }

        override fun onSensorChanged(event: SensorEvent) {
            if (event.values.isNotEmpty()) stats.lux = event.values[0]
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

        private fun drawLine(c: Canvas, line: Line, x0: Float, y: Float, alpha: Float): Float {
            var x = x0
            val a = (alpha * 255f).toInt().coerceIn(0, 255)
            for (s in line) {
                val b = s.bars
                if (b != null) {
                    val bw = charW * 0.78f
                    val maxH = lineH * 0.78f
                    for (k in b.indices) {
                        val v = b[k].coerceIn(0f, 1f)
                        paint.color = if (s.heat) heatColor(v) else s.c
                        paint.alpha = a
                        val bh = max(2f, v * maxH)
                        val bx = x + k * charW + charW * 0.11f
                        c.drawRect(bx, y - bh + 2f, bx + bw, y + 2f, paint)
                    }
                    x += b.size * charW
                } else {
                    paint.color = s.c
                    paint.alpha = a
                    c.drawText(s.t, x, y, paint)
                    x += paint.measureText(s.t)
                }
            }
            return x
        }

        private fun draw(now: Long) {
            val holder = surfaceHolder
            if (w == 0 || h == 0 || !holder.surface.isValid) return
            var c: Canvas? = null
            try {
                c = holder.lockCanvas() ?: return
                c.drawColor(Color.BLACK)

                val left = (w - TOTAL_COLS * charW) / 2f
                val rightX = left + LEFT_COLS * charW
                val promptY = h * (1f - BOTTOM_MARGIN)

                // ---- اللوحة الثابتة ----
                val l = stats.left
                val r = stats.right
                val n = max(l.size, r.size)
                val lastY = promptY - lineH * 1.2f
                val firstY = lastY - (n - 1) * lineH
                for (i in 0 until n) {
                    val y = firstY + i * lineH
                    if (i < l.size) drawLine(c, l[i], left, y, 1f)
                    if (i < r.size) drawLine(c, r[i], rightX, y, 1f)
                }
                paint.color = Color.argb(70, 255, 255, 255)
                val sx = rightX - charW * 0.5f
                c.drawRect(sx - 1f, firstY - lineH * 0.8f, sx + 1f, lastY + lineH * 0.25f, paint)
                val ry = firstY - lineH * 1.0f
                c.drawRect(left, ry, left + TOTAL_COLS * charW, ry + 2f, paint)

                // ---- سجل الأحداث فوق اللوحة ----
                val logBottom = firstY - lineH * 1.5f
                val top = h * LOG_TOP
                val fade = h * LOG_FADE
                var i = 0
                while (i < log.size) {
                    val y = logBottom - i * lineH
                    if (y < top) break
                    val a = ((y - top) / fade).coerceIn(0f, 1f)
                    drawLine(c, log[log.size - 1 - i], left, y, a)
                    i++
                }

                // ---- السطر الأخير مع المؤشر ----
                val endX = drawLine(c, prompt, left, promptY, 1f)
                if ((now / 500L) % 2L == 0L) {
                    paint.color = Col.WHITE
                    paint.alpha = 255
                    c.drawRect(endX, promptY - paint.textSize * 0.85f, endX + charW, promptY + paint.descent(), paint)
                }
            } catch (e: Exception) {
                // تجاهل أخطاء الرسم المؤقتة
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c) } catch (_: Exception) { }
                }
            }
        }
    }
}
