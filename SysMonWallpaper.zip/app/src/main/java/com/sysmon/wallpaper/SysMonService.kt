package com.sysmon.wallpaper

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.provider.Settings
import android.service.wallpaper.WallpaperService
import android.util.TypedValue
import android.view.SurfaceHolder
import kotlin.math.max
import kotlin.math.min

// ثوابت التخطيط (سرعة التحديث والخط والموقع والألوان تتحكم فيها من واجهة التطبيق)
private const val LOG_TOP = 0.03f   // حد أمان: أعلى نقطة ممكنة للسجل (نسبة من ارتفاع الشاشة)
private const val LEFT_COLS = 38    // عرض العمود الأيسر بالحروف
private const val TOTAL_COLS = 75   // العرض الكلي بالحروف
private const val MAX_LOG = 80

class SysMonService : WallpaperService() {

    override fun onCreateEngine(): Engine = MonEngine()

    private inner class MonEngine : Engine(), SensorEventListener {

        private val thread = HandlerThread("sysmon").apply { start() }
        private val handler = Handler(thread.looper)
        private val stats = SysStats(this@SysMonService.applicationContext)
        private val prefs: SharedPreferences = Prefs.of(this@SysMonService)
        private val sm = this@SysMonService.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        private val light: Sensor? = sm.getDefaultSensor(Sensor.TYPE_LIGHT)
        private val density = this@SysMonService.resources.displayMetrics.density
        private var gu: Float = density   // وحدة الرسوم: تتناسب مع حجم الخط

        private val log = ArrayList<Pair<String, Line>>()
        private var hidRaw: String? = null
        private var hidSet: Set<String> = emptySet()
        private var started = false
        private var lastFactor = 1
        private var lastLayoutKey = ""
        private var leftCols = LEFT_COLS
        private var totalCols = TOTAL_COLS
        private var lastHeavy = 0L

        private var bgColor = Color.BLACK
        private var shift = true
        private var devName = ""
        private var devTs = 0L

        @Volatile private var shown = false
        @Volatile private var w = 0
        @Volatile private var h = 0

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
        private var charW = 10f
        private var lineH = 20f

        /** معامل التبطيء حسب البطارية (لو الوضع التلقائي شغال). */
        private fun factor(): Int {
            if (!prefs.getBoolean(Prefs.AUTO, false)) return 1
            val pct = stats.curPct
            return when {
                stats.curCharging -> 1
                stats.curPsv || pct in 0..20 -> 4
                pct in 0..50 -> 2
                else -> 1
            }
        }

        private val tick = object : Runnable {
            override fun run() {
                if (!shown) return
                var delay = 50L
                try {
                    delay = step()
                } catch (ex: Exception) {
                    // أي خطأ مؤقت لا يوقف الحلقة ولا يقتل التطبيق
                }
                handler.removeCallbacks(this)
                handler.postDelayed(this, delay)
            }

            private fun step(): Long {
                val t0 = SystemClock.uptimeMillis()
                if (!started) {
                    started = true
                    stats.start(light != null)
                }
                val base = prefs.getInt(Prefs.TICK, Prefs.TICK_DEF).toLong().coerceAtLeast(30L)
                val fct = factor()
                var eff = max(base, min(base * fct, 2000L))
                val audio = prefs.getBoolean("sp_boost", true) && stats.audioActive
                val boostMs = prefs.getInt("sp_boostms", 40).toLong().coerceAtLeast(10L)
                if (audio && prefs.getBoolean("sp_boostall", false)) eff = min(eff, boostMs)
                var lightMs = eff
                if (audio && stats.hasBlock("spec")) lightMs = min(lightMs, boostMs)
                if (fct == 1 && stats.hasBlock("clk")) {
                    lightMs = min(lightMs, prefs.getInt(Prefs.CLK_MS, Prefs.CLK_MS_DEF).toLong().coerceAtLeast(4L))
                }
                if (fct != lastFactor) {
                    stats.note("CFG", Col.BLUE, "auto refresh x$fct -> ${eff}ms (bat ${stats.curPct}%)")
                    lastFactor = fct
                }
                if (lastHeavy == 0L || t0 - lastHeavy >= eff) {
                    lastHeavy = t0
                    stats.tick()
                } else {
                    stats.lightTick()
                }
                for (e in stats.drainEvents()) {
                    log.add(e)
                    if (log.size > MAX_LOG) log.removeAt(0)
                }
                draw(t0)
                val dt = SystemClock.uptimeMillis() - t0
                return max(lightMs - dt, 1L)
            }
        }

        private fun hiddenTags(): Set<String> {
            val raw = prefs.getString(Prefs.LOGOFF, Prefs.LOGOFF_DEF) ?: ""
            if (raw != hidRaw) {
                hidRaw = raw
                hidSet = raw.split(",").filter { it.isNotEmpty() }.toSet()
            }
            return hidSet
        }

        private fun layoutKey(): String =
            prefs.getInt(Prefs.TEXT, Prefs.TEXT_DEF).toString() + "," + prefs.getInt("cols_l", LEFT_COLS) + "," +
                prefs.getInt("cols_t", TOTAL_COLS) + "," + prefs.getInt("lsp", 105)

        private fun relayout() {
            if (w == 0) return
            val tp = prefs.getInt(Prefs.TEXT, Prefs.TEXT_DEF)
            lastLayoutKey = layoutKey()
            totalCols = prefs.getInt("cols_t", TOTAL_COLS).coerceIn(40, 200)
            leftCols = prefs.getInt("cols_l", LEFT_COLS).coerceIn(16, totalCols - 16)
            paint.textSize = 100f
            val ratio = paint.measureText("M") / 100f
            val spPx = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP, tp / 10f, this@SysMonService.resources.displayMetrics
            )
            val fit = w * 0.95f / (totalCols * ratio)
            paint.textSize = min(spPx, fit)
            charW = paint.measureText("M")
            gu = charW / 5.7f
            lineH = paint.fontSpacing * prefs.getInt("lsp", 105).coerceIn(70, 160) / 100f
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width
            h = height
            handler.post {
                relayout()
                draw(SystemClock.uptimeMillis())
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            shown = visible
            handler.removeCallbacks(tick)
            stats.onVisible(visible)
            if (visible) {
                handler.post(tick)
                if (light != null) sm.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL, handler)
            } else if (light != null) {
                sm.unregisterListener(this)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            shown = false
            handler.removeCallbacks(tick)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            shown = false
            if (light != null) sm.unregisterListener(this)
            handler.removeCallbacksAndMessages(null)
            stats.release()
            thread.quitSafely()
            super.onDestroy()
        }

        override fun onSensorChanged(event: SensorEvent) {
            if (event.values.isNotEmpty()) stats.lux = event.values[0]
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

        /** لون بعد إزاحته لو كان يشبه الخلفية (إذا الخيار مفعّل). */
        private fun fix(c: Int): Int = if (shift) Contrast.fix(c, bgColor) else c

        private fun deviceName(): String {
            val now = SystemClock.uptimeMillis()
            if (devName.isNotEmpty() && now - devTs < 5000L) return devName
            val cr = this@SysMonService.contentResolver
            var n: String? = try { Settings.Global.getString(cr, Settings.Global.DEVICE_NAME) } catch (e: Exception) { null }
            if (n.isNullOrBlank()) n = try { Settings.Secure.getString(cr, "bluetooth_name") } catch (e: Exception) { null }
            devName = (if (n.isNullOrBlank()) Build.MODEL else n).trim()
            devTs = now
            return devName
        }

        private fun buildPrompt(): Line {
            val out = ArrayList<Span>()
            for ((name, defT, defC) in Prefs.PROMPT) {
                var t = prefs.getString("ps_t_$name", defT) ?: defT
                if (name == "host" && prefs.getBoolean(Prefs.P_DEV, false)) t = deviceName()
                if (t.isEmpty()) continue
                out.add(Span(t, prefs.getInt("ps_c_$name", defC)))
            }
            return out
        }

        private fun drawLine(c: Canvas, line: Line, x0: Float, y: Float, alpha: Float, sc: Float = 1f): Float {
            var x = x0
            val a = (alpha * 255f).toInt().coerceIn(0, 255)
            for (s in line) {
                val b = s.bars
                val g = s.g
                if (b != null && g != null) {
                    val mh = if (s.lines > 1) lineH * 0.72f + (s.lines - 1) * lineH else lineH * 0.78f
                    x = GraphDraw.draw(c, paint, x, y, g, b, gu, mh, a, s.fixed, s.peaks, s.zlo, s.zhi) { col -> fix(col) }
                } else {
                    val k = s.scale * sc
                    val base = paint.textSize
                    if (k != 1f) paint.textSize = base * k
                    paint.color = fix(s.c)
                    paint.alpha = a
                    c.drawText(s.t, x, y, paint)
                    x += paint.measureText(s.t)
                    if (k != 1f) paint.textSize = base
                }
            }
            return x
        }

        private fun draw(now: Long) {
            val holder = surfaceHolder
            if (w == 0 || h == 0 || !holder.surface.isValid) return
            if (layoutKey() != lastLayoutKey) relayout()
            bgColor = prefs.getInt(Prefs.BG, Color.BLACK) or 0xFF000000.toInt()
            shift = prefs.getBoolean(Prefs.BGSHIFT, true)
            var c: Canvas? = null
            try {
                c = holder.lockCanvas() ?: return
                c.drawColor(bgColor)

                val bottom = prefs.getInt(Prefs.BOTTOM, Prefs.BOTTOM_DEF) / 100f
                val left = (w - totalCols * charW) / 2f
                val rightX = left + leftCols * charW
                val promptY = h * (1f - bottom)
                val ruleCol = if (Contrast.lum(bgColor) < 0.5f) Color.argb(70, 255, 255, 255) else Color.argb(70, 0, 0, 0)

                // ---- اللوحة الثابتة ----
                val l = stats.left
                val r = stats.right
                val n = max(l.size, r.size)
                val lastY = promptY - lineH * 1.2f
                val firstY = lastY - (n - 1) * lineH
                for (i in 0 until n) {
                    val y = firstY + i * lineH
                    if (i < l.size) drawLine(c, l[i], left, y, 1f)
                    if (i < r.size) drawLine(c, r[i], rightX, y, 1f)
                }
                paint.color = ruleCol
                val sx = rightX - charW * 0.5f
                c.drawRect(sx - 1f, firstY - lineH * 0.8f, sx + 1f, lastY + lineH * 0.25f, paint)
                val ry = firstY - lineH * 1.0f
                c.drawRect(left, ry, left + totalCols * charW, ry + 2f, paint)

                // ---- سجل الأحداث فوق اللوحة ----
                if (prefs.getBoolean(Prefs.LOG, true)) {
                    val hidden = hiddenTags()
                    val logSc = prefs.getInt("log_pct", 100).coerceIn(40, 160) / 100f
                    val lh = lineH * logSc
                    val logBottom = firstY - lineH * 1.5f
                    val top = h * LOG_TOP
                    val maxN = prefs.getInt(Prefs.LOG_LINES, Prefs.LOG_LINES_DEF).coerceIn(0, MAX_LOG)
                    val solid = prefs.getInt(Prefs.LOG_SOLID, Prefs.LOG_SOLID_DEF).coerceIn(0, maxN)
                    var shownN = 0
                    var j = log.size - 1
                    while (j >= 0 && shownN < maxN) {
                        val e = log[j]
                        j--
                        if (hidden.contains(e.first)) continue
                        val y = logBottom - shownN * lh
                        if (y < top) break
                        // أول solid أسطر (الأحدث) كاملة الوضوح، والباقي يتلاشى تدريجياً حتى آخر سطر
                        val a = if (shownN < solid) 1f else (maxN - shownN).toFloat() / (maxN - solid + 1).toFloat()
                        drawLine(c, e.second, left, y, a, logSc)
                        shownN++
                    }
                }

                // ---- السطر الأخير مع المؤشر ----
                val endX = drawLine(c, buildPrompt(), left, promptY, 1f)
                if (prefs.getBoolean(Prefs.P_CUR, true) && (now / 500L) % 2L == 0L) {
                    paint.color = fix(prefs.getInt(Prefs.P_CUR_COL, Col.WHITE))
                    paint.alpha = 255
                    c.drawRect(endX, promptY - paint.textSize * 0.85f, endX + charW, promptY + paint.descent(), paint)
                }
            } catch (e: Exception) {
                // تجاهل أخطاء الرسم المؤقتة
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c) } catch (ex: Exception) { }
                }
            }
        }
    }
}
