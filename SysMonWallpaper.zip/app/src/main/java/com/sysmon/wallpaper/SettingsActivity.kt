package com.sysmon.wallpaper

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.EditText
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var p: SharedPreferences
    private lateinit var col: LinearLayout
    private lateinit var permStatus: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        t.setPadding(0, dp(8), 0, dp(2))
        return t
    }

    private fun slider(
        title: String, min: Int, max: Int, step: Int, key: String, def: Int,
        colorOf: (Int) -> Int = { Col.CYAN }, fmt: (Int) -> String
    ): SeekBar {
        col.addView(tv(title, 14f, Col.WHITE, true))
        val label = tv("", 13f, Col.CYAN)
        col.addView(label)
        val bar = SeekBar(this)
        bar.max = (max - min) / step
        bar.progress = ((p.getInt(key, def) - min) / step).coerceIn(0, bar.max)
        label.text = fmt(min + bar.progress * step)
        label.setTextColor(colorOf(min + bar.progress * step))
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                val value = min + v * step
                label.text = fmt(value)
                label.setTextColor(colorOf(value))
                p.edit().putInt(key, value).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(bar)
        return bar
    }

    private fun toggle(title: String, key: String, def: Boolean, hint: String) {
        val sw = Switch(this)
        sw.text = title
        sw.setTextColor(Color.WHITE)
        sw.typeface = Typeface.MONOSPACE
        sw.isChecked = p.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, c -> p.edit().putBoolean(key, c).apply() }
        sw.setPadding(0, dp(16), 0, 0)
        col.addView(sw)
        col.addView(tv(hint, 11f, Col.GRAY))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs.of(this)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = ScrollView(this)
        root.setBackgroundColor(Color.BLACK)
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(36), dp(20), dp(36))
        root.addView(col)

        col.addView(tv("ax82l@phone:~\$ sysmon --config", 15f, Col.GREEN, true))

        val tickBar = slider(
            "Refresh interval", 30, 2000, 10, Prefs.TICK, Prefs.TICK_DEF,
            colorOf = { if (it < 60) Col.RED else if (it < 250) Col.YELLOW else Col.CYAN }
        ) {
            val hz = String.format(java.util.Locale.US, "%.1f", 1000f / it)
            val warn = if (it < 60) "\n!! very heavy on battery" else if (it < 250) "\n! heavy on battery" else ""
            "$it ms  ($hz Hz)$warn"
        }
        val presets = LinearLayout(this)
        presets.orientation = LinearLayout.HORIZONTAL
        for ((name, ms) in listOf("Turbo" to 30, "Fast" to 100, "Normal" to 250, "Eco" to 1000, "Slow" to 2000)) {
            val b = Button(this)
            b.text = "$name\n$ms"
            b.isAllCaps = false
            b.textSize = 11f
            b.setOnClickListener { tickBar.progress = (ms - 30) / 10 }
            presets.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(presets)

        toggle(
            "Battery-aware auto speed", Prefs.AUTO, false,
            "charging: full speed | battery <=50%: x2 slower | <=20% or battery saver: x4 slower (max 2000 ms)"
        )

        slider(
            "Clock row refresh (only the clock line)", 4, 1000, 1, Prefs.CLK_MS, Prefs.CLK_MS_DEF,
            colorOf = { if (it < 16) Col.RED else if (it < 50) Col.YELLOW else Col.CYAN }
        ) {
            "$it ms" + (if (it < 16) "  !! very heavy on battery" else if (it < 50) "  ! heavy on battery" else "")
        }
        col.addView(tv("runs only while the Clock block is shown; the rest keeps the normal refresh", 11f, Col.GRAY))

        slider("Text size", 60, 95, 5, Prefs.TEXT, Prefs.TEXT_DEF) {
            String.format(java.util.Locale.US, "%.1f sp  (shrinks automatically to fit the screen)", it / 10f)
        }
        slider("Vertical position", 6, 30, 1, Prefs.BOTTOM, Prefs.BOTTOM_DEF) {
            "$it% from bottom"
        }
        toggle("Show event log", Prefs.LOG, true, "events that print above the panel")

        // ---- أقصى تردد لكل نواة ----
        col.addView(tv("Max frequency per core (MHz)", 14f, Col.WHITE, true).apply { setPadding(0, dp(24), 0, dp(2)) })
        col.addView(tv("100% of the speed bars. Defaults: Dimensity 9200+ (A510 2000 / A715 2850 / X3 3350). 0 = auto-detect", 11f, Col.GRAY))
        val cores = (0 until 16).count { java.io.File("/sys/devices/system/cpu/cpu$it").exists() }.coerceAtLeast(1)
        var rowL: LinearLayout? = null
        for (i in 0 until cores) {
            if (i % 4 == 0) {
                rowL = LinearLayout(this)
                rowL.orientation = LinearLayout.HORIZONTAL
                col.addView(rowL)
            }
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.addView(tv("C$i", 11f, Col.GRAY))
            val et = EditText(this)
            et.inputType = InputType.TYPE_CLASS_NUMBER
            et.setText(p.getInt(Prefs.fmaxKey(i), Prefs.defaultFmax(i)).toString())
            et.setTextColor(Color.WHITE)
            et.typeface = Typeface.MONOSPACE
            et.textSize = 13f
            et.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    val v = s?.toString()?.toIntOrNull() ?: 0
                    p.edit().putInt(Prefs.fmaxKey(i), if (v in 100..6000) v else 0).apply()
                }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
            cell.addView(et)
            rowL!!.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        // ---- الصلاحيات ----
        col.addView(tv("Permissions", 14f, Col.WHITE, true).apply { setPadding(0, dp(24), 0, dp(2)) })
        permStatus = tv(permsText(), 12f, Col.CYAN)
        col.addView(permStatus)
        col.addView(tv("Location = Wi-Fi network name. Nearby devices = Bluetooth devices. If the name still shows N/A, open app settings and set Location to Allow all the time. Audio (microphone) is only the gate for the sound spectrum: nothing is recorded.", 11f, Col.GRAY))
        val grant = Button(this)
        grant.text = "Grant permissions"
        grant.isAllCaps = false
        grant.setOnClickListener { requestPerms() }
        col.addView(grant)
        val appSet = Button(this)
        appSet.text = "Open app settings"
        appSet.isAllCaps = false
        appSet.setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        col.addView(appSet)

        val gEd = Button(this)
        gEd.text = "Graph editor (size, range, colors, speed)"
        gEd.isAllCaps = false
        gEd.setOnClickListener { startActivity(Intent(this, GraphEditorActivity::class.java)) }
        col.addView(gEd, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) })

        val look = Button(this)
        look.text = "Background & prompt line"
        look.isAllCaps = false
        look.setOnClickListener { startActivity(Intent(this, AppearanceActivity::class.java)) }
        col.addView(look)

        val editor = Button(this)
        editor.text = "Layout, colors & log editor"
        editor.isAllCaps = false
        editor.setOnClickListener { startActivity(Intent(this, LayoutEditorActivity::class.java)) }
        col.addView(editor, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) })

        val prof = Button(this)
        prof.text = "Profiles, import & export"
        prof.isAllCaps = false
        prof.setOnClickListener { startActivity(Intent(this, ProfilesActivity::class.java)) }
        col.addView(prof, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) })

        val set = Button(this)
        set.text = "Set as live wallpaper"
        set.isAllCaps = false
        set.setOnClickListener { openChooser() }
        col.addView(set, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(28) })

        val reset = Button(this)
        reset.text = "Reset to defaults"
        reset.isAllCaps = false
        reset.setOnClickListener { SettingsIO.loadDefaults(p); recreate() }
        col.addView(reset)

        col.addView(tv("changes apply live to the running wallpaper", 11f, Col.GRAY))
        setContentView(root)

        if (!p.getBoolean("first_done", false)) {
            p.edit().putBoolean("first_done", true).apply()
            AlertDialog.Builder(this)
                .setTitle("First setup")
                .setMessage("1) Check the max frequency of each core below.\n2) Grant permissions to show the Wi-Fi name and Bluetooth devices.")
                .setPositiveButton("Grant permissions") { _, _ -> requestPerms() }
                .setNegativeButton("Later", null)
                .show()
        }
    }

    private fun permsText(): String {
        fun ok(perm: String) = checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
        val loc = ok(Manifest.permission.ACCESS_FINE_LOCATION)
        val bt = if (Build.VERSION.SDK_INT >= 31) ok(Manifest.permission.BLUETOOTH_CONNECT) else true
        val mic = ok(Manifest.permission.RECORD_AUDIO)
        return "location: " + (if (loc) "granted" else "missing") + "  |  bluetooth: " + (if (bt) "granted" else "missing") +
            "  |  audio: " + (if (mic) "granted" else "missing")
    }

    private fun requestPerms() {
        val list = ArrayList<String>()
        list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        list.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        list.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) list.add(Manifest.permission.BLUETOOTH_CONNECT)
        requestPermissions(list.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        permStatus.text = permsText()
    }

    override fun onResume() {
        super.onResume()
        if (::permStatus.isInitialized) permStatus.text = permsText()
    }

    private fun openChooser() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, SysMonService::class.java)
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            try { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) } catch (_: Exception) { }
        }
    }
}
