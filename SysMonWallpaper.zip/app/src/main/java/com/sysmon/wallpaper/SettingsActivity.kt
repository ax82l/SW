package com.sysmon.wallpaper

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.EditText
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var p: SharedPreferences
    private lateinit var col: LinearLayout
    private lateinit var permStatus: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        t.setPadding(0, dp(8), 0, dp(2))
        return t
    }

    private fun slider(
        title: String, min: Int, max: Int, step: Int, key: String, def: Int,
        colorOf: (Int) -> Int = { Col.CYAN }, fmt: (Int) -> String
    ): SeekBar {
        col.addView(tv(title, 14f, Col.WHITE, true))
        val label = tv("", 13f, Col.CYAN)
        col.addView(label)
        val bar = SeekBar(this)
        bar.max = (max - min) / step
        bar.progress = ((p.getInt(key, def) - min) / step).coerceIn(0, bar.max)
        label.text = fmt(min + bar.progress * step)
        label.setTextColor(colorOf(min + bar.progress * step))
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                val value = min + v * step
                label.text = fmt(value)
                label.setTextColor(colorOf(value))
                p.edit().putInt(key, value).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(bar)
        return bar
    }

    private fun toggle(title: String, key: String, def: Boolean, hint: String) {
        val sw = Switch(this)
        sw.text = title
        sw.setTextColor(Color.WHITE)
        sw.typeface = Typeface.MONOSPACE
        sw.isChecked = p.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, c -> p.edit().putBoolean(key, c).apply() }
        sw.setPadding(0, dp(16), 0, 0)
        col.addView(sw)
        col.addView(tv(hint, 11f, Col.GRAY))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs.of(this)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = ScrollView(this)
        root.setBackgroundColor(Color.BLACK)
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(36), dp(20), dp(36))
        root.addView(col)

        col.addView(tv("ax82l@phone:~\$ sysmon --config", 15f, Col.GREEN, true))

        val tickBar = slider(
            "Refresh interval", 30, 2000, 10, Prefs.TICK, Prefs.TICK_DEF,
            colorOf = { if (it < 60) Col.RED else if (it < 250) Col.YELLOW else Col.CYAN }
        ) {
            val hz = String.format(java.util.Locale.US, "%.1f", 1000f / it)
            val warn = if (it < 60) "\n!! very heavy on battery" else if (it < 250) "\n! heavy on battery" else ""
            "$it ms  ($hz Hz)$warn"
        }
        val presets = LinearLayout(this)
        presets.orientation = LinearLayout.HORIZONTAL
        for ((name, ms) in listOf("Turbo" to 30, "Fast" to 100, "Normal" to 250, "Eco" to 1000, "Slow" to 2000)) {
            val b = Button(this)
            b.text = "$name\n$ms"
            b.isAllCaps = false
            b.textSize = 11f
            b.setOnClickListener { tickBar.progress = (ms - 30) / 10 }
            presets.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(presets)

        toggle(
            "Battery-aware auto speed", Prefs.AUTO, false,
            "charging: full speed | battery <=50%: x2 slower | <=20% or battery saver: x4 slower (max 2000 ms)"
        )

        slider("Text size", 60, 95, 5, Prefs.TEXT, Prefs.TEXT_DEF) {
            String.format(java.util.Locale.US, "%.1f sp  (shrinks automatically to fit the screen)", it / 10f)
        }
        slider("Vertical position", 6, 30, 1, Prefs.BOTTOM, Prefs.BOTTOM_DEF) {
            "$it% from bottom"
        }
        toggle("Show event log", Prefs.LOG, true, "events that print above the panel")

        // ---- أقصى تردد لكل نواة ----
        col.addView(tv("Max frequency per core (MHz)", 14f, Col.WHITE, true).apply { setPadding(0, dp(24), 0, dp(2)) })
        col.addView(tv("100% of the speed bars. Defaults: Dimensity 9200+ (A510 2000 / A715 2850 / X3 3350). 0 = auto-detect", 11f, Col.GRAY))
        val cores = (0 until 16).count { java.io.File("/sys/devices/system/cpu/cpu$it").exists() }.coerceAtLeast(1)
        var rowL: LinearLayout? = null
        for (i in 0 until cores) {
            if (i % 4 == 0) {
                rowL = LinearLayout(this)
                rowL.orientation = LinearLayout.HORIZONTAL
                col.addView(rowL)
            }
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.addView(tv("C$i", 11f, Col.GRAY))
            val et = EditText(this)
            et.inputType = InputType.TYPE_CLASS_NUMBER
            et.setText(p.getInt(Prefs.fmaxKey(i), Prefs.defaultFmax(i)).toString())
            et.setTextColor(Color.WHITE)
            et.typeface = Typeface.MONOSPACE
            et.textSize = 13f
            et.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    val v = s?.toString()?.toIntOrNull() ?: 0
                    p.edit().putInt(Prefs.fmaxKey(i), if (v in 100..6000) v else 0).apply()
                }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
            cell.addView(et)
            rowL!!.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        // ---- الصلاحيات ----
        col.addView(tv("Permissions", 14f, Col.WHITE, true).apply { setPadding(0, dp(24), 0, dp(2)) })
        permStatus = tv(permsText(), 12f, Col.CYAN)
        col.addView(permStatus)
        col.addView(tv("Location = Wi-Fi network name. Nearby devices = Bluetooth devices. If the name still shows N/A, open app settings and set Location to Allow all the time.", 11f, Col.GRAY))
        val grant = Button(this)
        grant.text = "Grant permissions"
        grant.isAllCaps = false
        grant.setOnClickListener { requestPerms() }
        col.addView(grant)
        val appSet = Button(this)
        appSet.text = "Open app settings"
        appSet.isAllCaps = false
        appSet.setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        col.addView(appSet)

        val gEd = Button(this)
        gEd.text = "Graph editor (size, range, colors, speed)"
        gEd.isAllCaps = false
        gEd.setOnClickListener { startActivity(Intent(this, GraphEditorActivity::class.java)) }
        col.addView(gEd, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) })

        val look = Button(this)
        look.text = "Background & prompt line"
        look.isAllCaps = false
        look.setOnClickListener { startActivity(Intent(this, AppearanceActivity::class.java)) }
        col.addView(look)

        val editor = Button(this)
        editor.text = "Layout, colors & log editor"
        editor.isAllCaps = false
        editor.setOnClickListener { startActivity(Intent(this, LayoutEditorActivity::class.java)) }
        col.addView(editor, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) })

        val exp = Button(this)
        exp.text = "Export all settings (copy to clipboard)"
        exp.isAllCaps = false
        exp.setOnClickListener { exportSettings() }
        col.addView(exp, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) })
        val imp = Button(this)
        imp.text = "Import settings (paste from clipboard)"
        imp.isAllCaps = false
        imp.setOnClickListener { importSettings() }
        col.addView(imp)

        val set = Button(this)
        set.text = "Set as live wallpaper"
        set.isAllCaps = false
        set.setOnClickListener { openChooser() }
        col.addView(set, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(28) })

        val reset = Button(this)
        reset.text = "Reset to defaults"
        reset.isAllCaps = false
        reset.setOnClickListener { p.edit().clear().apply(); recreate() }
        col.addView(reset)

        col.addView(tv("changes apply live to the running wallpaper", 11f, Col.GRAY))
        setContentView(root)

        if (!p.getBoolean("first_done", false)) {
            p.edit().putBoolean("first_done", true).apply()
            AlertDialog.Builder(this)
                .setTitle("First setup")
                .setMessage("1) Check the max frequency of each core below.\n2) Grant permissions to show the Wi-Fi name and Bluetooth devices.")
                .setPositiveButton("Grant permissions") { _, _ -> requestPerms() }
                .setNegativeButton("Later", null)
                .show()
        }
    }

    private fun exportSettings() {
        val sb = StringBuilder("SYSMON1\n")
        var n = 0
        for ((k, v) in p.all) {
            val t = when (v) {
                is Boolean -> "b"
                is Int -> "i"
                is Long -> "l"
                is Float -> "f"
                is String -> "s"
                else -> continue
            }
            sb.append(k).append('|').append(t).append('|')
                .append(java.net.URLEncoder.encode(v.toString(), "UTF-8")).append('\n')
            n++
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("sysmon", sb.toString()))
        Toast.makeText(this, "Copied $n settings. Paste them somewhere safe.", Toast.LENGTH_LONG).show()
    }

    private fun importSettings() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val txt = try { cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: "" } catch (e: Exception) { "" }
        if (!txt.startsWith("SYSMON1")) {
            Toast.makeText(this, "Clipboard has no SysMon settings", Toast.LENGTH_LONG).show()
            return
        }
        val e = p.edit()
        var n = 0
        for (line in txt.lineSequence().drop(1)) {
            val parts = line.split("|")
            if (parts.size != 3) continue
            val v = try { java.net.URLDecoder.decode(parts[2], "UTF-8") } catch (ex: Exception) { continue }
            when (parts[1]) {
                "b" -> e.putBoolean(parts[0], v == "true")
                "i" -> { val x = v.toIntOrNull() ?: continue; e.putInt(parts[0], x) }
                "l" -> { val x = v.toLongOrNull() ?: continue; e.putLong(parts[0], x) }
                "f" -> { val x = v.toFloatOrNull() ?: continue; e.putFloat(parts[0], x) }
                "s" -> e.putString(parts[0], v)
                else -> continue
            }
            n++
        }
        e.apply()
        Toast.makeText(this, "Imported $n settings", Toast.LENGTH_LONG).show()
        recreate()
    }

    private fun permsText(): String {
        fun ok(perm: String) = checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
        val loc = ok(Manifest.permission.ACCESS_FINE_LOCATION)
        val bt = if (Build.VERSION.SDK_INT >= 31) ok(Manifest.permission.BLUETOOTH_CONNECT) else true
        return "location: " + (if (loc) "granted" else "missing") + "  |  bluetooth: " + (if (bt) "granted" else "missing")
    }

    private fun requestPerms() {
        val list = ArrayList<String>()
        list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        list.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) list.add(Manifest.permission.BLUETOOTH_CONNECT)
        requestPermissions(list.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        permStatus.text = permsText()
    }

    override fun onResume() {
        super.onResume()
        if (::permStatus.isInitialized) permStatus.text = permsText()
    }

    private fun openChooser() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, SysMonService::class.java)
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            try { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) } catch (_: Exception) { }
        }
    }
}
