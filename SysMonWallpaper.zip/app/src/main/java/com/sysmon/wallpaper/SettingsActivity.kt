package com.sysmon.wallpaper

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * الشاشة الرئيسية للإعدادات: رأس + حالة الصلاحيات + أزرار الشاشات الأخرى
 * + أقسام قابلة للطي (التحديث، النص والتخطيط، ملاحظات المخططات، ترددات الأنوية، وضع الاختبار).
 * مفاتيح الإعدادات وسلوكها كما هي تماماً؛ التغيير في الشكل والترتيب فقط.
 */
class SettingsActivity : Activity() {

    private lateinit var p: SharedPreferences
    private lateinit var ui: SharedPreferences
    private lateinit var permRow: LinearLayout
    private lateinit var permButtons: LinearLayout

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs.of(this)
        ui = getSharedPreferences("sysmon_ui", Context.MODE_PRIVATE)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = ScrollView(this)
        root.setBackgroundColor(Ui.BG)
        root.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(32), dp(16), dp(40))
        root.addView(col)

        // ---------- الرأس ----------
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        col.addView(Ui.text(this, "ax82l@phone:~\$ sysmon --config", 15f, Col.GREEN, true))
        col.addView(
            Ui.text(this, (if (ver.isNotEmpty()) "v$ver  \u00B7  " else "") + "changes apply live to the wallpaper", 11f, Ui.DIM),
            Ui.lp(this, top = 4, bottom = 16)
        )
        col.addView(Ui.button(this, "Set as live wallpaper", Ui.PRIMARY) { openChooser() })

        // ---------- الصلاحيات ----------
        val permCard = LinearLayout(this)
        permCard.orientation = LinearLayout.VERTICAL
        permCard.setPadding(dp(14), dp(14), dp(14), dp(14))
        permCard.background = Ui.shape(this, Ui.CARD, Ui.STROKE, 12)
        permCard.addView(Ui.text(this, "Permissions", 14f, Col.WHITE, true))
        permRow = LinearLayout(this)
        permRow.orientation = LinearLayout.HORIZONTAL
        permCard.addView(permRow, Ui.lp(this, top = 10))
        permCard.addView(
            Ui.text(
                this,
                "Location = Wi-Fi name. Nearby devices = Bluetooth. Audio only gates the sound spectrum; nothing is recorded. " +
                    "If the Wi-Fi name still shows N/A, set Location to \"Allow all the time\" in app settings.",
                11f, Ui.DIM
            ),
            Ui.lp(this, top = 10)
        )
        permButtons = LinearLayout(this)
        permButtons.orientation = LinearLayout.HORIZONTAL
        permButtons.addView(Ui.button(this, "Grant", Ui.SECONDARY) { requestPerms() }, Ui.lp(this, weight = 1f, end = 4))
        permButtons.addView(Ui.button(this, "App settings", Ui.SECONDARY) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, Ui.lp(this, weight = 1f, start = 4))
        permCard.addView(permButtons, Ui.lp(this, top = 12))
        col.addView(permCard, Ui.lp(this, top = 14))

        // ---------- الشاشات الأخرى ----------
        col.addView(Ui.label(this, "customize"), Ui.lp(this, top = 24, bottom = 8))
        col.addView(Ui.navRow(this, "Layout, colors & log", "lines, columns, color rules, log filters") {
            startActivity(Intent(this, LayoutEditorActivity::class.java))
        })
        col.addView(Ui.navRow(this, "Graph editor", "size, range, colors, speed, auto zoom") {
            startActivity(Intent(this, GraphEditorActivity::class.java))
        }, Ui.lp(this, top = 8))
        col.addView(Ui.navRow(this, "Background & prompt line", "background color, name, prompt colors") {
            startActivity(Intent(this, AppearanceActivity::class.java))
        }, Ui.lp(this, top = 8))
        col.addView(Ui.navRow(this, "Profiles, import & export", "save, share and restore your setup") {
            startActivity(Intent(this, ProfilesActivity::class.java))
        }, Ui.lp(this, top = 8))

        // ---------- الأقسام ----------
        col.addView(Ui.label(this, "settings"), Ui.lp(this, top = 24, bottom = 8))
        col.addView(refreshSection().view)
        col.addView(textSection().view, Ui.lp(this, top = 10))
        col.addView(graphNotesSection().view, Ui.lp(this, top = 10))
        col.addView(coresSection().view, Ui.lp(this, top = 10))
        col.addView(testSection().view, Ui.lp(this, top = 10))

        // ---------- التذييل ----------
        col.addView(Ui.button(this, "Reset to defaults", Ui.DANGER) {
            AlertDialog.Builder(this)
                .setTitle("Reset to defaults?")
                .setMessage("All settings, layout and colors go back to the default profile.")
                .setPositiveButton("Reset") { _, _ -> SettingsIO.loadDefaults(p); recreate() }
                .setNegativeButton("Cancel", null)
                .show()
        }, Ui.lp(this, top = 28))

        setContentView(root)
        refreshPerms()

        if (!p.getBoolean("first_done", false)) {
            p.edit().putBoolean("first_done", true).apply()
            AlertDialog.Builder(this)
                .setTitle("First setup")
                .setMessage("1) Grant permissions to show the Wi-Fi name and Bluetooth devices.\n2) Check the max frequency of each core under Settings > CPU max frequency.")
                .setPositiveButton("Grant permissions") { _, _ -> requestPerms() }
                .setNegativeButton("Later", null)
                .show()
        }
    }

    // ================= الأقسام =================

    private fun refreshSection(): Section {
        val s = Section(this, "Refresh", "speed of the wallpaper updates", ui, true)

        val chips = ArrayList<Pair<TextView, Int>>()
        val tick = Ui.slider(
            this, p, "Refresh interval", 30, 2000, 10, Prefs.TICK, Prefs.TICK_DEF,
            colorOf = { if (it < 60) Col.RED else if (it < 250) Col.YELLOW else Col.CYAN },
            note = { if (it < 60) "!! very heavy on battery" else if (it < 250) "! heavy on battery" else "" },
            onChange = { v -> for ((t, ms) in chips) Ui.presetStyle(this, t, ms == v) }
        ) {
            val hz = String.format(java.util.Locale.US, "%.1f", 1000f / it)
            "$it ms \u00B7 $hz Hz"
        }
        s.add(tick.view, 4)

        val presets = LinearLayout(this)
        presets.orientation = LinearLayout.HORIZONTAL
        for ((name, ms) in listOf("Turbo" to 30, "Fast" to 100, "Normal" to 250, "Eco" to 1000, "Slow" to 2000)) {
            val chip = Ui.presetChip(this, "$name\n$ms") { tick.bar.progress = (ms - 30) / 10 }
            chips.add(chip to ms)
            presets.addView(chip, Ui.lp(this, weight = 1f, start = 2, end = 2))
        }
        s.add(presets, 12)
        // يضبط تمييز الشريحة الحالية بعد إنشائها
        val cur = p.getInt(Prefs.TICK, Prefs.TICK_DEF)
        for ((t, ms) in chips) Ui.presetStyle(this, t, ms == cur)

        s.add(
            Ui.toggle(
                this, p, "Battery-aware auto speed", Prefs.AUTO, false,
                "charging: full speed \u00B7 battery <=50%: x2 slower \u00B7 <=20% or battery saver: x4 slower (max 2000 ms)"
            ), 18
        )

        s.add(
            Ui.slider(
                this, p, "Clock row refresh", 4, 1000, 1, Prefs.CLK_MS, Prefs.CLK_MS_DEF,
                hint = "only the clock line, and only while the Clock block is shown",
                colorOf = { if (it < 16) Col.RED else if (it < 50) Col.YELLOW else Col.CYAN },
                note = { if (it < 16) "!! very heavy on battery" else if (it < 50) "! heavy on battery" else "" }
            ) { "$it ms" }.view, 18
        )
        return s
    }

    private fun textSection(): Section {
        val s = Section(this, "Text & layout", "font size, spacing, widths, position", ui, false)
        s.add(Ui.slider(this, p, "Text size", 30, 140, 1, Prefs.TEXT, Prefs.TEXT_DEF,
            hint = "never bigger than what fits the total width") {
            String.format(java.util.Locale.US, "%.1f sp", it / 10f)
        }.view, 4)
        s.add(Ui.slider(this, p, "Line spacing", 70, 160, 1, "lsp", 105) { "$it%" }.view)
        s.add(Ui.slider(this, p, "Total width", 40, 200, 1, "cols_t", 75,
            hint = "more characters = smaller text, more room for graph notes") { "$it chars" }.view)
        s.add(Ui.slider(this, p, "Left column width", 16, 150, 1, "cols_l", 38,
            hint = "the right column gets the rest") { "$it chars" }.view)
        s.add(Ui.slider(this, p, "Graph note text size", 30, 120, 5, "note_pct", 70) { "$it%" }.view)
        s.add(Ui.slider(this, p, "Event log text size", 40, 160, 5, "log_pct", 100) { "$it%" }.view)
        s.add(Ui.slider(this, p, "Vertical position", 6, 30, 1, Prefs.BOTTOM, Prefs.BOTTOM_DEF) { "$it% from bottom" }.view)
        s.add(Ui.toggle(this, p, "Show event log", Prefs.LOG, true, "events that print above the panel"), 18)
        return s
    }

    private fun graphNotesSection(): Section {
        val s = Section(this, "Graph notes", "range + time shown after each graph", ui, false)
        s.add(
            Ui.text(
                this,
                "Quick switch for every graph at once. Each graph keeps its own details in the Graph editor (auto zoom, style, decimals ...).",
                11f, Ui.DIM
            ), 4
        )
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun bulk(text: String, range: Boolean, time: Boolean, zoom: Boolean?, first: Boolean) {
            val b = Ui.button(this, text, Ui.SECONDARY) {
                for (d in Graphs.all) {
                    if (d.id == "spec") continue
                    val g = Graphs.get(p, d.id).copy()
                    g.nRange = range
                    g.nTime = time
                    if (zoom != null) g.azOn = zoom
                    Graphs.save(p, d.id, g)
                }
                Toast.makeText(this, "Applied: $text", Toast.LENGTH_SHORT).show()
            }
            b.textSize = 12f
            row.addView(b, Ui.lp(this, weight = 1f, start = if (first) 0 else 3, end = 3))
        }
        bulk("Range+time", true, true, null, true)
        bulk("All off", false, false, false, false)
        bulk("+ zoom", true, true, true, false)
        s.add(row, 12)
        return s
    }

    private fun coresSection(): Section {
        val s = Section(this, "CPU max frequency", "100% of the speed bars, per core (MHz)", ui, false)
        s.add(
            Ui.text(
                this,
                "Defaults: Dimensity 9200+ (A510 2000 / A715 2850 / X3 3350). 0 = auto-detect.",
                11f, Ui.DIM
            ), 4
        )
        val cores = (0 until 16).count { java.io.File("/sys/devices/system/cpu/cpu$it").exists() }.coerceAtLeast(1)
        var rowL: LinearLayout? = null
        var inRow = 0
        for (i in 0 until cores) {
            if (i % 4 == 0) {
                rowL = LinearLayout(this)
                rowL.orientation = LinearLayout.HORIZONTAL
                s.add(rowL, if (i == 0) 12 else 8)
                inRow = 0
            }
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.addView(Ui.text(this, "C$i", 11f, Ui.DIM, true), Ui.lp(this, bottom = 3))
            val et = EditText(this)
            et.inputType = InputType.TYPE_CLASS_NUMBER
            et.setText(p.getInt(Prefs.fmaxKey(i), Prefs.defaultFmax(i)).toString())
            et.setTextColor(Col.WHITE)
            et.typeface = android.graphics.Typeface.MONOSPACE
            et.textSize = 13f
            et.gravity = Gravity.CENTER
            et.setSingleLine()
            et.setPadding(dp(4), dp(8), dp(4), dp(8))
            et.background = Ui.shape(this, 0xFF0A0B0D.toInt(), Ui.STROKE_STRONG, 8)
            et.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    val v = s?.toString()?.toIntOrNull() ?: 0
                    p.edit().putInt(Prefs.fmaxKey(i), if (v in 100..6000) v else 0).apply()
                }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
            cell.addView(et)
            rowL!!.addView(cell, Ui.lp(this, weight = 1f, start = 3, end = 3))
            inRow++
            // املأ الصف الأخير بخلايا فارغة ليبقى عرض الخلايا متساوياً
            if (i == cores - 1) {
                while (inRow < 4) {
                    rowL.addView(View(this), Ui.lp(this, weight = 1f, start = 3, end = 3))
                    inRow++
                }
            }
        }
        return s
    }

    private fun testSection(): Section {
        val s = Section(this, "Test mode", "fake fast-changing data for every block", ui, false)
        s.add(
            Ui.toggle(
                this, p, "TEST MODE (fake data)", "test_mode", false,
                "uses your layout, colors and graph settings and changes none of them. Turn it off to see real data again."
            ), 4
        )
        s.add(Ui.slider(this, p, "Test mode speed", 1, 20, 1, "test_speed", 6) { "x$it" }.view)
        return s
    }

    // ================= الصلاحيات =================

    private fun granted(perm: String) = checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    private fun refreshPerms() {
        val loc = granted(Manifest.permission.ACCESS_FINE_LOCATION)
        val bt = if (Build.VERSION.SDK_INT >= 31) granted(Manifest.permission.BLUETOOTH_CONNECT) else true
        val mic = granted(Manifest.permission.RECORD_AUDIO)
        permRow.removeAllViews()
        fun add(name: String, ok: Boolean) {
            permRow.addView(
                Ui.chip(this, (if (ok) "\u25CF " else "\u25CB ") + name, if (ok) Col.GREEN else Col.RED),
                Ui.lp(this, end = 8)
            )
        }
        add("location", loc)
        add("bluetooth", bt)
        add("audio", mic)
    }

    private fun requestPerms() {
        val list = ArrayList<String>()
        list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        list.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        list.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) list.add(Manifest.permission.BLUETOOTH_CONNECT)
        requestPermissions(list.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshPerms()
    }

    override fun onResume() {
        super.onResume()
        if (::permRow.isInitialized) refreshPerms()
    }

    private fun openChooser() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, SysMonService::class.java)
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            try { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) } catch (ex: Exception) { }
        }
    }
}
