package com.sysmon.wallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var p: SharedPreferences
    private lateinit var col: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        t.setPadding(0, dp(8), 0, dp(2))
        return t
    }

    private fun slider(
        title: String, min: Int, max: Int, step: Int, key: String, def: Int,
        colorOf: (Int) -> Int = { Col.CYAN }, fmt: (Int) -> String
    ): SeekBar {
        col.addView(tv(title, 14f, Col.WHITE, true))
        val label = tv("", 13f, Col.CYAN)
        col.addView(label)
        val bar = SeekBar(this)
        bar.max = (max - min) / step
        bar.progress = ((p.getInt(key, def) - min) / step).coerceIn(0, bar.max)
        label.text = fmt(min + bar.progress * step)
        label.setTextColor(colorOf(min + bar.progress * step))
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                val value = min + v * step
                label.text = fmt(value)
                label.setTextColor(colorOf(value))
                p.edit().putInt(key, value).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(bar)
        return bar
    }

    private fun toggle(title: String, key: String, def: Boolean, hint: String) {
        val sw = Switch(this)
        sw.text = title
        sw.setTextColor(Color.WHITE)
        sw.typeface = Typeface.MONOSPACE
        sw.isChecked = p.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, c -> p.edit().putBoolean(key, c).apply() }
        sw.setPadding(0, dp(16), 0, 0)
        col.addView(sw)
        col.addView(tv(hint, 11f, Col.GRAY))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs.of(this)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = ScrollView(this)
        root.setBackgroundColor(Color.BLACK)
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(36), dp(20), dp(36))
        root.addView(col)

        col.addView(tv("ax82l@phone:~\$ sysmon --config", 15f, Col.GREEN, true))

        val tickBar = slider(
            "Refresh interval", 30, 2000, 10, Prefs.TICK, Prefs.TICK_DEF,
            colorOf = { if (it < 60) Col.RED else if (it < 250) Col.YELLOW else Col.CYAN }
        ) {
            val hz = String.format(java.util.Locale.US, "%.1f", 1000f / it)
            val warn = if (it < 60) "\n!! very heavy on battery" else if (it < 250) "\n! heavy on battery" else ""
            "$it ms  ($hz Hz)$warn"
        }
        val presets = LinearLayout(this)
        presets.orientation = LinearLayout.HORIZONTAL
        for ((name, ms) in listOf("Turbo" to 30, "Fast" to 100, "Normal" to 250, "Eco" to 1000, "Slow" to 2000)) {
            val b = Button(this)
            b.text = "$name\n$ms"
            b.isAllCaps = false
            b.textSize = 11f
            b.setOnClickListener { tickBar.progress = (ms - 30) / 10 }
            presets.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(presets)

        toggle(
            "Battery-aware auto speed", Prefs.AUTO, false,
            "charging: full speed | battery <=50%: x2 slower | <=20% or battery saver: x4 slower (max 2000 ms)"
        )

        slider("Text size", 60, 95, 5, Prefs.TEXT, Prefs.TEXT_DEF) {
            String.format(java.util.Locale.US, "%.1f sp  (shrinks automatically to fit the screen)", it / 10f)
        }
        slider("Vertical position", 6, 30, 1, Prefs.BOTTOM, Prefs.BOTTOM_DEF) {
            "$it% from bottom"
        }
        toggle("Show event log", Prefs.LOG, true, "events that print above the panel")

        val set = Button(this)
        set.text = "Set as live wallpaper"
        set.isAllCaps = false
        set.setOnClickListener { openChooser() }
        col.addView(set, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(28) })

        val reset = Button(this)
        reset.text = "Reset to defaults"
        reset.isAllCaps = false
        reset.setOnClickListener { p.edit().clear().apply(); recreate() }
        col.addView(reset)

        col.addView(tv("changes apply live to the running wallpaper", 11f, Col.GRAY))
        setContentView(root)
    }

    private fun openChooser() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, SysMonService::class.java)
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            try { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) } catch (_: Exception) { }
        }
    }
}
