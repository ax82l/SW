package com.sysmon.wallpaper

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class LayoutEditorActivity : Activity() {

    private lateinit var p: SharedPreferences
    private lateinit var scroll: ScrollView
    private lateinit var col: LinearLayout
    private lateinit var layout: Layout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        t.setPadding(0, dp(8), 0, dp(2))
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs.of(this)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(32), dp(16), dp(32))
        scroll.addView(col)
        setContentView(scroll)
        layout = LayoutStore.load(p)
        render()
    }

    private fun save() = LayoutStore.save(p, layout)

    private fun render() {
        val y = scroll.scrollY
        col.removeAllViews()
        col.addView(tv("ax82l@phone:~\$ sysmon --layout", 15f, Col.GREEN, true))
        col.addView(tv("switch = show/hide  |  up/down = reorder  |  >> << = other column  |  dot = color (A = auto)", 11f, Col.GRAY))
        section("LEFT column", layout.left, true)
        section("RIGHT column", layout.right, false)
        logSection()

        val reset = Button(this)
        reset.text = "Reset layout, colors & log filters"
        reset.isAllCaps = false
        reset.setOnClickListener {
            p.edit().remove(LayoutStore.KEY_L).remove(LayoutStore.KEY_R).remove(Prefs.LOGOFF).apply()
            layout = LayoutStore.defaults()
            render()
        }
        col.addView(reset, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) })
        col.addView(tv("changes apply live to the wallpaper", 11f, Col.GRAY))
        scroll.post { scroll.scrollTo(0, y) }
    }

    private fun btn(text: String, color: Int = Col.WHITE, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.textSize = 16f
        b.setTextColor(color)
        b.gravity = Gravity.CENTER
        b.minWidth = dp(38)
        b.setPadding(dp(6), dp(10), dp(6), dp(10))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun section(title: String, list: MutableList<Item>, isLeft: Boolean) {
        col.addView(tv(title, 14f, Col.CYAN, true).apply { setPadding(0, dp(22), 0, dp(4)) })
        for (idx in list.indices) col.addView(itemRow(list, idx, isLeft))
    }

    private fun itemRow(list: MutableList<Item>, idx: Int, isLeft: Boolean): View {
        val item = list[idx]
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val name = TextView(this)
        name.text = Blocks.label(item.id)
        name.textSize = 12f
        name.typeface = Typeface.MONOSPACE
        name.setTextColor(if (item.on) Color.WHITE else Col.GRAY)

        val sw = Switch(this)
        sw.isChecked = item.on
        sw.setOnCheckedChangeListener { _, c ->
            item.on = c
            name.setTextColor(if (c) Color.WHITE else Col.GRAY)
            save()
        }
        row.addView(sw)
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        row.addView(btn("▲") {
            if (idx > 0) { list.removeAt(idx); list.add(idx - 1, item); save(); render() }
        })
        row.addView(btn("▼") {
            if (idx < list.size - 1) { list.removeAt(idx); list.add(idx + 1, item); save(); render() }
        })
        row.addView(btn(if (isLeft) ">>" else "<<") {
            list.removeAt(idx)
            (if (isLeft) layout.right else layout.left).add(item)
            save(); render()
        })
        row.addView(
            if (item.color == 0) btn("A", Col.GRAY) { pickColor(item) } else btn("●", item.color) { pickColor(item) }
        )
        return row
    }

    private fun pickColor(item: Item) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val dlg = AlertDialog.Builder(this)
            .setTitle("Color: " + Blocks.label(item.id))
            .setView(box)
            .setNegativeButton("Cancel", null)
            .create()

        val palette = listOf(
            0 to "Auto", Col.GREEN to "Green", Col.YELLOW to "Yellow", Col.RED to "Red",
            Col.CYAN to "Cyan", Col.BLUE to "Blue", Col.WHITE to "White", 0xFFFF9100.toInt() to "Orange",
            0xFFFF4081.toInt() to "Pink", 0xFFB388FF.toInt() to "Purple", 0xFFC6FF00.toInt() to "Lime", 0xFF8A8A8A.toInt() to "Gray"
        )
        var rowL: LinearLayout? = null
        for ((i, pc) in palette.withIndex()) {
            if (i % 4 == 0) {
                rowL = LinearLayout(this)
                rowL.orientation = LinearLayout.HORIZONTAL
                box.addView(rowL)
            }
            val sq = TextView(this)
            sq.text = pc.second
            sq.textSize = 11f
            sq.gravity = Gravity.CENTER
            sq.setTextColor(if (pc.first == 0) Color.WHITE else Color.BLACK)
            sq.setBackgroundColor(if (pc.first == 0) 0xFF333333.toInt() else pc.first)
            sq.setPadding(0, dp(14), 0, dp(14))
            sq.setOnClickListener { item.color = pc.first; save(); dlg.dismiss(); render() }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            rowL!!.addView(sq, lp)
        }

        val hex = EditText(this)
        hex.hint = "custom hex, e.g. FF8800"
        hex.setTextColor(Color.WHITE)
        hex.setHintTextColor(Col.GRAY)
        hex.typeface = Typeface.MONOSPACE
        box.addView(hex)
        val apply = Button(this)
        apply.text = "Apply custom color"
        apply.isAllCaps = false
        apply.setOnClickListener {
            try {
                item.color = Color.parseColor("#" + hex.text.toString().trim().removePrefix("#"))
                save(); dlg.dismiss(); render()
            } catch (e: Exception) {
                hex.error = "invalid"
            }
        }
        box.addView(apply)
        dlg.show()
    }

    private fun hiddenSet(): MutableSet<String> =
        (p.getString(Prefs.LOGOFF, "") ?: "").split(",").filter { it.isNotEmpty() }.toMutableSet()

    private fun logSection() {
        col.addView(tv("LOG events (what prints above the panel)", 14f, Col.CYAN, true).apply { setPadding(0, dp(22), 0, dp(4)) })
        val hidden = hiddenSet()
        for ((tag, desc) in LogTags.all) {
            val sw = Switch(this)
            sw.text = tag.padEnd(6) + desc
            sw.textSize = 12f
            sw.typeface = Typeface.MONOSPACE
            sw.setTextColor(Color.WHITE)
            sw.isChecked = !hidden.contains(tag)
            sw.setOnCheckedChangeListener { _, c ->
                val h = hiddenSet()
                if (c) h.remove(tag) else h.add(tag)
                p.edit().putString(Prefs.LOGOFF, h.joinToString(",")).apply()
            }
            sw.setPadding(0, dp(6), 0, dp(6))
            col.addView(sw)
        }
    }
}
