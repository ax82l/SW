package com.sysmon.wallpaper

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import android.text.InputType
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class LayoutEditorActivity : Activity() {

    private lateinit var p: SharedPreferences
    private lateinit var scroll: ScrollView
    private lateinit var col: LinearLayout
    private lateinit var layout: Layout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        t.setPadding(0, dp(8), 0, dp(2))
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs.of(this)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(32), dp(16), dp(32))
        scroll.addView(col)
        setContentView(scroll)
        layout = LayoutStore.load(p)
        render()
    }

    private fun save() = LayoutStore.save(p, layout)

    private fun render() {
        val y = scroll.scrollY
        col.removeAllViews()
        col.addView(tv("ax82l@phone:~\$ sysmon --layout", 15f, Col.GREEN, true))
        col.addView(tv("switch = show/hide  |  up/down = reorder  |  >> << = other column  |  dot = one color for all  |  ... = colors per part  |  gear = show/hide each field + color rules", 11f, Col.GRAY))
        section("LEFT column", layout.left, true)
        section("RIGHT column", layout.right, false)
        logSection()
        logColorSection()
        diagSection()

        val reset = Button(this)
        reset.text = "Reset layout, field colors & log filters/colors"
        reset.isAllCaps = false
        reset.setOnClickListener {
            p.edit().remove(LayoutStore.KEY_L).remove(LayoutStore.KEY_R).remove(Prefs.LOGOFF).remove(Prefs.LOG_LINES).remove(Prefs.LOG_SOLID).apply()
            FieldCfg.clearAll(p)
            val ed = p.edit()
            for (k in p.all.keys) if (k.startsWith("lc_")) ed.remove(k)
            ed.apply()
            layout = LayoutStore.defaults()
            render()
        }
        col.addView(reset, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) })
        col.addView(tv("changes apply live to the wallpaper", 11f, Col.GRAY))
        scroll.post { scroll.scrollTo(0, y) }
    }

    private fun btn(text: String, color: Int = Col.WHITE, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.textSize = 16f
        b.setTextColor(color)
        b.gravity = Gravity.CENTER
        b.minWidth = dp(38)
        b.setPadding(dp(6), dp(10), dp(6), dp(10))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun section(title: String, list: MutableList<Item>, isLeft: Boolean) {
        col.addView(tv(title, 14f, Col.CYAN, true).apply { setPadding(0, dp(22), 0, dp(4)) })
        for (idx in list.indices) col.addView(itemRow(list, idx, isLeft))
    }

    private fun itemRow(list: MutableList<Item>, idx: Int, isLeft: Boolean): View {
        val item = list[idx]
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val name = TextView(this)
        name.text = Blocks.label(item.id)
        name.textSize = 12f
        name.typeface = Typeface.MONOSPACE
        name.setTextColor(if (item.on) Color.WHITE else Col.GRAY)

        val sw = Switch(this)
        sw.isChecked = item.on
        sw.setOnCheckedChangeListener { _, c ->
            item.on = c
            name.setTextColor(if (c) Color.WHITE else Col.GRAY)
            save()
        }
        row.addView(sw)
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        row.addView(btn("▲") {
            if (idx > 0) { list.removeAt(idx); list.add(idx - 1, item); save(); render() }
        })
        row.addView(btn("▼") {
            if (idx < list.size - 1) { list.removeAt(idx); list.add(idx + 1, item); save(); render() }
        })
        row.addView(btn(if (isLeft) ">>" else "<<") {
            list.removeAt(idx)
            (if (isLeft) layout.right else layout.left).add(item)
            save(); render()
        })
        row.addView(
            if (item.color == 0) btn("A", Col.GRAY) { pickColor(item) } else btn("●", item.color) { pickColor(item) }
        )
        row.addView(btn("⋯") { roleDialog(item) })
        if (Fields.of(item.id).isNotEmpty()) row.addView(btn("⚙", Col.CYAN) { fieldsDialog(item) })
        return row
    }

    private fun roleDialog(item: Item) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val dlg = AlertDialog.Builder(this)
            .setTitle("Colors: " + Blocks.label(item.id))
            .setView(box)
            .setPositiveButton("Done", null)
            .create()
        dlg.setOnDismissListener { render() }

        fun addRow(label: String, get: () -> Int, set: (Int) -> Unit) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            val name = TextView(this)
            name.text = label
            name.textSize = 12f
            name.setTextColor(Color.WHITE)
            name.typeface = Typeface.MONOSPACE
            r.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val sw = TextView(this)
            val cur = get()
            sw.text = if (cur == 0) "  Auto  " else "  #" + String.format("%06X", cur and 0xFFFFFF) + "  "
            sw.textSize = 12f
            sw.typeface = Typeface.MONOSPACE
            sw.setPadding(dp(6), dp(10), dp(6), dp(10))
            if (cur == 0) {
                sw.setBackgroundColor(0xFF333333.toInt())
                sw.setTextColor(Color.WHITE)
            } else {
                sw.setBackgroundColor(cur or 0xFF000000.toInt())
                sw.setTextColor(if (Contrast.lum(cur) > 0.4f) Color.BLACK else Color.WHITE)
            }
            sw.setOnClickListener {
                ColorDialog.show(this, label, "Auto") { c ->
                    set(c)
                    save()
                    dlg.setOnDismissListener(null)
                    dlg.dismiss()
                    roleDialog(item)
                }
            }
            r.addView(sw)
            r.setPadding(0, dp(6), 0, dp(6))
            box.addView(r)
        }
        addRow("All text + graphs", { item.color }, { item.color = it })
        addRow("Label (CPU, RAM, ...)", { item.cL }, { item.cL = it })
        addRow("Value", { item.cV }, { item.cV = it })
        addRow("Dim / extra text", { item.cX }, { item.cX = it })
        val hint = TextView(this)
        hint.text = "A part set to Auto keeps its smart color. A specific part wins over All."
        hint.textSize = 11f
        hint.setTextColor(Col.GRAY)
        box.addView(hint)
        dlg.show()
    }

    private fun pickColor(item: Item) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val dlg = AlertDialog.Builder(this)
            .setTitle("Color: " + Blocks.label(item.id))
            .setView(box)
            .setNegativeButton("Cancel", null)
            .create()

        val palette = listOf(
            0 to "Auto", Col.GREEN to "Green", Col.YELLOW to "Yellow", Col.RED to "Red",
            Col.CYAN to "Cyan", Col.BLUE to "Blue", Col.WHITE to "White", 0xFFFF9100.toInt() to "Orange",
            0xFFFF4081.toInt() to "Pink", 0xFFB388FF.toInt() to "Purple", 0xFFC6FF00.toInt() to "Lime", 0xFF8A8A8A.toInt() to "Gray"
        )
        var rowL: LinearLayout? = null
        for ((i, pc) in palette.withIndex()) {
            if (i % 4 == 0) {
                rowL = LinearLayout(this)
                rowL.orientation = LinearLayout.HORIZONTAL
                box.addView(rowL)
            }
            val sq = TextView(this)
            sq.text = pc.second
            sq.textSize = 11f
            sq.gravity = Gravity.CENTER
            sq.setTextColor(if (pc.first == 0) Color.WHITE else Color.BLACK)
            sq.setBackgroundColor(if (pc.first == 0) 0xFF333333.toInt() else pc.first)
            sq.setPadding(0, dp(14), 0, dp(14))
            sq.setOnClickListener { item.color = pc.first; save(); dlg.dismiss(); render() }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            rowL!!.addView(sq, lp)
        }

        val hex = EditText(this)
        hex.hint = "custom hex, e.g. FF8800"
        hex.setTextColor(Color.WHITE)
        hex.setHintTextColor(Col.GRAY)
        hex.typeface = Typeface.MONOSPACE
        box.addView(hex)
        val apply = Button(this)
        apply.text = "Apply custom color"
        apply.isAllCaps = false
        apply.setOnClickListener {
            try {
                item.color = Color.parseColor("#" + hex.text.toString().trim().removePrefix("#"))
                save(); dlg.dismiss(); render()
            } catch (e: Exception) {
                hex.error = "invalid"
            }
        }
        box.addView(apply)
        dlg.show()
    }

    private fun hiddenSet(): MutableSet<String> =
        (p.getString(Prefs.LOGOFF, Prefs.LOGOFF_DEF) ?: "").split(",").filter { it.isNotEmpty() }.toMutableSet()

    private fun logSlider(title: String, min: Int, max: Int, key: String, def: Int, fmt: (Int) -> String) {
        col.addView(tv(title, 13f, Col.WHITE, true))
        val label = tv("", 12f, Col.CYAN)
        col.addView(label)
        val bar = SeekBar(this)
        bar.max = max - min
        bar.progress = (p.getInt(key, def) - min).coerceIn(0, bar.max)
        label.text = fmt(min + bar.progress)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                label.text = fmt(min + v)
                p.edit().putInt(key, min + v).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(bar)
    }

    private fun logSection() {
        col.addView(tv("LOG events (what prints above the panel)", 14f, Col.CYAN, true).apply { setPadding(0, dp(22), 0, dp(4)) })
        logSlider("Max visible log lines", 0, 80, Prefs.LOG_LINES, Prefs.LOG_LINES_DEF) { "$it lines" }
        logSlider("Lines kept fully visible (fade starts after)", 0, 80, Prefs.LOG_SOLID, Prefs.LOG_SOLID_DEF) {
            if (it == 0) "0 - fade starts at the newest line" else "$it newest lines stay solid, older ones fade out"
        }
        col.addView(tv("the last visible line is the faintest; older lines are dropped. Fully-visible count is capped by the max above", 11f, Col.GRAY))
        val hidden = hiddenSet()
        for ((tag, desc) in LogTags.all) {
            val sw = Switch(this)
            sw.text = tag.padEnd(6) + desc
            sw.textSize = 12f
            sw.typeface = Typeface.MONOSPACE
            sw.setTextColor(Color.WHITE)
            sw.isChecked = !hidden.contains(tag)
            sw.setOnCheckedChangeListener { _, c ->
                val h = hiddenSet()
                if (c) h.remove(tag) else h.add(tag)
                p.edit().putString(Prefs.LOGOFF, h.joinToString(",")).apply()
            }
            sw.setPadding(0, dp(6), 0, dp(6))
            col.addView(sw)
        }
    }

    // ====================== حقول البلوك: إخفاء + قواعد ألوان ======================

    private fun colorChip(c: Int, autoText: String = "Auto", onClick: () -> Unit): TextView {
        val sw = TextView(this)
        sw.text = if (c == 0) "  $autoText  " else "  #" + String.format("%06X", c and 0xFFFFFF) + "  "
        sw.textSize = 12f
        sw.typeface = Typeface.MONOSPACE
        sw.setPadding(dp(6), dp(10), dp(6), dp(10))
        if (c == 0) {
            sw.setBackgroundColor(0xFF333333.toInt())
            sw.setTextColor(Color.WHITE)
        } else {
            sw.setBackgroundColor(c or 0xFF000000.toInt())
            sw.setTextColor(if (Contrast.lum(c) > 0.4f) Color.BLACK else Color.WHITE)
        }
        sw.setOnClickListener { onClick() }
        return sw
    }

    private fun fieldsDialog(item: Item) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sc = ScrollView(this)
        sc.addView(box)
        val dlg = AlertDialog.Builder(this)
            .setTitle("Fields: " + Blocks.label(item.id))
            .setView(sc)
            .setPositiveButton("Done", null)
            .create()
        box.addView(tv("switch = show / hide this part of the line.  Color = rules that pick the color (charging, above a value, ...).", 11f, Col.GRAY))
        for (fd in Fields.of(item.id)) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            val sw = Switch(this)
            sw.text = fd.label
            sw.textSize = 12f
            sw.typeface = Typeface.MONOSPACE
            sw.setTextColor(Color.WHITE)
            sw.isChecked = !FieldCfg.hidden(p, item.id, fd.id)
            sw.setOnCheckedChangeListener { _, c -> FieldCfg.setHidden(p, item.id, fd.id, !c) }
            r.addView(sw, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (!fd.label.endsWith("graph")) {
                val custom = FieldCfg.isCustom(p, item.id, fd.id)
                val n = FieldCfg.rules(p, item.id, fd.id).size
                val label = if (custom) "colors*" else if (n > 0) "colors" else "colors"
                r.addView(btn(label, if (custom || n > 0) Col.YELLOW else Col.GRAY) {
                    dlg.dismiss()
                    rulesDialog(item, fd)
                })
            }
            r.setPadding(0, dp(4), 0, dp(4))
            box.addView(r)
        }
        dlg.show()
    }

    private fun rulesDialog(item: Item, fd: FieldDef) {
        val rules = FieldCfg.rules(p, item.id, fd.id).map { Rule(it.cond, it.v, it.color) }.toMutableList()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sc = ScrollView(this)
        sc.addView(box)
        val dlg = AlertDialog.Builder(this)
            .setTitle("Colors: " + Blocks.label(item.id) + " / " + fd.label)
            .setView(sc)
            .setPositiveButton("Done", null)
            .create()
        dlg.setOnDismissListener { fieldsDialog(item) }

        fun persistRules() { FieldCfg.save(p, item.id, fd.id, rules) }

        fun build() {
            box.removeAllViews()
            box.addView(tv("the first rule that matches decides the color. No match = the automatic color. Use the arrows to reorder.", 11f, Col.GRAY))
            if (rules.isEmpty()) box.addView(tv("no rules - automatic colors", 12f, Col.GRAY))
            for ((i, rule) in rules.withIndex()) {
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                r.gravity = Gravity.CENTER_VERTICAL
                val t = tv(FieldCfg.condLabel(rule), 12f, Color.WHITE)
                t.setOnClickListener { ruleEditDialog(fd, rule) { persistRules(); build() } }
                r.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                r.addView(colorChip(rule.color) {
                    ColorDialog.show(this, "Rule color", null) { c -> rule.color = c or 0xFF000000.toInt(); persistRules(); build() }
                })
                r.addView(btn("▲") { if (i > 0) { rules.removeAt(i); rules.add(i - 1, rule); persistRules(); build() } })
                r.addView(btn("▼") { if (i < rules.size - 1) { rules.removeAt(i); rules.add(i + 1, rule); persistRules(); build() } })
                r.addView(btn("✕", Col.RED) { rules.remove(rule); persistRules(); build() })
                box.addView(r)
            }
            val add = Button(this)
            add.text = "+ Add rule"
            add.isAllCaps = false
            add.setOnClickListener {
                val nr = Rule(if (fd.numeric) "ge" else "chg", 0f, Col.GREEN)
                ruleEditDialog(fd, nr) { rules.add(nr); persistRules(); build() }
            }
            box.addView(add)
            val clear = Button(this)
            clear.text = "No rules (always automatic color)"
            clear.isAllCaps = false
            clear.setOnClickListener { rules.clear(); persistRules(); build() }
            box.addView(clear)
            if (FieldCfg.isCustom(p, item.id, fd.id) || fd.defRules.isNotEmpty()) {
                val rst = Button(this)
                rst.text = "Back to built-in rules"
                rst.isAllCaps = false
                rst.setOnClickListener {
                    FieldCfg.reset(p, item.id, fd.id)
                    rules.clear()
                    rules.addAll(FieldCfg.rules(p, item.id, fd.id).map { Rule(it.cond, it.v, it.color) })
                    build()
                }
                box.addView(rst)
            }
        }
        build()
        dlg.show()
    }

    /** يعدل شرط واحد: النوع (شحن / أكبر / أصغر ...) + الرقم + اللون. */
    private fun ruleEditDialog(fd: FieldDef, rule: Rule, onOk: () -> Unit) {
        val conds = ArrayList<Pair<String, String>>()
        conds.add("chg" to "when charging")
        conds.add("dis" to "when NOT charging")
        if (fd.numeric) {
            conds.add("ge" to "value >= (at or above)")
            conds.add("gt" to "value > (above)")
            conds.add("le" to "value <= (at or below)")
            conds.add("lt" to "value < (below)")
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        var cond = if (conds.any { it.first == rule.cond }) rule.cond else conds[0].first
        var color = rule.color
        val condBtn = Button(this)
        condBtn.isAllCaps = false
        val num = EditText(this)
        num.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        num.setTextColor(Color.WHITE)
        num.typeface = Typeface.MONOSPACE
        num.setText(if (rule.v == rule.v.toInt().toFloat()) rule.v.toInt().toString() else rule.v.toString())
        val numRow = LinearLayout(this)
        numRow.orientation = LinearLayout.HORIZONTAL
        numRow.gravity = Gravity.CENTER_VERTICAL
        val pm = TextView(this)
        pm.text = "±"
        pm.textSize = 18f
        pm.setTextColor(Col.CYAN)
        pm.setPadding(dp(12), dp(6), dp(12), dp(6))
        pm.setOnClickListener {
            val t = num.text.toString().trim()
            num.setText(if (t.startsWith("-")) t.substring(1) else if (t.isEmpty()) "-" else "-$t")
            num.setSelection(num.text.length)
        }
        numRow.addView(tv("value", 12f, Color.WHITE), LinearLayout.LayoutParams(dp(60), ViewGroup.LayoutParams.WRAP_CONTENT))
        numRow.addView(num, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        numRow.addView(pm)
        val chipHolder = LinearLayout(this)
        chipHolder.orientation = LinearLayout.HORIZONTAL

        fun refresh() {
            condBtn.text = conds.first { it.first == cond }.second
            numRow.visibility = if (cond == "chg" || cond == "dis") View.GONE else View.VISIBLE
            chipHolder.removeAllViews()
            chipHolder.addView(tv("color", 12f, Color.WHITE), LinearLayout.LayoutParams(dp(60), ViewGroup.LayoutParams.WRAP_CONTENT))
            chipHolder.addView(colorChip(color) {
                ColorDialog.show(this, "Rule color", null) { c -> color = c or 0xFF000000.toInt(); refresh() }
            })
        }
        condBtn.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Condition")
                .setItems(conds.map { it.second }.toTypedArray()) { _, which -> cond = conds[which].first; refresh() }
                .show()
        }
        box.addView(condBtn)
        box.addView(numRow)
        box.addView(chipHolder)
        refresh()
        AlertDialog.Builder(this)
            .setTitle("Rule")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("OK") { _, _ ->
                rule.cond = cond
                rule.v = num.text.toString().toFloatOrNull() ?: 0f
                rule.color = color
                onOk()
            }
            .show()
    }

    // ====================== ألوان السجل لكل حالة ======================

    private fun logColorSection() {
        col.addView(tv("LOG colors (one color per state)", 14f, Col.CYAN, true).apply { setPadding(0, dp(22), 0, dp(4)) })
        col.addView(tv("tap a color to change it. Auto = the built-in color. Applies to new log lines.", 11f, Col.GRAY))
        var lastTag = ""
        for (ls in LogStates.all) {
            if (ls.tag != lastTag) {
                lastTag = ls.tag
                col.addView(tv(ls.tag, 12f, Col.WHITE, true).apply { setPadding(0, dp(10), 0, dp(0)) })
            }
            val cur = p.getInt(LogStates.key(ls.id), 0)
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            val name = TextView(this)
            name.text = ls.label
            name.textSize = 12f
            name.typeface = Typeface.MONOSPACE
            name.setTextColor(if (cur != 0) cur else ls.def)
            r.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(colorChip(cur) {
                ColorDialog.show(this, ls.tag + ": " + ls.label, "Auto") { c ->
                    if (c == 0) p.edit().remove(LogStates.key(ls.id)).apply()
                    else p.edit().putInt(LogStates.key(ls.id), c or 0xFF000000.toInt()).apply()
                    render()
                }
            })
            r.setPadding(0, dp(2), 0, dp(2))
            col.addView(r)
        }
    }

    // ====================== تشخيص أوضاع الطاقة (Xiaomi) ======================

    private var diagSnap: Map<String, String>? = null

    private fun readAllSettings(): Map<String, String> {
        val out = java.util.TreeMap<String, String>()
        fun grab(tag: String, uri: android.net.Uri) {
            try {
                contentResolver.query(uri, arrayOf("name", "value"), null, null, null)?.use { c ->
                    while (c.moveToNext()) out[tag + ":" + (c.getString(0) ?: "")] = c.getString(1) ?: ""
                }
            } catch (e: Exception) { }
        }
        grab("system", Settings.System.CONTENT_URI)
        grab("global", Settings.Global.CONTENT_URI)
        grab("secure", Settings.Secure.CONTENT_URI)
        return out
    }

    private fun diagSection() {
        col.addView(tv("Power mode diagnostics (Xiaomi)", 14f, Col.CYAN, true).apply { setPadding(0, dp(22), 0, dp(4)) })
        col.addView(tv("Ultra battery saver is detected automatically. For Performance mode: tap Snapshot, switch the phone to Performance mode, come back and tap Changes - it lists the setting that changed. Type that setting name below to use it.", 11f, Col.GRAY))
        val out = tv("", 11f, Col.WHITE)
        out.typeface = Typeface.MONOSPACE
        out.setTextIsSelectable(true)

        val b1 = Button(this)
        b1.text = "1) Snapshot now"
        b1.isAllCaps = false
        b1.setOnClickListener {
            diagSnap = readAllSettings()
            out.text = "snapshot saved: " + diagSnap!!.size + " settings.\nnow change the power mode, then tap Changes."
        }
        val b2 = Button(this)
        b2.text = "2) Changes since snapshot"
        b2.isAllCaps = false
        b2.setOnClickListener {
            val a = diagSnap
            if (a == null) { out.text = "take a snapshot first"; return@setOnClickListener }
            val b = readAllSettings()
            val sb = StringBuilder()
            for ((k, v) in b) if (a[k] != v) sb.append(k).append("  ").append(a[k] ?: "(none)").append(" -> ").append(v).append('\n')
            for ((k, v) in a) if (!b.containsKey(k)) sb.append(k).append("  ").append(v).append(" -> (removed)\n")
            out.text = if (sb.isEmpty()) "no change detected" else sb.toString()
        }
        val b3 = Button(this)
        b3.text = "Show power-related settings"
        b3.isAllCaps = false
        b3.setOnClickListener {
            val rx = Regex("power|perform|save|saver|mode|battery|boost|extreme|thermal|game", RegexOption.IGNORE_CASE)
            val sb = StringBuilder()
            for ((k, v) in readAllSettings()) if (rx.containsMatchIn(k)) sb.append(k).append(" = ").append(v.take(40)).append('\n')
            out.text = sb.toString()
        }
        val b4 = Button(this)
        b4.text = "Copy output"
        b4.isAllCaps = false
        b4.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("sysmon", out.text.toString()))
        }
        col.addView(b1); col.addView(b2); col.addView(b3); col.addView(b4)
        col.addView(out)

        fun keyField(title: String, key: String) {
            col.addView(tv(title, 12f, Col.WHITE))
            val et = EditText(this)
            et.setText(p.getString(key, "") ?: "")
            et.hint = "setting name, e.g. SOME_KEY (empty = none)"
            et.setTextColor(Color.WHITE)
            et.setHintTextColor(Col.GRAY)
            et.typeface = Typeface.MONOSPACE
            et.textSize = 12f
            et.setSingleLine(true)
            et.addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(e: android.text.Editable?) {
                    val v = e?.toString()?.trim()?.substringAfter(":") ?: ""
                    p.edit().putString(key, v).apply()
                }
                override fun beforeTextChanged(e: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(e: CharSequence?, st: Int, b: Int, c: Int) {}
            })
            col.addView(et)
        }
        keyField("Setting that is 1 / on when Performance mode is active", "pm_key_perf")
        keyField("Setting that is 1 / on when Ultra saver is active (optional)", "pm_key_ultra")
    }
}
