package com.sysmon.wallpaper

import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** محطة لون: من هذه القيمة وما فوق يصير اللون كذا. */
class Stop(var v: Float, var color: Int)

class GraphStyle(
    var width: Float = 4.2f,      // عرض العمود (dp)
    var gap: Float = 1.2f,        // الفراغ بين الأعمدة (dp)
    var count: Int = 8,           // عدد الأعمدة
    var minH: Float = 0.7f,       // أقل ارتفاع (dp)
    var rmin: Float = 0f,         // بداية المجال (بوحدة الرسم)
    var rmax: Float = 100f,       // نهاية المجال
    var log: Boolean = false,     // مقياس لوغاريتمي
    var smooth: Boolean = false,  // ألوان متدرجة ناعمة أو درجات حادة
    var updMs: Int = 0,           // سرعة إضافة عمود جديد (0 = كل نبضة)
    var stops: MutableList<Stop> = ArrayList()
) {
    fun copy(): GraphStyle = GraphStyle(
        width, gap, count, minH, rmin, rmax, log, smooth, updMs,
        stops.map { Stop(it.v, it.color) }.toMutableList()
    )

    fun totalDp(): Float = count * (width + gap)

    fun norm(v: Float): Float {
        if (v.isNaN()) return 0f
        if (rmax <= rmin) return 0f
        return if (log) {
            val lo = if (rmin <= 0f) 1f else rmin
            val hi = if (rmax <= lo) lo + 1f else rmax
            ((ln(max(v, lo)) - ln(lo)) / (ln(hi) - ln(lo))).coerceIn(0f, 1f)
        } else {
            ((v - rmin) / (rmax - rmin)).coerceIn(0f, 1f)
        }
    }

    fun colorFor(v: Float): Int {
        val s = stops
        if (s.isEmpty()) return Col.GREEN
        if (v <= s[0].v) return s[0].color
        for (i in 1 until s.size) {
            if (v < s[i].v) {
                if (!smooth) return s[i - 1].color
                val a = s[i - 1]
                val b = s[i]
                val t = if (b.v > a.v) (v - a.v) / (b.v - a.v) else 0f
                return lerp(a.color, b.color, t)
            }
        }
        return s.last().color
    }

    private fun lerp(a: Int, b: Int, t: Float): Int = Color.argb(
        255,
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    /** قيمة تمثيلية لمعاينة المجال كاملاً (للمحرر). */
    fun sample(t: Float): Float {
        return if (log) {
            val lo = if (rmin <= 0f) 1f else rmin
            val hi = if (rmax <= lo) lo + 1f else rmax
            exp(ln(lo) + t * (ln(hi) - ln(lo)))
        } else rmin + t * (rmax - rmin)
    }
}

class GraphDef(val id: String, val label: String, val unit: String)

object Graphs {
    val all = listOf(
        GraphDef("core_f", "Core speed (% of max freq)", "%"),
        GraphDef("core_l", "Core usage", "%"),
        GraphDef("cpu_ld", "CPU usage (total)", "%"),
        GraphDef("cpu_t", "CPU temperature", "C"),
        GraphDef("bat_ma", "Battery current", "mA"),
        GraphDef("bat_w", "Battery power", "W"),
        GraphDef("bat_t", "Battery temperature", "C"),
        GraphDef("ram", "RAM usage", "%"),
        GraphDef("dl", "Download speed", "B/s"),
        GraphDef("ul", "Upload speed", "B/s"),
        GraphDef("spec", "Spectrum (audio bars)", "%")
    )

    private fun st(vararg p: Pair<Float, Int>): MutableList<Stop> = p.map { Stop(it.first, it.second) }.toMutableList()
    private fun heat3(): MutableList<Stop> = st(0f to Col.GREEN, 50f to Col.YELLOW, 80f to Col.RED)

    fun default(id: String): GraphStyle = when (id) {
        "core_f" -> GraphStyle(width = 1f, gap = 1f, count = 18, smooth = true, stops = heat3())
        "core_l" -> GraphStyle(width = 1f, gap = 1f, count = 18, stops = heat3())
        "cpu_ld" -> GraphStyle(width = 1f, gap = 1f, count = 14, smooth = true, stops = heat3())
        "cpu_t" -> GraphStyle(width = 1f, gap = 1f, count = 14, rmin = 30f, rmax = 80f,
            stops = st(30f to Col.GREEN, 55f to Col.YELLOW, 70f to Col.RED))
        "bat_ma" -> GraphStyle(width = 1f, gap = 1f, count = 18, rmin = 0f, rmax = 4000f,
            stops = st(0f to Col.CYAN, 2500f to Col.YELLOW, 3500f to Col.RED))
        "bat_w" -> GraphStyle(width = 1f, gap = 1f, count = 18, rmin = 0f, rmax = 20f,
            stops = st(0f to Col.CYAN, 12f to Col.YELLOW, 18f to Col.RED))
        "bat_t" -> GraphStyle(width = 1f, gap = 1f, count = 18, rmin = 25f, rmax = 50f,
            stops = st(25f to Col.GREEN, 37.5f to Col.YELLOW, 45f to Col.RED))
        "ram" -> GraphStyle(width = 1f, gap = 1f, count = 12, updMs = 1000, smooth = true,
            stops = st(0f to Col.GREEN, 70f to Col.YELLOW, 88f to Col.RED))
        "dl" -> GraphStyle(width = 1f, gap = 1f, count = 50, rmin = 1f, rmax = 10_000_000f, log = true, stops = st(1f to Col.CYAN))
        "ul" -> GraphStyle(width = 1f, gap = 1f, count = 50, rmin = 1f, rmax = 10_000_000f, log = true, stops = st(1f to Col.BLUE))
        "spec" -> GraphStyle(width = 3.2f, gap = 1f, count = 36, rmin = 0f, rmax = 100f, smooth = true,
            stops = st(0f to Col.GREEN, 55f to Col.YELLOW, 85f to Col.RED))
        else -> GraphStyle(stops = heat3())
    }

    private val cache = HashMap<String, Pair<String?, GraphStyle>>()

    @Synchronized
    fun get(p: SharedPreferences, id: String): GraphStyle {
        val raw = p.getString("g_$id", null)
        val c = cache[id]
        if (c != null && c.first == raw) return c.second
        val s = if (raw == null) default(id) else parse(raw, id)
        cache[id] = Pair(raw, s)
        return s
    }

    fun save(p: SharedPreferences, id: String, s: GraphStyle) {
        s.stops.sortBy { it.v }
        p.edit().putString("g_$id", ser(s)).apply()
    }

    fun reset(p: SharedPreferences, id: String) {
        p.edit().remove("g_$id").apply()
    }

    private fun ser(s: GraphStyle): String {
        val head = listOf(
            s.width, s.gap, s.count, s.minH, s.rmin, s.rmax,
            if (s.log) 1 else 0, if (s.smooth) 1 else 0, s.updMs
        ).joinToString(",")
        return head + s.stops.joinToString("") { ";" + it.v + ":" + it.color }
    }

    private fun parse(raw: String, id: String): GraphStyle {
        val d = default(id)
        try {
            val parts = raw.split(";")
            val h = parts[0].split(",")
            if (h.size < 9) return d
            val stops = parts.drop(1).filter { it.isNotEmpty() }.mapNotNull {
                val kv = it.split(":")
                val v = kv.getOrNull(0)?.toFloatOrNull()
                val c = kv.getOrNull(1)?.toIntOrNull()
                if (v != null && c != null) Stop(v, c) else null
            }.toMutableList()
            if (stops.isEmpty()) stops.addAll(d.stops)
            stops.sortBy { it.v }
            return GraphStyle(
                width = (h[0].toFloatOrNull() ?: d.width).coerceIn(0.5f, 40f),
                gap = (h[1].toFloatOrNull() ?: d.gap).coerceIn(0f, 20f),
                count = (h[2].toIntOrNull() ?: d.count).coerceIn(1, 64),
                minH = (h[3].toFloatOrNull() ?: d.minH).coerceIn(0f, 20f),
                rmin = h[4].toFloatOrNull() ?: d.rmin,
                rmax = h[5].toFloatOrNull() ?: d.rmax,
                log = h[6] == "1",
                smooth = h[7] == "1",
                updMs = (h[8].toIntOrNull() ?: d.updMs).coerceAtLeast(0),
                stops = stops
            )
        } catch (e: Exception) {
            return d
        }
    }
}

/** سجل قيم خام (بوحدتها) لرسم واحد. NaN = لا توجد قراءة بعد. */
class Hist(private val cap: Int = 64) {
    private val a = FloatArray(cap)
    private var i = 0
    private var lastPush = -1L
    var count = 0
        private set

    fun due(now: Long, upd: Int): Boolean = upd <= 0 || lastPush < 0L || now - lastPush >= upd

    fun push(v: Float, now: Long) {
        a[i] = v
        i = (i + 1) % cap
        if (count < cap) count++
        lastPush = now
    }

    fun last(n: Int): FloatArray {
        val m = n.coerceIn(1, cap)
        val out = FloatArray(m) { Float.NaN }
        val take = min(m, count)
        for (k in 0 until take) out[m - 1 - k] = a[(i - 1 - k + cap * 2) % cap]
        return out
    }
}

/** رسم الأعمدة (مشترك بين الخلفية ومعاينة المحرر). يرجع x بعد الرسم. */
object GraphDraw {
    fun draw(
        c: Canvas, p: Paint, x: Float, baseY: Float, g: GraphStyle, vals: FloatArray,
        density: Float, maxH: Float, alpha: Int, fixed: Int, peaks: FloatArray?, colorFix: (Int) -> Int
    ): Float {
        val w = g.width * density
        val gp = g.gap * density
        val minH = g.minH * density
        for (k in vals.indices) {
            val v = vals[k]
            if (v.isNaN()) continue
            p.color = colorFix(if (fixed != 0) fixed else g.colorFor(v))
            p.alpha = alpha
            val bh = max(minH, g.norm(v) * maxH)
            val bx = x + k * (w + gp)
            c.drawRect(bx, baseY - bh + 2f, bx + w, baseY + 2f, p)
        }
        if (peaks != null) {
            val cap = max(1.5f, 1.3f * density)
            for (k in vals.indices) {
                val pv = peaks.getOrNull(k) ?: continue
                if (pv.isNaN() || pv <= 1f) continue
                val py = baseY - max(minH, g.norm(pv) * maxH) + 2f
                p.color = colorFix(Col.WHITE)
                p.alpha = alpha
                val bx = x + k * (w + gp)
                c.drawRect(bx, py - cap, bx + w, py, p)
            }
        }
        return x + vals.size * (w + gp)
    }
}

/** تعديل الألوان التي تشبه الخلفية حتى تبقى واضحة. */
object Contrast {
    private val cache = HashMap<Long, Int>()

    private fun ch(v: Int): Float {
        val s = v / 255f
        return if (s <= 0.03928f) s / 12.92f else Math.pow(((s + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
    }

    fun lum(c: Int): Float =
        0.2126f * ch(Color.red(c)) + 0.7152f * ch(Color.green(c)) + 0.0722f * ch(Color.blue(c))

    fun ratio(a: Int, b: Int): Float {
        val l1 = lum(a)
        val l2 = lum(b)
        return (max(l1, l2) + 0.05f) / (min(l1, l2) + 0.05f)
    }

    @Synchronized
    fun fix(fg: Int, bg: Int, minRatio: Float = 3f): Int {
        val key = (fg.toLong() shl 32) xor (bg.toLong() and 0xFFFFFFFFL)
        val hit = cache[key]
        if (hit != null) return hit
        val r = compute(fg, bg, minRatio)
        if (cache.size > 3000) cache.clear()
        cache[key] = r
        return r
    }

    private fun compute(fg: Int, bg: Int, minRatio: Float): Int {
        if (ratio(fg, bg) >= minRatio) return fg
        val hsv = FloatArray(3)
        Color.colorToHSV(fg, hsv)
        val up = ratio(Color.WHITE, bg) >= ratio(Color.BLACK, bg)
        var best = fg
        for (step in 1..20) {
            val t = step / 20f
            val v = if (up) hsv[2] + (1f - hsv[2]) * t else hsv[2] * (1f - t)
            val s = if (up) hsv[1] * (1f - t * 0.6f) else hsv[1]
            val cand = Color.HSVToColor(floatArrayOf(hsv[0], s, v))
            if (ratio(cand, bg) >= minRatio) return cand
            best = cand
        }
        return best
    }
}
