package com.sysmon.wallpaper

import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** محطة لون: من هذه القيمة وما فوق يصير اللون كذا. */
class Stop(var v: Float, var color: Int)

class GraphStyle(
    var width: Float = 4.2f,      // عرض العمود (dp)
    var gap: Float = 1.2f,        // الفراغ بين الأعمدة (dp)
    var count: Int = 8,           // عدد الأعمدة
    var minH: Float = 0.7f,       // أقل ارتفاع (dp)
    var rmin: Float = 0f,         // بداية المجال (بوحدة الرسم)
    var rmax: Float = 100f,       // نهاية المجال
    var log: Boolean = false,     // مقياس لوغاريتمي
    var smooth: Boolean = false,  // ألوان متدرجة ناعمة أو درجات حادة
    var updMs: Int = 0,           // سرعة إضافة عمود جديد (0 = كل نبضة)
    var stops: MutableList<Stop> = ArrayList(),
    // ---- نص المجال والوقت بجانب المخطط ----
    var nRange: Boolean = false,  // يعرض المجال (قيمة أسفل المخطط وقيمة أعلاه)
    var nTime: Boolean = false,   // يعرض المدة الزمنية التي يغطيها المخطط
    var nStyle: Int = 0,          // 0 = (lo-hi unit)  1 = (0=lo 100=hi unit)
    var nDec: Int = -1,           // عدد الأرقام العشرية (-1 = تلقائي حسب المدى)
    // ---- التكبير / التصغير التلقائي ----
    var azOn: Boolean = false,    // المجال يتبع القيم الظاهرة
    var azPad: Float = 8f,        // هامش إضافي فوق وتحت (% من المدى)
    var azMinSpan: Float = 0f,    // أصغر مدى مسموح (بوحدة الرسم). 0 = 5% من المجال الأساسي (للوغاريتمي: النسبة بين الأعلى والأدنى)
    var azUpMs: Int = 0,          // سرعة اتساع المجال لما القيم تخرج منه (0 = فوري)
    var azDownMs: Int = 2500,     // سرعة انكماش المجال لما القيم تهدأ (أكبر = أبطأ وأهدى)
    var azPin: Int = 0,           // 0 حر  1 الأدنى ثابت على بداية المجال  2 الأعلى ثابت على نهاية المجال
    var azWin: Int = 0            // عدد الأعمدة الأخيرة المستخدمة في الحساب (0 = كل الظاهرة)
) {
    fun copy(): GraphStyle = GraphStyle(
        width, gap, count, minH, rmin, rmax, log, smooth, updMs,
        stops.map { Stop(it.v, it.color) }.toMutableList(),
        nRange, nTime, nStyle, nDec, azOn, azPad, azMinSpan, azUpMs, azDownMs, azPin, azWin
    )

    fun totalDp(): Float = count * (width + gap)

    /** lo / hi = المجال المستخدم للرسم (الثابت أو المتغير مع الزوم التلقائي). */
    fun norm(vIn: Float, lo0: Float = rmin, hi0: Float = rmax): Float {
        if (vIn.isNaN()) return 0f
        if (hi0 <= lo0) return 0f
        // قيمة سالبة = شحن: لو المجال يبدأ من صفر أو أكثر نستعمل حجمها لارتفاع العمود
        val v = if (rmin >= 0f && vIn < 0f) -vIn else vIn
        return if (log) {
            val lo = if (lo0 <= 0f) 1f else lo0
            val hi = if (hi0 <= lo) lo + 1f else hi0
            ((ln(max(v, lo)) - ln(lo)) / (ln(hi) - ln(lo))).coerceIn(0f, 1f)
        } else {
            ((v - lo0) / (hi0 - lo0)).coerceIn(0f, 1f)
        }
    }

    fun colorFor(v: Float): Int {
        val s = stops
        if (s.isEmpty()) return Col.GREEN
        if (v <= s[0].v) return s[0].color
        for (i in 1 until s.size) {
            if (v < s[i].v) {
                if (!smooth) return s[i - 1].color
                val a = s[i - 1]
                val b = s[i]
                val t = if (b.v > a.v) (v - a.v) / (b.v - a.v) else 0f
                return lerp(a.color, b.color, t)
            }
        }
        return s.last().color
    }

    private fun lerp(a: Int, b: Int, t: Float): Int = Color.argb(
        255,
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    /** قيمة تمثيلية لمعاينة المجال كاملاً (للمحرر). */
    fun sample(t: Float): Float {
        return if (log) {
            val lo = if (rmin <= 0f) 1f else rmin
            val hi = if (rmax <= lo) lo + 1f else rmax
            exp(ln(lo) + t * (ln(hi) - ln(lo)))
        } else rmin + t * (rmax - rmin)
    }
}

class GraphDef(val id: String, val label: String, val unit: String)

object Graphs {
    val all = listOf(
        GraphDef("core_f", "Core speed (% of max freq)", "%"),
        GraphDef("core_l", "Core usage", "%"),
        GraphDef("cpu_ld", "CPU usage (total)", "%"),
        GraphDef("cpu_t", "CPU temperature", "C"),
        GraphDef("bat_ma", "Battery current", "mA"),
        GraphDef("bat_w", "Battery power", "W"),
        GraphDef("bat_t", "Battery temperature", "C"),
        GraphDef("ram", "RAM usage", "%"),
        GraphDef("dl", "Download speed", "B/s"),
        GraphDef("ul", "Upload speed", "B/s"),
        GraphDef("spec", "Spectrum (audio bars)", "%")
    )

    private fun st(vararg p: Pair<Float, Int>): MutableList<Stop> = p.map { Stop(it.first, it.second) }.toMutableList()
    private fun heat3(): MutableList<Stop> = st(0f to Col.GREEN, 50f to Col.YELLOW, 80f to Col.RED)

    /**
     * محطات الشحن: القيمة السالبة تعني شحن (الواط الموجب على الشاشة).
     * من 1 واط أزرق فاتح، من 30 بنفسجي، من 90 وردي.
     * التيار محسوب على فولت تقريبي 4.0V (واط ÷ 4 × 1000): 250 و 7500 و 22500 mA.
     */
    fun chargeStops(id: String): List<Stop> = if (id == "bat_ma") listOf(
        Stop(-100000f, Col.PINK), Stop(-22500f, Col.PURPLE), Stop(-7500f, Col.LIGHT_BLUE), Stop(-250f, Col.CYAN)
    ) else listOf(
        Stop(-1000f, Col.PINK), Stop(-90f, Col.PURPLE), Stop(-30f, Col.LIGHT_BLUE), Stop(-1f, Col.CYAN)
    )

    /** مرة واحدة: يضيف محطات الشحن لإعدادات الرسمين المحفوظة سابقاً بدون ما يمس بقية تعديلات المستخدم. */
    @Synchronized
    fun migrateCharge(p: SharedPreferences) {
        if (p.getInt("chg_v", 0) >= 1) return
        for (id in listOf("bat_ma", "bat_w")) {
            if (p.getString("g_$id", null) == null) continue
            val s = get(p, id).copy()
            if (s.stops.none { it.v < 0f }) {
                s.stops.addAll(chargeStops(id))
                save(p, id, s)
            }
        }
        p.edit().putInt("chg_v", 1).apply()
    }

    fun default(id: String): GraphStyle = when (id) {
        "core_f" -> GraphStyle(width = 1f, gap = 1f, count = 18, smooth = true, stops = heat3())
        "core_l" -> GraphStyle(width = 1f, gap = 1f, count = 18, stops = heat3())
        "cpu_ld" -> GraphStyle(width = 1f, gap = 1f, count = 14, smooth = true, stops = heat3())
        "cpu_t" -> GraphStyle(width = 1f, gap = 1f, count = 14, rmin = 30f, rmax = 80f,
            stops = st(30f to Col.GREEN, 55f to Col.YELLOW, 70f to Col.RED))
        "bat_ma" -> GraphStyle(width = 1f, gap = 1f, count = 18, rmin = 0f, rmax = 4000f,
            stops = (chargeStops("bat_ma") + st(0f to Col.CYAN, 2500f to Col.YELLOW, 3500f to Col.RED)).toMutableList())
        "bat_w" -> GraphStyle(width = 1f, gap = 1f, count = 18, rmin = 0f, rmax = 20f,
            stops = (chargeStops("bat_w") + st(0f to Col.CYAN, 12f to Col.YELLOW, 18f to Col.RED)).toMutableList())
        "bat_t" -> GraphStyle(width = 1f, gap = 1f, count = 18, rmin = 25f, rmax = 50f,
            stops = st(25f to Col.GREEN, 37.5f to Col.YELLOW, 45f to Col.RED))
        "ram" -> GraphStyle(width = 1f, gap = 1f, count = 12, updMs = 1000, smooth = true,
            stops = st(0f to Col.GREEN, 70f to Col.YELLOW, 88f to Col.RED))
        "dl" -> GraphStyle(width = 1f, gap = 1f, count = 50, rmin = 1f, rmax = 10_000_000f, log = true, stops = st(1f to Col.CYAN))
        "ul" -> GraphStyle(width = 1f, gap = 1f, count = 50, rmin = 1f, rmax = 10_000_000f, log = true, stops = st(1f to Col.BLUE))
        "spec" -> GraphStyle(width = 3.2f, gap = 1f, count = 36, rmin = 0f, rmax = 100f, smooth = true,
            stops = st(0f to Col.GREEN, 55f to Col.YELLOW, 85f to Col.RED))
        else -> GraphStyle(stops = heat3())
    }

    private val cache = HashMap<String, Pair<String?, GraphStyle>>()

    @Synchronized
    fun get(p: SharedPreferences, id: String): GraphStyle {
        val raw = p.getString("g_$id", null)
        val c = cache[id]
        if (c != null && c.first == raw) return c.second
        val s = if (raw == null) default(id) else parse(raw, id)
        cache[id] = Pair(raw, s)
        return s
    }

    fun save(p: SharedPreferences, id: String, s: GraphStyle) {
        s.stops.sortBy { it.v }
        p.edit().putString("g_$id", ser(s)).apply()
    }

    fun reset(p: SharedPreferences, id: String) {
        p.edit().remove("g_$id").apply()
    }

    private fun ser(s: GraphStyle): String {
        val head = listOf(
            s.width, s.gap, s.count, s.minH, s.rmin, s.rmax,
            if (s.log) 1 else 0, if (s.smooth) 1 else 0, s.updMs,
            if (s.nRange) 1 else 0, if (s.nTime) 1 else 0, s.nStyle, s.nDec,
            if (s.azOn) 1 else 0, s.azPad, s.azMinSpan, s.azUpMs, s.azDownMs, s.azPin, s.azWin
        ).joinToString(",")
        return head + s.stops.joinToString("") { ";" + it.v + ":" + it.color }
    }

    private fun parse(raw: String, id: String): GraphStyle {
        val d = default(id)
        try {
            val parts = raw.split(";")
            val h = parts[0].split(",")
            if (h.size < 9) return d
            val stops = parts.drop(1).filter { it.isNotEmpty() }.mapNotNull {
                val kv = it.split(":")
                val v = kv.getOrNull(0)?.toFloatOrNull()
                val c = kv.getOrNull(1)?.toIntOrNull()
                if (v != null && c != null) Stop(v, c) else null
            }.toMutableList()
            if (stops.isEmpty()) stops.addAll(d.stops)
            stops.sortBy { it.v }
            return GraphStyle(
                width = (h[0].toFloatOrNull() ?: d.width).coerceIn(0.5f, 40f),
                gap = (h[1].toFloatOrNull() ?: d.gap).coerceIn(0f, 20f),
                count = (h[2].toIntOrNull() ?: d.count).coerceIn(1, 64),
                minH = (h[3].toFloatOrNull() ?: d.minH).coerceIn(0f, 20f),
                rmin = h[4].toFloatOrNull() ?: d.rmin,
                rmax = h[5].toFloatOrNull() ?: d.rmax,
                log = h[6] == "1",
                smooth = h[7] == "1",
                updMs = (h[8].toIntOrNull() ?: d.updMs).coerceAtLeast(0),
                stops = stops,
                nRange = h.getOrNull(9)?.let { it == "1" } ?: d.nRange,
                nTime = h.getOrNull(10)?.let { it == "1" } ?: d.nTime,
                nStyle = (h.getOrNull(11)?.toIntOrNull() ?: d.nStyle).coerceIn(0, 1),
                nDec = (h.getOrNull(12)?.toIntOrNull() ?: d.nDec).coerceIn(-1, 4),
                azOn = h.getOrNull(13)?.let { it == "1" } ?: d.azOn,
                azPad = (h.getOrNull(14)?.toFloatOrNull() ?: d.azPad).coerceIn(0f, 100f),
                azMinSpan = (h.getOrNull(15)?.toFloatOrNull() ?: d.azMinSpan).coerceAtLeast(0f),
                azUpMs = (h.getOrNull(16)?.toIntOrNull() ?: d.azUpMs).coerceAtLeast(0),
                azDownMs = (h.getOrNull(17)?.toIntOrNull() ?: d.azDownMs).coerceAtLeast(0),
                azPin = (h.getOrNull(18)?.toIntOrNull() ?: d.azPin).coerceIn(0, 2),
                azWin = (h.getOrNull(19)?.toIntOrNull() ?: d.azWin).coerceIn(0, 64)
            )
        } catch (e: Exception) {
            return d
        }
    }
}

/** سجل قيم خام (بوحدتها) لرسم واحد مع وقت كل قيمة. NaN = لا توجد قراءة بعد. */
class Hist(private val cap: Int = 64) {
    private val a = FloatArray(cap)
    private val ts = LongArray(cap)
    private var i = 0
    private var lastPush = -1L
    var count = 0
        private set

    // حالة الزوم التلقائي (المجال الحالي المنسّق) + عرض نص المجال
    var zlo = Float.NaN
    var zhi = Float.NaN
    var zT = 0L
    var noteW = 0

    fun due(now: Long, upd: Int): Boolean = upd <= 0 || lastPush < 0L || now - lastPush >= upd

    fun clear() {
        i = 0; count = 0; lastPush = -1L
        zlo = Float.NaN; zhi = Float.NaN; zT = 0L; noteW = 0
    }

    fun push(v: Float, now: Long) {
        a[i] = v
        ts[i] = now
        i = (i + 1) % cap
        if (count < cap) count++
        lastPush = now
    }

    fun last(n: Int): FloatArray {
        val m = n.coerceIn(1, cap)
        val out = FloatArray(m) { Float.NaN }
        val take = min(m, count)
        for (k in 0 until take) out[m - 1 - k] = a[(i - 1 - k + cap * 2) % cap]
        return out
    }

    /** المدة الزمنية التي تغطيها آخر n عمود (من أقدم عمود إلى أحدث + فترة عمود واحد). */
    fun spanMs(n: Int): Long {
        val m = min(n.coerceIn(1, cap), count)
        if (m < 2) return 0L
        val newest = ts[(i - 1 + cap) % cap]
        val oldest = ts[(i - m + cap * 2) % cap]
        val per = (newest - oldest) / (m - 1)
        return newest - oldest + per
    }
}

/** الزوم التلقائي: يحسب مدى الرسم من القيم الظاهرة، مع تنعيم بالزمن (يتسع بسرعة ويضيق ببطء حسب الإعداد). */
object AutoZoom {
    private fun mag(g: GraphStyle, v: Float): Float = if (g.rmin >= 0f && v < 0f) -v else v

    fun update(g: GraphStyle, h: Hist, vals: FloatArray, now: Long): FloatArray {
        val from = if (g.azWin > 0) max(0, vals.size - g.azWin) else 0
        var dmin = Float.MAX_VALUE
        var dmax = -Float.MAX_VALUE
        for (k in from until vals.size) {
            val v = vals[k]
            if (v.isNaN()) continue
            val m = mag(g, v)
            if (m < dmin) dmin = m
            if (m > dmax) dmax = m
        }
        var tLo: Float
        var tHi: Float
        if (dmax < dmin) {
            tLo = g.rmin
            tHi = g.rmax
        } else if (g.log) {
            val pad = 1f + g.azPad / 100f
            tLo = max(dmin / pad, 1f)
            tHi = dmax * pad
            val minRatio = if (g.azMinSpan > 1f) g.azMinSpan else 4f
            if (tHi < tLo * minRatio) {
                val mid = Math.sqrt((tLo * tHi).toDouble()).toFloat()
                val half = Math.sqrt(minRatio.toDouble()).toFloat()
                tLo = max(mid / half, 1f)
                tHi = mid * half
            }
        } else {
            val minSpan = if (g.azMinSpan > 0f) g.azMinSpan else 0.05f * (g.rmax - g.rmin)
            var lo = dmin
            var hi = dmax
            if (hi - lo < minSpan) {
                val mid = (lo + hi) / 2f
                lo = mid - minSpan / 2f
                hi = mid + minSpan / 2f
            }
            val padV = (hi - lo) * g.azPad / 100f
            tLo = lo - padV
            tHi = hi + padV
        }
        if (g.azPin == 1) tLo = g.rmin
        if (g.azPin == 2) tHi = g.rmax
        if (tHi <= tLo) tHi = tLo + 1f

        if (h.zlo.isNaN() || h.zhi.isNaN() || h.zT == 0L) {
            h.zlo = tLo
            h.zhi = tHi
        } else {
            val dt = (now - h.zT).coerceIn(0L, 2000L).toFloat()
            h.zlo = step(h.zlo, tLo, dt, if (tLo < h.zlo) g.azUpMs else g.azDownMs)
            h.zhi = step(h.zhi, tHi, dt, if (tHi > h.zhi) g.azUpMs else g.azDownMs)
        }
        h.zT = now
        return floatArrayOf(h.zlo, h.zhi)
    }

    private fun step(cur: Float, target: Float, dtMs: Float, tauMs: Int): Float {
        if (tauMs <= 0) return target
        val a = 1f - Math.exp((-dtMs / tauMs).toDouble()).toFloat()
        return cur + (target - cur) * a
    }
}

/** رسم الأعمدة (مشترك بين الخلفية ومعاينة المحرر). يرجع x بعد الرسم. */
object GraphDraw {
    fun draw(
        c: Canvas, p: Paint, x: Float, baseY: Float, g: GraphStyle, vals: FloatArray,
        density: Float, maxH: Float, alpha: Int, fixed: Int, peaks: FloatArray?,
        zlo: Float = Float.NaN, zhi: Float = Float.NaN, colorFix: (Int) -> Int
    ): Float {
        val lo = if (zlo.isNaN() || zhi.isNaN()) g.rmin else zlo
        val hi = if (zlo.isNaN() || zhi.isNaN()) g.rmax else zhi
        val w = g.width * density
        val gp = g.gap * density
        val minH = g.minH * density
        for (k in vals.indices) {
            val v = vals[k]
            if (v.isNaN()) continue
            p.color = colorFix(if (fixed != 0) fixed else g.colorFor(v))
            p.alpha = alpha
            val bh = max(minH, g.norm(v, lo, hi) * maxH)
            val bx = x + k * (w + gp)
            c.drawRect(bx, baseY - bh + 2f, bx + w, baseY + 2f, p)
        }
        if (peaks != null) {
            val cap = max(1.5f, 1.3f * density)
            for (k in vals.indices) {
                val pv = peaks.getOrNull(k) ?: continue
                if (pv.isNaN() || pv <= 1f) continue
                val py = baseY - max(minH, g.norm(pv, lo, hi) * maxH) + 2f
                p.color = colorFix(Col.WHITE)
                p.alpha = alpha
                val bx = x + k * (w + gp)
                c.drawRect(bx, py - cap, bx + w, py, p)
            }
        }
        return x + vals.size * (w + gp)
    }
}

/** تعديل الألوان التي تشبه الخلفية حتى تبقى واضحة. */
object Contrast {
    private val cache = HashMap<Long, Int>()

    private fun ch(v: Int): Float {
        val s = v / 255f
        return if (s <= 0.03928f) s / 12.92f else Math.pow(((s + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
    }

    fun lum(c: Int): Float =
        0.2126f * ch(Color.red(c)) + 0.7152f * ch(Color.green(c)) + 0.0722f * ch(Color.blue(c))

    fun ratio(a: Int, b: Int): Float {
        val l1 = lum(a)
        val l2 = lum(b)
        return (max(l1, l2) + 0.05f) / (min(l1, l2) + 0.05f)
    }

    @Synchronized
    fun fix(fg: Int, bg: Int, minRatio: Float = 3f): Int {
        val key = (fg.toLong() shl 32) xor (bg.toLong() and 0xFFFFFFFFL)
        val hit = cache[key]
        if (hit != null) return hit
        val r = compute(fg, bg, minRatio)
        if (cache.size > 3000) cache.clear()
        cache[key] = r
        return r
    }

    private fun compute(fg: Int, bg: Int, minRatio: Float): Int {
        if (ratio(fg, bg) >= minRatio) return fg
        val hsv = FloatArray(3)
        Color.colorToHSV(fg, hsv)
        val up = ratio(Color.WHITE, bg) >= ratio(Color.BLACK, bg)
        var best = fg
        for (step in 1..20) {
            val t = step / 20f
            val v = if (up) hsv[2] + (1f - hsv[2]) * t else hsv[2] * (1f - t)
            val s = if (up) hsv[1] * (1f - t * 0.6f) else hsv[1]
            val cand = Color.HSVToColor(floatArrayOf(hsv[0], s, v))
            if (ratio(cand, bg) >= minRatio) return cand
            best = cand
        }
        return best
    }
}
