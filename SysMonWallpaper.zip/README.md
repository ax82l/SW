# SysMon Wallpaper v5

## التحديث
1. ارفع SysMonWallpaper.zip بنفس الاسم (يستبدل القديم) ثم Commit.
2. Actions ← انتظر البناء ← نزّل Artifact وثبّته فوق القديم.

## الإعدادات
افتح أيقونة التطبيق: سرعة التحديث، الوضع التلقائي حسب البطارية،
حجم الخط، موقع النص، إظهار السجل. التغييرات تنطبق فوراً.

## HyperOS
التشغيل التلقائي: مفعّل / توفير البطارية: بدون قيود.

## جديد في v4
- أقصى تردد لكل نواة قابل للتعديل من الإعدادات.
- اسم شبكة الواي فاي (صلاحية الموقع) وقسم البلوتوث (صلاحية الأجهزة القريبة).
- أول تشغيل: افتح التطبيق واضغط Grant permissions.

## جديد في v5
- محرر التخطيط: أي سطر، أي عمود، إخفاء/إظهار، ألوان مخصصة، وفلترة أحداث السجل.
- السطوع من معلومات الشاشة الحقيقية (يتبع شريط النظام) مع علامة auto.
- اسم الشبكة: طريقة إضافية + سبب واضح لو ما ظهر (AP N/A (...)).

## Field settings, color rules, log colors, power modes

- Layout screen, gear button on a block: show/hide each field in the line, and per-field color rules
  (when charging, value >= / <= N ...). First matching rule wins. BAT percent and DSK percent ship with
  editable built-in rules.
- Layout screen, "LOG colors": one color per log state (charging, unplugged, camera in use, ...).
- Power modes (Xiaomi): block `pwr` shows balanced / performance / battery saver / ultra saver.
  Ultra uses `EXTREME_POWER_SAVE_MODE_OPEN`, saver uses `POWER_SAVE_MODE_OPEN` (Settings.System).
  The Performance mode key is not documented: use "Power mode diagnostics" at the bottom of the Layout
  screen (snapshot, switch mode, show changes) and type the key it finds.
