# SysMon Wallpaper v5

## التحديث
1. ارفع SysMonWallpaper.zip بنفس الاسم (يستبدل القديم) ثم Commit.
2. Actions ← انتظر البناء ← نزّل Artifact وثبّته فوق القديم.

## الإعدادات
افتح أيقونة التطبيق: سرعة التحديث، الوضع التلقائي حسب البطارية،
حجم الخط، موقع النص، إظهار السجل. التغييرات تنطبق فوراً.

## HyperOS
التشغيل التلقائي: مفعّل / توفير البطارية: بدون قيود.

## جديد في v4
- أقصى تردد لكل نواة قابل للتعديل من الإعدادات.
- اسم شبكة الواي فاي (صلاحية الموقع) وقسم البلوتوث (صلاحية الأجهزة القريبة).
- أول تشغيل: افتح التطبيق واضغط Grant permissions.

## جديد في v5
- محرر التخطيط: أي سطر، أي عمود، إخفاء/إظهار، ألوان مخصصة، وفلترة أحداث السجل.
- السطوع من معلومات الشاشة الحقيقية (يتبع شريط النظام) مع علامة auto.
- اسم الشبكة: طريقة إضافية + سبب واضح لو ما ظهر (AP N/A (...)).

## Field settings, color rules, log colors, power modes

- Layout screen, gear button on a block: show/hide each field in the line, and per-field color rules
  (when charging, value >= / <= N ...). First matching rule wins. BAT percent and DSK percent ship with
  editable built-in rules.
- Layout screen, "LOG colors": one color per log state (charging, unplugged, camera in use, ...).
- Power modes (Xiaomi): block `pwr` shows balanced / performance / battery saver / ultra saver.
  Ultra uses `EXTREME_POWER_SAVE_MODE_OPEN`, saver uses `POWER_SAVE_MODE_OPEN` (Settings.System).
  The Performance mode key is not documented: use "Power mode diagnostics" at the bottom of the Layout
  screen (snapshot, switch mode, show changes) and type the key it finds.

## 8.0

- Graph side notes: `(28.1-31.4°C 45s)` after any graph (range and/or time covered). Per graph in the Graph editor;
  quick switch for all graphs in Settings. Font size: Settings > Graph note text size.
- Auto zoom per graph: range follows the visible bars. Padding, min span, widen/shrink speed (ms),
  last-N-bars window, pin bottom/top. Colors still follow the real value.
- Settings: text size 3.0-14 sp, line spacing, total width and left column width in characters,
  note text size, log text size.
- TEST MODE (Settings): fake, fast-changing data for every block (battery, charging, network, bluetooth,
  camera/mic/GPS, modes, spectrum) with events in the log. Uses the current layout/colors/graph settings
  and changes none of them. Not exported with profiles.
- Default profile replaced with the user's profile.
